-- Add description column to custom_categories table
ALTER TABLE custom_categories ADD COLUMN IF NOT EXISTS description TEXT;