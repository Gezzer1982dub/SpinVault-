/**
 * SpinVault Content Script
 * Injects and executes the detector on gambling sites
 */

// Keep track of previously detected rewards to avoid duplicates
let detectedRewardHashes = new Set();

// Function to inject the detector script
function injectDetector() {
  console.log('SpinVault: Injecting detector script');
  
  return new Promise((resolve, reject) => {
    try {
      // Create script element
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('detector.js');
      script.onload = () => {
        script.remove();
        console.log('SpinVault: Detector script injected successfully');
        resolve();
      };
      script.onerror = (error) => {
        console.error('SpinVault: Failed to inject detector script', error);
        reject(error);
      };
      
      // Add script to page
      (document.head || document.documentElement).appendChild(script);
    } catch (error) {
      console.error('SpinVault: Error injecting detector script', error);
      reject(error);
    }
  });
}

// Create a simple hash of a reward for deduplication
function hashReward(reward) {
  return `${reward.site}-${reward.title}`;
}

// Function to scan the page for rewards
async function scanPage(manual = false) {
  try {
    console.log(`SpinVault: Starting ${manual ? 'manual' : 'automatic'} scan`);
    
    // Check if we're on a gambling site (basic check)
    const gambling_domains = [
      'bet365', 'paddypower', 'skybet', 'williamhill', 'ladbrokes', 'coral',
      'betfair', 'betfred', '888sport', '888casino', 'meccabingo', 'heartbingo', 
      'unibet', '10bet', 'betvictor', 'betway'
    ];
    
    const hostname = window.location.hostname.toLowerCase();
    const isGamblingSite = gambling_domains.some(domain => hostname.includes(domain));
    
    if (!isGamblingSite && !manual) {
      console.log('SpinVault: Not a known gambling site, skipping auto-scan');
      return;
    }
    
    // Ensure detector is injected
    await injectDetector();
    
    // Pause to make sure detector is ready
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Execute scan using the injected detector
    const scanResult = await new Promise((resolve) => {
      const interval = setInterval(() => {
        if (window.SpinVaultDetector) {
          clearInterval(interval);
          try {
            const result = window.SpinVaultDetector.scanForRewards();
            resolve(result);
          } catch (error) {
            console.error('SpinVault: Error executing scan', error);
            resolve({ success: false, message: error.message });
          }
        }
      }, 100);
      
      // Timeout after 5 seconds
      setTimeout(() => {
        clearInterval(interval);
        resolve({ success: false, message: 'Timed out waiting for detector' });
      }, 5000);
    });
    
    if (!scanResult.success) {
      console.error('SpinVault: Scan failed', scanResult.message);
      return;
    }
    
    // Filter out previously detected rewards
    const newRewards = scanResult.rewards.filter(reward => {
      const hash = hashReward(reward);
      if (detectedRewardHashes.has(hash)) {
        return false;
      }
      detectedRewardHashes.add(hash);
      return true;
    });
    
    if (newRewards.length === 0) {
      console.log('SpinVault: No new rewards found');
      return;
    }
    
    console.log(`SpinVault: Found ${newRewards.length} new rewards`);
    
    // Send rewards to background script
    chrome.runtime.sendMessage({
      action: 'rewardsDetected',
      rewards: newRewards,
      manual: manual
    });
    
  } catch (error) {
    console.error('SpinVault: Error scanning page', error);
  }
}

// Listen for scan requests from popup or background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'scanPage') {
    scanPage(true).then(() => {
      sendResponse({ success: true });
    }).catch(error => {
      sendResponse({ success: false, error: error.message });
    });
    return true; // Keep the messaging channel open for async response
  }
});

// Auto-scan after page load
window.addEventListener('load', () => {
  // Wait for the page to fully render before scanning
  setTimeout(() => {
    scanPage(false);
  }, 3000);
});

// Also scan when the DOM content is loaded (for faster initial scan)
document.addEventListener('DOMContentLoaded', () => {
  // Perform a quick initial scan
  setTimeout(() => {
    scanPage(false);
  }, 1000);
});

// Inform background script that content script is active
chrome.runtime.sendMessage({ action: 'contentScriptActive' });

console.log('SpinVault: Content script loaded');