/**
 * SpinVault Popup Script
 * Handles the popup UI and communication with the background script
 */

// DOM Elements
const scanButton = document.getElementById('scanButton');
const clearButton = document.getElementById('clearButton');
const rawToggle = document.getElementById('rawToggle');
const rewardsList = document.getElementById('rewardsList');
const emptyState = document.getElementById('emptyState');
const rawDetectionContainer = document.getElementById('rawDetectionContainer');
const loginFormContainer = document.getElementById('loginFormContainer');
const userInfoContainer = document.getElementById('userInfoContainer');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const loginButton = document.getElementById('loginButton');
const logoutButton = document.getElementById('logoutButton');
const loginError = document.getElementById('loginError');
const usernameDisplay = document.getElementById('usernameDisplay');
const connectionStatus = document.getElementById('connectionStatus');
const autoDetectionToggle = document.getElementById('autoDetectionToggle');
const notificationsToggle = document.getElementById('notificationsToggle');
const saveToServerToggle = document.getElementById('saveToServerToggle');

// Tab switching
const tabs = document.querySelectorAll('.tab');
const tabContents = document.querySelectorAll('.tab-content');

// Variables to store the current tab and raw reward data
let currentTab = 'rewards';
let rawRewardData = null;

// Initialize the popup
async function initialize() {
  try {
    // Get state from background script
    const state = await getState();
    
    // Update UI based on auth state
    updateAuthUI(state);
    
    // Update settings UI
    updateSettingsUI(state);
    
    // Get rewards
    const rewardsData = await chrome.runtime.sendMessage({ action: 'getRewards' });
    const rewards = rewardsData.rewards || [];
    
    // Update rewards UI
    updateRewardsUI(rewards);
    
    // Update connection status
    updateConnectionStatus(state.authenticated);
    
  } catch (error) {
    console.error('SpinVault: Error initializing popup', error);
    showError('Failed to connect to background service.');
  }
}

// Get state from background script
async function getState() {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: 'getState' }, response => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(response);
      }
    });
  });
}

// Update auth UI based on state
function updateAuthUI(state) {
  if (state.authenticated) {
    loginFormContainer.style.display = 'none';
    userInfoContainer.style.display = 'block';
    usernameDisplay.textContent = state.username;
  } else {
    loginFormContainer.style.display = 'block';
    userInfoContainer.style.display = 'none';
  }
}

// Update settings UI based on state
function updateSettingsUI(state) {
  autoDetectionToggle.checked = state.settings.autoDetectionEnabled;
  notificationsToggle.checked = state.settings.notificationsEnabled;
  saveToServerToggle.checked = state.settings.saveToServer;
}

// Update connection status UI
function updateConnectionStatus(authenticated) {
  connectionStatus.innerHTML = authenticated 
    ? '<span style="color:#8bc34a;">●</span>'
    : '<span style="color:#ff9800;">●</span>';
  connectionStatus.title = authenticated 
    ? 'Connected to SpinVault' 
    : 'Not logged in';
}

// Update rewards UI
function updateRewardsUI(rewards) {
  // Store raw data for raw view
  rawRewardData = rewards;
  
  // Clear the list
  rewardsList.innerHTML = '';
  
  // Show empty state if no rewards
  if (rewards.length === 0) {
    emptyState.style.display = 'flex';
    return;
  }
  
  // Hide empty state if we have rewards
  emptyState.style.display = 'none';
  
  // Sort rewards by detected time (newest first)
  rewards.sort((a, b) => new Date(b.detectedAt) - new Date(a.detectedAt));
  
  // Add each reward to the list
  rewards.forEach(reward => {
    const card = document.createElement('div');
    card.className = 'reward-card';
    
    // Format reward data
    const siteBadge = `<span class="site-badge">${reward.site || 'Unknown'}</span>`;
    const categoryBadge = `<span class="category-badge">${formatCategory(reward.category)}</span>`;
    
    // Create reward details
    let details = '';
    
    if (reward.game) {
      details += createDetailItem('Game', reward.game);
    }
    
    if (reward.spins) {
      details += createDetailItem('Spins', reward.spins);
    }
    
    if (reward.bonusAmount) {
      details += createDetailItem('Amount', reward.bonusAmount);
    }
    
    if (reward.wagering && reward.wagering !== 'Unknown') {
      details += createDetailItem('Wagering', reward.wagering);
    }
    
    if (reward.expiryDate) {
      const formattedDate = formatDate(reward.expiryDate);
      details += createDetailItem('Expires', formattedDate);
    }
    
    // Assemble the card
    card.innerHTML = `
      <div class="reward-title">${reward.title}</div>
      <div style="margin-bottom: 8px;">
        ${siteBadge}
        ${categoryBadge}
      </div>
      <div class="reward-details">
        ${details}
      </div>
    `;
    
    rewardsList.appendChild(card);
  });
}

// Create a detail item for the reward card
function createDetailItem(label, value) {
  return `
    <div class="reward-detail">
      <span class="reward-detail-label">${label}:</span>
      <span class="reward-detail-value">${value}</span>
    </div>
  `;
}

// Format a category string for display
function formatCategory(category) {
  if (!category) return 'Offer';
  
  // Remove underscores and capitalize
  return category
    .replace(/_/g, ' ')
    .replace(/\b\w/g, c => c.toUpperCase());
}

// Format a date string
function formatDate(dateString) {
  try {
    const date = new Date(dateString);
    // Check if valid date
    if (isNaN(date.getTime())) {
      return 'Unknown';
    }
    
    // Get today and tomorrow for comparison
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    // Format the date
    if (date.getTime() === today.getTime()) {
      return 'Today';
    } else if (date.getTime() === tomorrow.getTime()) {
      return 'Tomorrow';
    } else {
      return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });
    }
  } catch (error) {
    console.error('SpinVault: Error formatting date', error);
    return 'Unknown';
  }
}

// Update raw detection view
function updateRawDetectionView() {
  if (!rawRewardData || rawRewardData.length === 0) {
    rawDetectionContainer.textContent = 'No raw detection data available.';
    return;
  }
  
  try {
    const formattedData = JSON.stringify(rawRewardData, null, 2);
    rawDetectionContainer.textContent = formattedData;
  } catch (error) {
    console.error('SpinVault: Error formatting raw data', error);
    rawDetectionContainer.textContent = 'Error displaying raw data.';
  }
}

// Show an error message
function showError(message) {
  loginError.textContent = message;
  loginError.style.display = 'block';
}

// Hide error message
function hideError() {
  loginError.style.display = 'none';
}

// Scan the current page for rewards
async function scanPage() {
  try {
    // Get the active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab) {
      showError('No active tab found.');
      return;
    }
    
    // Send scan message to the content script
    chrome.tabs.sendMessage(tab.id, { action: 'scanPage' }, response => {
      if (chrome.runtime.lastError) {
        showError('Could not scan this page. Try refreshing the page first.');
      } else if (response && response.success) {
        // Refresh rewards list after a short delay
        setTimeout(initialize, 500);
      } else {
        showError('Scan failed. Make sure you are on a gambling site.');
      }
    });
  } catch (error) {
    console.error('SpinVault: Error scanning page', error);
    showError('Failed to scan page.');
  }
}

// Clear all detected rewards
async function clearRewards() {
  try {
    await chrome.runtime.sendMessage({ action: 'clearRewards' });
    initialize();
  } catch (error) {
    console.error('SpinVault: Error clearing rewards', error);
    showError('Failed to clear rewards.');
  }
}

// Login to the SpinVault account
async function login() {
  try {
    hideError();
    
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();
    
    if (!username || !password) {
      showError('Username and password are required.');
      return;
    }
    
    const response = await chrome.runtime.sendMessage({
      action: 'login',
      username,
      password
    });
    
    if (response.success) {
      // Refresh UI
      initialize();
    } else {
      showError(response.message || 'Login failed. Please check your credentials.');
    }
  } catch (error) {
    console.error('SpinVault: Error logging in', error);
    showError('Login failed. Please try again later.');
  }
}

// Logout from the SpinVault account
async function logout() {
  try {
    await chrome.runtime.sendMessage({ action: 'logout' });
    initialize();
  } catch (error) {
    console.error('SpinVault: Error logging out', error);
    showError('Logout failed. Please try again.');
  }
}

// Update settings
async function updateSettings(settings) {
  try {
    await chrome.runtime.sendMessage({
      action: 'updateSettings',
      settings
    });
  } catch (error) {
    console.error('SpinVault: Error updating settings', error);
  }
}

// Switch between tabs
function switchTab(tabName) {
  // Update active tab class
  tabs.forEach(tab => {
    tab.classList.toggle('active', tab.dataset.tab === tabName);
  });
  
  // Show active tab content
  tabContents.forEach(content => {
    const isActive = content.id === `${tabName}Tab`;
    content.classList.toggle('active', isActive);
  });
  
  currentTab = tabName;
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
  // Initialize the popup
  initialize();
  
  // Scan button
  scanButton.addEventListener('click', scanPage);
  
  // Clear button
  clearButton.addEventListener('click', clearRewards);
  
  // Raw toggle
  rawToggle.addEventListener('change', () => {
    rawDetectionContainer.style.display = rawToggle.checked ? 'block' : 'none';
    if (rawToggle.checked) {
      updateRawDetectionView();
    }
  });
  
  // Login button
  loginButton.addEventListener('click', login);
  
  // Logout button
  logoutButton.addEventListener('click', logout);
  
  // Tab switching
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      switchTab(tab.dataset.tab);
    });
  });
  
  // Settings toggles
  autoDetectionToggle.addEventListener('change', () => {
    updateSettings({ autoDetectionEnabled: autoDetectionToggle.checked });
  });
  
  notificationsToggle.addEventListener('change', () => {
    updateSettings({ notificationsEnabled: notificationsToggle.checked });
  });
  
  saveToServerToggle.addEventListener('change', () => {
    updateSettings({ saveToServer: saveToServerToggle.checked });
  });
});