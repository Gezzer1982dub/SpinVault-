/**
 * SpinVault Background Script
 * Handles communication with the backend and manages user authentication
 */

// Configuration
const API_BASE_URL = 'https://e3358ddb-cf0c-495d-95cd-423fbf06a5bd-00-3en8vm9jsxml6.picard.replit.dev/api';
const REWARDS_ENDPOINT = `${API_BASE_URL}/rewards/save`;
const USER_INFO_ENDPOINT = `${API_BASE_URL}/user`;

// State management
let state = {
  authenticated: false,
  userToken: null,
  username: null,
  detectedRewards: [],
  settings: {
    autoDetectionEnabled: true,
    notificationsEnabled: true,
    saveToServer: true
  }
};

// Initialization
async function initialize() {
  console.log('SpinVault: Initializing background script');
  
  // Load saved state
  const savedState = await chrome.storage.local.get(['userToken', 'username', 'detectedRewards', 'settings']);
  
  if (savedState.userToken) {
    state.userToken = savedState.userToken;
    state.username = savedState.username || 'User';
    state.authenticated = true;
    
    // Verify token is still valid
    verifyAuthentication();
  }
  
  if (savedState.settings) {
    state.settings = { ...state.settings, ...savedState.settings };
  }
  
  if (savedState.detectedRewards) {
    state.detectedRewards = savedState.detectedRewards;
  }
  
  // Set up alarm for periodic cleanup
  chrome.alarms.create('rewardsCleanup', { periodInMinutes: 60 * 24 }); // Once a day
  
  console.log('SpinVault: Initialization complete');
}

// Verify that the saved authentication token is still valid
async function verifyAuthentication() {
  try {
    const response = await fetch(USER_INFO_ENDPOINT, {
      method: 'GET',
      credentials: 'include', // Include cookies for session-based auth
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.log('SpinVault: Authentication session invalid or expired');
      state.authenticated = false;
      state.userToken = null;
      state.username = null;
      
      // Clear saved token
      await chrome.storage.local.remove(['userToken', 'username']);
    } else {
      const userData = await response.json();
      state.username = userData.username || 'User';
      state.authenticated = true;
      state.userToken = userData.id; // Use user ID as token
      console.log(`SpinVault: User verified - ${state.username}`);
    }
  } catch (error) {
    console.error('SpinVault: Error verifying authentication', error);
    // Don't clear token on network errors - might be temporary
  }
}

// Handle detected rewards from content script
async function handleDetectedRewards(rewards, manual = false) {
  console.log(`SpinVault: Processing ${rewards.length} rewards`);
  
  // Store rewards locally
  const updatedRewards = [...state.detectedRewards, ...rewards];
  
  // Keep only the latest 100 rewards to prevent storage bloat
  if (updatedRewards.length > 100) {
    updatedRewards.splice(0, updatedRewards.length - 100);
  }
  
  state.detectedRewards = updatedRewards;
  await chrome.storage.local.set({ detectedRewards: updatedRewards });
  
  // Update badge count
  updateBadgeCount(updatedRewards.length);
  
  // Notify user if manual scan
  if (manual) {
    if (rewards.length > 0) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'SpinVault',
        message: `Found ${rewards.length} reward${rewards.length === 1 ? '' : 's'} on this page!`
      });
    } else {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'SpinVault',
        message: 'No new rewards found on this page.'
      });
    }
  }
  
  // Send to server if authenticated and setting enabled
  if (state.authenticated && state.settings.saveToServer) {
    await saveRewardsToServer(rewards);
  }
}

// Save rewards to the server
async function saveRewardsToServer(rewards) {
  if (!state.authenticated) {
    console.log('SpinVault: Not authenticated, skipping server save');
    return;
  }
  
  try {
    console.log(`SpinVault: Saving ${rewards.length} rewards to server`);
    
    const response = await fetch(REWARDS_ENDPOINT, {
      method: 'POST',
      credentials: 'include', // Include cookies for session-based auth
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ rewards })
    });
    
    if (!response.ok) {
      throw new Error(`Server responded with ${response.status}`);
    }
    
    const result = await response.json();
    console.log('SpinVault: Rewards saved successfully', result);
  } catch (error) {
    console.error('SpinVault: Error saving rewards to server', error);
  }
}

// Update badge count on extension icon
function updateBadgeCount(count) {
  chrome.action.setBadgeText({ text: count > 0 ? count.toString() : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#4caf50' });
}

// Process login request
async function processLogin(username, password) {
  try {
    const response = await fetch(`${API_BASE_URL}/login`, {
      method: 'POST',
      credentials: 'include', // Include cookies for session-based auth
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });
    
    if (!response.ok) {
      throw new Error('Invalid username or password');
    }
    
    const data = await response.json();
    
    // Save authentication data
    state.authenticated = true;
    state.userToken = data.id; // Use user ID as token
    state.username = data.username || username;
    
    // Save to persistent storage
    await chrome.storage.local.set({
      userToken: state.userToken,
      username: state.username
    });
    
    console.log('SpinVault: Login successful');
    
    // Save any cached rewards
    if (state.detectedRewards.length > 0) {
      await saveRewardsToServer(state.detectedRewards);
    }
    
    return { success: true };
  } catch (error) {
    console.error('SpinVault: Login failed', error);
    return { success: false, message: error.message };
  }
}

// Process logout request
async function processLogout() {
  state.authenticated = false;
  state.userToken = null;
  state.username = null;
  
  // Clear saved auth data
  await chrome.storage.local.remove(['userToken', 'username']);
  
  console.log('SpinVault: Logout successful');
  return { success: true };
}

// Handle periodic cleanup of old rewards
function cleanupOldRewards() {
  // Remove rewards older than 30 days
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  state.detectedRewards = state.detectedRewards.filter(reward => {
    const detectedAt = new Date(reward.detectedAt);
    return detectedAt >= thirtyDaysAgo;
  });
  
  chrome.storage.local.set({ detectedRewards: state.detectedRewards });
  updateBadgeCount(state.detectedRewards.length);
  
  console.log(`SpinVault: Cleaned up rewards (${state.detectedRewards.length} remaining)`);
}

// Update settings
async function updateSettings(newSettings) {
  state.settings = { ...state.settings, ...newSettings };
  await chrome.storage.local.set({ settings: state.settings });
  console.log('SpinVault: Settings updated', state.settings);
}

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case 'rewardsDetected':
      handleDetectedRewards(message.rewards, message.manual);
      sendResponse({ success: true });
      break;
      
    case 'login':
      processLogin(message.username, message.password)
        .then(sendResponse)
        .catch(error => sendResponse({ success: false, message: error.message }));
      return true; // Keep channel open for async response
      
    case 'logout':
      processLogout()
        .then(sendResponse)
        .catch(error => sendResponse({ success: false, message: error.message }));
      return true; // Keep channel open for async response
      
    case 'getState':
      sendResponse({
        authenticated: state.authenticated,
        username: state.username,
        rewardsCount: state.detectedRewards.length,
        settings: state.settings
      });
      break;
      
    case 'getRewards':
      sendResponse({ rewards: state.detectedRewards });
      break;
      
    case 'clearRewards':
      state.detectedRewards = [];
      chrome.storage.local.set({ detectedRewards: [] });
      updateBadgeCount(0);
      sendResponse({ success: true });
      break;
      
    case 'updateSettings':
      updateSettings(message.settings)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, message: error.message }));
      return true; // Keep channel open for async response
      
    case 'contentScriptActive':
      sendResponse({ success: true });
      break;
      
    case 'scanAllTabs':
      // Trigger scan on all gambling site tabs
      chrome.tabs.query({}, tabs => {
        const gambling_domains = [
          'bet365', 'paddypower', 'skybet', 'williamhill', 'ladbrokes', 'coral',
          'betfair', 'betfred', '888', 'meccabingo', 'heartbingo', 'unibet', 
          '10bet', 'betvictor', 'betway'
        ];
        
        tabs.forEach(tab => {
          if (tab.url && gambling_domains.some(domain => tab.url.includes(domain))) {
            chrome.tabs.sendMessage(tab.id, { action: 'scanPage' });
          }
        });
      });
      sendResponse({ success: true });
      break;
  }
});

// Handle alarm events
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'rewardsCleanup') {
    cleanupOldRewards();
  }
});

// Initialize on install
chrome.runtime.onInstalled.addListener(details => {
  if (details.reason === 'install') {
    // First time install
    chrome.tabs.create({ url: 'welcome.html' });
  } else if (details.reason === 'update') {
    // Extension updated
    const version = chrome.runtime.getManifest().version;
    console.log(`SpinVault: Updated to version ${version}`);
  }
  
  initialize();
});

// Initialize on startup
initialize();