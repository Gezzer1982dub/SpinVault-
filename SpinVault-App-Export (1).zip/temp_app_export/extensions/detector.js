/**
 * SpinVault Advanced Reward Detector
 * Combines multiple detection methods for maximum coverage
 */

// Site configurations for detection
const SITE_CONFIGS = {
  'bet365.com': {
    name: 'Bet365',
    selectors: ['.promotion-pod', '.bonus-container', '.offers-module', '[class*="promo"]'],
    keywords: ['free bet', 'bonus', 'spin', 'offer', 'promotion']
  },
  'paddypower.com': {
    name: 'Paddy Power',
    selectors: ['.promotion-pod', '.offers-grid', '.promos-container'],
    keywords: ['free bet', 'power up', 'spin', 'bonus', 'offer']
  },
  'skybet.com': {
    name: 'Sky Bet',
    selectors: ['.promotion-card', '.offer-container', '.skybet-promo'],
    keywords: ['free bet', 'price boost', 'bonus', 'offer']
  },
  'williamhill.com': {
    name: 'William Hill',
    selectors: ['.promo-card', '.offer-grid', '.promotions-container'],
    keywords: ['free bet', 'bonus', 'spin', 'enhanced odds']
  },
  'ladbrokes.com': {
    name: 'Ladbrokes',
    selectors: ['.promotion-item', '.offer-pod', '.promo-block'],
    keywords: ['free bet', 'spin', 'bonus', 'promotion']
  },
  'coral.co.uk': {
    name: 'Coral',
    selectors: ['.promotion-container', '.offer-module', '.coral-promo'],
    keywords: ['free bet', 'spin', 'bonus', 'offer']
  },
  'betfair.com': {
    name: 'Betfair',
    selectors: ['.promotion-card', '.bf-offer', '.promos-container'],
    keywords: ['free bet', 'odds boost', 'exchange', 'bonus']
  },
  'betfred.com': {
    name: 'Betfred',
    selectors: ['.promotion-pod', '.bf-offer', '.promos-grid'],
    keywords: ['free bet', 'spin', 'bonus', 'double delight']
  },
  '888sport.com': {
    name: '888 Sport',
    selectors: ['.promotion-banner', '.offer-card', '.promo-grid'],
    keywords: ['free bet', 'bonus', 'enhanced odds', 'spin']
  },
  '888casino.com': {
    name: '888 Casino',
    selectors: ['.promo-card', '.offer-container', '.promo-banner'],
    keywords: ['free spin', 'bonus', 'welcome offer', 'promotion']
  },
  'meccabingo.com': {
    name: 'Mecca Bingo',
    selectors: ['.promotion-item', '.offer-card', '.mecca-promo'],
    keywords: ['free bingo', 'spin', 'bonus', 'promotion']
  },
  'heartbingo.co.uk': {
    name: 'Heart Bingo',
    selectors: ['.promotion-pod', '.offers-grid', '.heart-promo'],
    keywords: ['free bingo', 'spin', 'bonus', 'promotion']
  },
  'unibet.co.uk': {
    name: 'Unibet',
    selectors: ['.promotion-card', '.offer-container', '.unibet-promo'],
    keywords: ['free bet', 'bonus', 'spin', 'offer']
  },
  '10bet.co.uk': {
    name: '10Bet',
    selectors: ['.promotion-item', '.offer-banner', '.promo-grid'],
    keywords: ['free bet', 'bonus', 'cash out', 'boost']
  },
  'betvictor.com': {
    name: 'BetVictor',
    selectors: ['.promotion-card', '.bv-offer', '.promo-container'],
    keywords: ['free bet', 'bonus', 'price boost', 'spin']
  },
  'betway.com': {
    name: 'Betway',
    selectors: ['.promotion-pod', '.offer-module', '.betway-promo'],
    keywords: ['free bet', 'bonus', 'free spin', 'boost']
  }
};

// Default config for sites without specific configurations
const DEFAULT_CONFIG = {
  selectors: [
    '.promotion', '.promo', '.offer', '.bonus', '.free-bet',
    '[class*="promotion"]', '[class*="promo"]', '[class*="offer"]',
    '[class*="bonus"]', '[id*="promotion"]', '[id*="promo"]',
    '[id*="offer"]', '[id*="bonus"]'
  ],
  keywords: [
    'free bet', 'free spin', 'bonus', 'offer', 'promotion',
    'deposit', 'welcome', 'cash back', 'cash out', 'enhanced odds',
    'price boost', 'acca', 'free game', 'free bingo', 'prize'
  ]
};

// Detect site from the current URL
function detectSite(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    
    // Find matching site configuration
    for (const domain in SITE_CONFIGS) {
      if (hostname.includes(domain)) {
        return {
          name: SITE_CONFIGS[domain].name,
          config: SITE_CONFIGS[domain]
        };
      }
    }
    
    // If no specific configuration, use the domain as the site name
    const siteName = hostname.split('.').slice(-2, -1)[0];
    return {
      name: siteName.charAt(0).toUpperCase() + siteName.slice(1),
      config: DEFAULT_CONFIG
    };
  } catch (error) {
    console.error('SpinVault: Error detecting site', error);
    return null;
  }
}

// Extract offers using DOM selectors
function extractOffersFromDOM(site) {
  const results = [];
  const selectors = site.config.selectors;
  
  // Try each selector
  for (const selector of selectors) {
    try {
      const elements = document.querySelectorAll(selector);
      elements.forEach(element => {
        // Extract title
        let title = '';
        const titleElement = element.querySelector('h1, h2, h3, h4, h5, [class*="title"], [class*="header"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          title = element.textContent.trim().substring(0, 100);
        }
        
        // Extract description
        let description = '';
        const descElement = element.querySelector('p, [class*="description"], [class*="text"], [class*="content"]');
        if (descElement) {
          description = descElement.textContent.trim();
        }
        
        // Extract URL
        let url = '';
        const linkElement = element.querySelector('a');
        if (linkElement && linkElement.href) {
          url = linkElement.href;
        } else {
          url = window.location.href;
        }
        
        // Add to results if title is meaningful
        if (title && title.length > 5) {
          results.push({
            title,
            description,
            url,
            element: element.outerHTML.substring(0, 500) // Keep a snippet of the HTML for debugging
          });
        }
      });
    } catch (error) {
      console.error(`SpinVault: Error with selector "${selector}"`, error);
    }
  }
  
  return results;
}

// Use regex patterns to find offers in the page text
function extractOffersWithRegex(text) {
  const results = [];
  
  // Pattern for free spins
  const freeSpinPattern = /(\d+\s+free\s+spins\s+[^.;!?]+)/gi;
  const freeSpinMatches = text.match(freeSpinPattern) || [];
  
  freeSpinMatches.forEach(match => {
    // Extract game name if mentioned
    const gameMatch = match.match(/on\s+([A-Za-z0-9 ]+)/i);
    const game = gameMatch ? gameMatch[1] : null;
    
    // Extract number of spins
    const spinsMatch = match.match(/(\d+)\s+free\s+spins/i);
    const spins = spinsMatch ? parseInt(spinsMatch[1]) : null;
    
    // Check for wagering requirement
    let wagering = "Unknown";
    if (match.toLowerCase().includes("no wagering")) {
      wagering = "None";
    } else {
      const wageringMatch = match.match(/wagering\s+(requirement)?\s+(\d+)x/i);
      if (wageringMatch && wageringMatch[2]) {
        wagering = wageringMatch[2] + "x";
      }
    }
    
    results.push({
      title: match.trim(),
      game,
      spins,
      wagering,
      category: 'FREE_SPIN'
    });
  });
  
  // Pattern for free bets
  const freeBetPattern = /([£$€]\d+\s+free\s+bet\s+[^.;!?]+)/gi;
  const freeBetMatches = text.match(freeBetPattern) || [];
  
  freeBetMatches.forEach(match => {
    // Extract bet amount
    const amountMatch = match.match(/([£$€])(\d+)/);
    const currency = amountMatch ? amountMatch[1] : '£';
    const amount = amountMatch ? parseInt(amountMatch[2]) : null;
    
    results.push({
      title: match.trim(),
      bonusAmount: amount ? `${currency}${amount}` : null,
      category: 'FREE_BET'
    });
  });
  
  // Pattern for welcome bonuses
  const welcomeBonusPattern = /(welcome\s+bonus|sign\s+up\s+offer|new\s+customer\s+offer)[^.;!?]+\s+([£$€]\d+)/gi;
  const welcomeBonusMatches = text.match(welcomeBonusPattern) || [];
  
  welcomeBonusMatches.forEach(match => {
    // Extract bonus amount
    const amountMatch = match.match(/([£$€])(\d+)/);
    const currency = amountMatch ? amountMatch[1] : '£';
    const amount = amountMatch ? parseInt(amountMatch[2]) : null;
    
    results.push({
      title: match.trim(),
      bonusAmount: amount ? `${currency}${amount}` : null,
      category: 'WELCOME_OFFER'
    });
  });
  
  return results;
}

// Parse expiry date from text
function parseExpiryDate(text) {
  if (!text) return null;
  
  const lowerText = text.toLowerCase();
  
  // Check for common date patterns
  const patterns = [
    // Format: 31st December 2025
    /(\d{1,2}(?:st|nd|rd|th)?\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{4})/i,
    // Format: 31/12/2025 or 31-12-2025
    /(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/i,
    // Format: expires tomorrow/today/Monday
    /expires?\s+(today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday)/i,
    // Format: valid until midnight/noon
    /valid\s+until\s+(midnight|noon)/i
  ];
  
  for (const pattern of patterns) {
    const match = lowerText.match(pattern);
    if (match && match[1]) {
      const dateText = match[1];
      
      // Handle "tomorrow", "today", etc.
      if (/today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday/i.test(dateText)) {
        const today = new Date();
        if (dateText === 'today') {
          return new Date(today.setHours(23, 59, 59, 999));
        } else if (dateText === 'tomorrow') {
          const tomorrow = new Date(today);
          tomorrow.setDate(tomorrow.getDate() + 1);
          tomorrow.setHours(23, 59, 59, 999);
          return tomorrow;
        } else {
          // Handle specific day of week
          const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
          const targetDay = dayNames.indexOf(dateText.toLowerCase());
          const currentDay = today.getDay();
          let daysUntilTarget = targetDay - currentDay;
          if (daysUntilTarget <= 0) daysUntilTarget += 7; // Next week if day has already passed
          
          const targetDate = new Date(today);
          targetDate.setDate(targetDate.getDate() + daysUntilTarget);
          targetDate.setHours(23, 59, 59, 999);
          return targetDate;
        }
      }
      
      // Handle "midnight", "noon"
      if (/midnight|noon/i.test(dateText)) {
        const today = new Date();
        if (dateText === 'midnight') {
          const tomorrow = new Date(today);
          tomorrow.setDate(tomorrow.getDate() + 1);
          tomorrow.setHours(0, 0, 0, 0);
          return tomorrow;
        } else if (dateText === 'noon') {
          const noon = new Date(today);
          noon.setHours(12, 0, 0, 0);
          return noon;
        }
      }
      
      // Try to parse date formats
      try {
        // Clean up date text by removing ordinal suffixes
        const cleanDateText = dateText.replace(/(st|nd|rd|th)/i, '');
        let date = new Date(cleanDateText);
        
        // Check if valid date was parsed
        if (!isNaN(date.getTime())) {
          return date;
        }
        
        // Try DD/MM/YYYY format if above failed
        if (/\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}/.test(cleanDateText)) {
          const parts = cleanDateText.split(/[\/\-\.]/);
          if (parts.length === 3) {
            // Assume UK format day/month/year
            let year = parseInt(parts[2]);
            if (year < 100) year += year < 50 ? 2000 : 1900;
            date = new Date(year, parseInt(parts[1]) - 1, parseInt(parts[0]));
            if (!isNaN(date.getTime())) {
              return date;
            }
          }
        }
      } catch (e) {
        console.error('SpinVault: Error parsing date', e);
      }
    }
  }
  
  return null;
}

// Determine reward category based on text content
function determineCategory(text) {
  const lowerText = text.toLowerCase();
  
  if (lowerText.includes('free spin') || lowerText.includes('free game') || lowerText.includes('spin') && lowerText.includes('free')) {
    return 'FREE_SPIN';
  } else if (lowerText.includes('free bet') || (lowerText.includes('bet') && lowerText.includes('free'))) {
    return 'FREE_BET';
  } else if (lowerText.includes('bonus') && (lowerText.includes('deposit') || lowerText.includes('welcome'))) {
    return 'DEPOSIT_BONUS';
  } else if (lowerText.includes('cashback') || lowerText.includes('money back')) {
    return 'CASHBACK';
  } else if (lowerText.includes('odds boost') || lowerText.includes('enhanced odds') || lowerText.includes('price boost')) {
    return 'ODDS_BOOST';
  } else if (lowerText.includes('welcome') || lowerText.includes('new customer') || lowerText.includes('sign up')) {
    return 'WELCOME_OFFER';
  } else if (lowerText.includes('accumulator') || lowerText.includes('acca')) {
    return 'ACCA_INSURANCE';
  } else if (lowerText.includes('free bingo') || lowerText.includes('free game')) {
    return 'FREE_GAME';
  } else if (lowerText.includes('jackpot') || lowerText.includes('prize draw')) {
    return 'JACKPOT';
  } else {
    return 'OTHER';
  }
}

// Extract all visible text from the page
function extractVisibleText() {
  const bodyText = document.body.innerText || '';
  const visibleElements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, span, div, a, button');
  let combinedText = bodyText + ' ';
  
  visibleElements.forEach(element => {
    const style = window.getComputedStyle(element);
    if (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
      combinedText += ' ' + element.textContent;
    }
  });
  
  return combinedText;
}

// Normalize and clean rewards data
function normalizeReward(reward, site, detectedAt) {
  // Create expiry date (default to 7 days from now if not specified)
  const expiryDate = reward.expiresAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  
  // Clean up the title
  let title = reward.title || '';
  if (title.length > 200) {
    title = title.substring(0, 197) + '...';
  }
  
  // Normalize URL
  const url = reward.url || window.location.href;
  
  // Determine category if not already set
  const category = reward.category || determineCategory(title);
  
  // Structure the final reward object
  return {
    title: title,
    game: reward.game || null,
    bonusAmount: reward.bonusAmount || null,
    spins: reward.spins || null,
    wagering: reward.wagering || "Unknown",
    expiryDate: expiryDate instanceof Date ? expiryDate.toISOString() : expiryDate,
    category: category,
    site: site.name,
    url: url,
    detectedAt: detectedAt.toISOString()
  };
}

// Main scanning function
function scanForRewards() {
  try {
    const currentUrl = window.location.href;
    const site = detectSite(currentUrl);
    
    if (!site) {
      console.log('SpinVault: Not a supported gambling site');
      return { success: false, message: 'Not a supported gambling site' };
    }
    
    console.log(`SpinVault: Scanning ${site.name} for rewards...`);
    
    // Extract offers using DOM selectors
    const domOffers = extractOffersFromDOM(site);
    console.log(`SpinVault: Found ${domOffers.length} DOM-based offers`);
    
    // Extract visible text for regex parsing
    const visibleText = extractVisibleText();
    
    // Extract offers using regex patterns
    const regexOffers = extractOffersWithRegex(visibleText);
    console.log(`SpinVault: Found ${regexOffers.length} regex-based offers`);
    
    // Combine all offers
    const allOffers = [...domOffers, ...regexOffers];
    if (allOffers.length === 0) {
      return { success: true, rewards: [], message: 'No rewards found' };
    }
    
    // Detected timestamp
    const detectedAt = new Date();
    
    // Process and normalize rewards
    const rewards = allOffers.map(offer => normalizeReward(offer, site, detectedAt));
    
    // Remove duplicates based on title similarity
    const uniqueRewards = [];
    const titles = new Set();
    
    rewards.forEach(reward => {
      // Simple deduplication based on title
      const normalizedTitle = reward.title.toLowerCase().replace(/\s+/g, ' ').trim();
      
      // Check if we have a similar title already
      let isDuplicate = false;
      for (const existingTitle of titles) {
        // If 70% of the shorter title is contained in the longer one, consider it a duplicate
        const shorter = normalizedTitle.length < existingTitle.length ? normalizedTitle : existingTitle;
        const longer = normalizedTitle.length >= existingTitle.length ? normalizedTitle : existingTitle;
        
        if (longer.includes(shorter.substring(0, Math.floor(shorter.length * 0.7)))) {
          isDuplicate = true;
          break;
        }
      }
      
      if (!isDuplicate) {
        titles.add(normalizedTitle);
        uniqueRewards.push(reward);
      }
    });
    
    console.log(`SpinVault: Found ${uniqueRewards.length} unique rewards on ${site.name}`);
    
    return {
      success: true,
      rewards: uniqueRewards,
      site: site.name,
      message: `Found ${uniqueRewards.length} rewards on ${site.name}`
    };
  } catch (error) {
    console.error('SpinVault: Error scanning for rewards', error);
    return { success: false, message: 'Error scanning for rewards: ' + error.message };
  }
}

// Make functions available globally
window.SpinVaultDetector = {
  scanForRewards,
  detectSite,
  extractOffersFromDOM,
  extractOffersWithRegex,
  parseExpiryDate,
  determineCategory
};