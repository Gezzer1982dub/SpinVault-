# SpinVault Chrome Extension v3.0.0 - Production Edition

## Overview

This is the production-ready Chrome extension for SpinVault that automatically detects gambling rewards across 100+ UK gambling sites. The extension combines multiple detection methods for maximum coverage and integrates seamlessly with your SpinVault backend.

## Features

### Advanced Detection System
- **Dual Detection Methods**: Combines sophisticated DOM-based detection with regex pattern matching
- **Smart Site Recognition**: Automatically identifies and adapts to different gambling sites
- **Real-time Scanning**: Detects rewards as you browse gambling websites
- **Manual Scan Option**: Click "Scan Page" button for on-demand detection

### Reward Data Structure
Each detected reward includes:
- `title`: The main reward text
- `game`: Associated game (if applicable)
- `bonusAmount`: Monetary value (if applicable)
- `spins`: Number of free spins (if applicable)
- `wagering`: Wagering requirements
- `expiryDate`: When the offer expires
- `category`: Type of reward (FREE_BET, FREE_SPIN, DEPOSIT_BONUS, etc.)
- `site`: The gambling site name
- `url`: Source URL
- `detectedAt`: Detection timestamp

### User Interface
- Clean, modern popup design
- Real-time reward display with detailed information
- Raw detection preview toggle for debugging
- Settings panel with customizable options
- Authentication integration with SpinVault account

### Backend Integration
- Automatic sync to SpinVault backend via `/api/rewards/save`
- Session-based authentication using cookies
- Duplicate detection and prevention
- Local storage for offline capability

## Installation

1. Download the extension ZIP file
2. Extract to a folder on your computer
3. Open Chrome and go to `chrome://extensions`
4. Enable "Developer Mode" (toggle in top-right)
5. Click "Load Unpacked" and select the extracted folder
6. The SpinVault extension will appear in your browser toolbar

## Usage

### Initial Setup
1. Click the SpinVault extension icon
2. Log in with your SpinVault account credentials
3. Configure settings as needed

### Automatic Detection
- Visit any supported gambling site
- The extension automatically scans for rewards
- New rewards appear in the popup and sync to your account

### Manual Scanning
- Click the SpinVault extension icon
- Click "Scan Page" to manually trigger detection
- View detected rewards in the popup

### Settings
- **Automatic Detection**: Enable/disable auto-scanning
- **Notifications**: Control notification preferences
- **Server Sync**: Enable/disable syncing to SpinVault account
- **Raw Preview**: Show technical detection data

## Supported Sites

The extension works with 100+ UK gambling sites including:

### Tier 1 Sites (Optimized Detection)
- Bet365
- Paddy Power
- Sky Bet
- William Hill
- Ladbrokes
- Coral
- Betfair
- Betfred

### Tier 2 Sites (Enhanced Detection)
- 888 Sport / Casino
- Mecca Bingo
- Heart Bingo
- Unibet
- 10Bet
- BetVictor
- Betway

### Additional Sites
- 80+ more gambling sites with basic detection support

## Technical Details

### Detection Methods
1. **DOM-based Detection**: Uses CSS selectors and site-specific configurations
2. **Regex Pattern Matching**: Catches simple patterns like "50 free spins"
3. **Text Analysis**: Processes visible page content for keyword matching

### Authentication
- Uses session-based authentication with cookies
- Automatically verifies login status
- Handles login/logout through SpinVault API

### Data Storage
- Local storage for offline capability
- Automatic cleanup of old rewards (30+ days)
- Badge counter shows total detected rewards

### Performance
- Lightweight content script injection
- Efficient scanning algorithms
- Minimal impact on browsing performance

## API Integration

### Backend Endpoint
The extension posts rewards to: `/api/rewards/save`

### Request Format
```json
{
  "rewards": [
    {
      "title": "50 Free Spins on Starburst",
      "game": "Starburst", 
      "spins": 50,
      "wagering": "35x",
      "category": "FREE_SPIN",
      "site": "Bet365",
      "url": "https://www.bet365.com/promotions",
      "detectedAt": "2025-01-30T23:13:00.000Z",
      "expiryDate": "2025-02-06T23:59:59.000Z"
    }
  ]
}
```

### Response Format
```json
{
  "success": true,
  "message": "Successfully saved 1 rewards",
  "count": 1,
  "rewards": [...]
}
```

## Troubleshooting

### Extension Not Working
1. Check that you're on a supported gambling site
2. Refresh the page and try again
3. Check Chrome extensions page for any errors
4. Ensure you're logged into your SpinVault account

### No Rewards Detected
1. Try manual scanning with "Scan Page" button
2. Check if the site has visible promotions
3. Enable raw detection preview to see technical details
4. Some sites may block automated detection

### Login Issues
1. Verify your SpinVault account credentials
2. Check internet connection
3. Try logging out and back in
4. Clear browser cookies if needed

## Development

### File Structure
- `manifest.json`: Extension configuration
- `background.js`: Service worker handling API communication
- `content.js`: Content script for page scanning
- `detector.js`: Core detection algorithms
- `popup.html/js`: User interface
- `icons/`: Extension icons

### Permissions
- `storage`: Local data storage
- `tabs`: Access to tab information
- `scripting`: Inject detection scripts
- `alarms`: Periodic cleanup
- `<all_urls>`: Access gambling sites

## Changelog

### v3.0.0 - Production Edition
- Complete rewrite with dual detection system
- Enhanced UI with settings panel
- Improved backend integration
- Better error handling and debugging
- Support for 100+ gambling sites
- Session-based authentication
- Raw detection preview mode

## Support

For technical support or feature requests, contact SpinVault support through your account dashboard.