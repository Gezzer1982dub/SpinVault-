import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { detectionService } from "./detection";
import { setupAuth } from "./auth";
import { z } from "zod";
import { resolveOfferLink, validateOfferLink } from "./services/link-resolver";
import { 
  insertRewardSchema, updateRewardSchema, RewardCategory,
  insertCustomCategorySchema, updateCustomCategorySchema,
  insertOfferingSchema, updateOfferingSchema
} from "@shared/schema";
import Stripe from "stripe";
import path from "path";
import fs from "fs";
import { notificationsRouter } from "./routes-notifications";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}
// the newest Stripe API version
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16" as any,
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Direct HTML endpoints - needs to be before catch-all routes
  app.get("/extension-download", (req, res) => {
    // Redirect to the latest version
    res.redirect("/extensions");
  });
  
  // Extension download directory with index page
  app.get("/extensions", (req, res) => {
    res.sendFile(path.join(process.cwd(), "extensions/index.html"));
  });
  
  // Serve the extension folders for direct browsing
  app.use("/extensions", express.static(path.join(process.cwd(), "extensions")));
  
  // Serve our current extension versions
  app.get("/extension-download-v20", (req, res) => {
    res.sendFile(path.join(process.cwd(), "extensions/extension-download-v20-exact-capture.html"));
  });
  
  app.get("/extension-download-v18", (req, res) => {
    res.sendFile(path.join(process.cwd(), "extensions/extension-download-improved-v18.html"));
  });
  
  // Direct ZIP downloads for various extension versions
  app.get("/spinvault-extension-exact-capture-v20.zip", (req, res) => {
    const filePath = path.join(process.cwd(), "extensions/current/downloads/spinvault-extension-exact-capture-v20.zip");
    res.download(filePath, "spinvault-extension-exact-capture-v20.zip");
  });
  
  app.get("/spinvault-extension-comprehensive-v18.zip", (req, res) => {
    const filePath = path.join(process.cwd(), "extensions/current/downloads/spinvault-extension-comprehensive-v18.zip");
    res.download(filePath, "spinvault-extension-comprehensive-v18.zip");
  });
  
  // Legacy routes for backward compatibility
  app.get("/extension-download-v11", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public/extension-v11-download.html"));
  });
  
  // Connected v16 extension download endpoint
  app.get("/extension-download-v16", (req, res) => {
    res.sendFile(path.join(process.cwd(), "extension-download-connected-v16.html"));
  });
  
  app.get("/download", (req, res) => {
    // Check if the request is coming from a mobile device
    const userAgent = req.headers['user-agent'] || '';
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
    
    if (isMobile) {
      res.sendFile(path.join(process.cwd(), "public/mobile-download.html"));
    } else {
      // Serve the premium v11 download page
      res.sendFile(path.join(process.cwd(), "public/extension-v11-download.html"));
    }
  });
  
  // Direct backup links
  app.get("/backup-download", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public/backup-direct-link.html"));
  });
  
  // Ultra-direct download page
  app.get("/download-backup", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public/direct-backup-download.html"));
  });
  
  // Simple backup download page
  app.get("/get-backup", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public/get-backup.html"));
  });
  
  // Project download page
  app.get("/project-download", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public/project-download.html"));
  });
  
  // Direct project download without dynamic generation
  app.get("/get-project", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public/direct-project-download.html"));
  });
  
  // Private secure download
  app.get("/secure-project", (req, res) => {
    // Only provide to authenticated users for security
    if (req.isAuthenticated()) {
      res.sendFile(path.join(process.cwd(), "public/secure_download.html"));
    } else {
      res.redirect("/auth");
    }
  });
  
  // Secure download endpoint with session validation
  app.get("/secure-file-download", (req, res) => {
    // Only provide to authenticated users
    if (req.isAuthenticated()) {
      // User is authenticated, provide the secure download
      res.download(path.join(process.env.HOME as string, "secure_download/spinvault-essential-code.zip"), "spinvault-complete-project.zip");
    } else {
      res.redirect("/auth");
    }
  });
  
  // Serve static download files
  app.get("/downloads/spinvault-full-project.zip", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public/downloads/spinvault-full-project.zip"));
  });
  
  // Direct download endpoints
  app.get("/spinvault-extension-fixed-v8.zip", (req, res) => {
    res.download(path.join(process.cwd(), "spinvault-extension-fixed-v8.zip"));
  });
  
  app.get("/spinvault-extension-fixed-v10.zip", (req, res) => {
    res.download(path.join(process.cwd(), "spinvault-extension-fixed-v10.zip"));
  });
  
  app.get("/spinvault-extension-fixed-v11.zip", (req, res) => {
    res.download(path.join(process.cwd(), "spinvault-extension-fixed-v11.zip"));
  });
  
  app.get("/spinvault-basic-v2.zip", (req, res) => {
    res.download(path.join(process.cwd(), "spinvault-basic-v2.zip"));
  });
  
  app.get("/spinvault-extension-connected-v16.zip", (req, res) => {
    res.download(path.join(process.cwd(), "spinvault-extension-connected-v16.zip"));
  });
  
  // Direct download for v20 extension
  app.get("/spinvault-extension-exact-capture-v20.zip", (req, res) => {
    res.download(path.join(process.cwd(), "extensions/current/downloads/spinvault-extension-exact-capture-v20.zip"));
  });
  
  // Direct download for v18 extension
  app.get("/spinvault-extension-improved-v18-comprehensive.zip", (req, res) => {
    res.download(path.join(process.cwd(), "extensions/current/downloads/spinvault-extension-improved-v18-comprehensive.zip"));
  });
  
  // Direct download for production v3.0.0 extension
  app.get("/spinvault-extension-production-v3.0.0.zip", (req, res) => {
    res.download(path.join(process.cwd(), "extensions/SpinVault-Production-v3.0.0.zip"));
  });
  
  // Direct download for v14 extension
  app.get("/spinvault-extension-v14.zip", (req, res) => {
    res.download(path.join(process.cwd(), "spinvault-extension-fixed-v14.zip"));
  });
  
  // Serve extension zip directly - multiple endpoints for compatibility
  app.get("/extension-download/v8", (req, res) => {
    res.sendFile(path.join(process.cwd(), "spinvault-extension-fixed-v8.zip"));
  });
  
  app.get("/extension-download/v11", (req, res) => {
    res.sendFile(path.join(process.cwd(), "spinvault-extension-fixed-v11.zip"));
  });
  
  app.get("/extension-download/v10", (req, res) => {
    res.sendFile(path.join(process.cwd(), "spinvault-extension-fixed-v10.zip"));
  });
  
  app.get("/extension-download/basic", (req, res) => {
    res.sendFile(path.join(process.cwd(), "spinvault-basic-v2.zip"));
  });
  
  app.get("/extension-download/v16", (req, res) => {
    res.sendFile(path.join(process.cwd(), "spinvault-extension-connected-v16.zip"));
  });
  
  app.get("/downloads/extension-v8.zip", (req, res) => {
    res.sendFile(path.join(process.cwd(), "public/downloads/extension-v8.zip"));
  });
  
  app.get("/download-basic-extension", (req, res) => {
    res.sendFile(path.join(process.cwd(), "spinvault-basic-v2.zip"));
  });
  
  // Direct access to backup files
  app.get("/backups/:filename", (req, res) => {
    const filename = req.params.filename;
    const backupPath = path.join(process.cwd(), "backups", filename);
    
    if (fs.existsSync(backupPath)) {
      return res.download(backupPath);
    } else {
      return res.status(404).send("Backup file not found");
    }
  });
  
  // Project download endpoints
  app.get("/download-project", async (req, res) => {
    try {
      // Create a temp directory for zip files if it doesn't exist
      const zipDir = path.join(process.cwd(), "temp_zip");
      if (!fs.existsSync(zipDir)) {
        fs.mkdirSync(zipDir, { recursive: true });
      }
      
      // Generate a zip file of important project files
      const zipFilePath = path.join(zipDir, "spinvault-project.zip");
      const archiver = require('archiver');
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      output.on('close', function() {
        console.log('Project archive created: ' + archive.pointer() + ' total bytes');
        res.download(zipFilePath, "spinvault-project.zip");
      });
      
      archive.on('error', function(err) {
        console.error("Error creating project archive:", err);
        res.status(500).send("Failed to create project archive");
      });
      
      archive.pipe(output);
      
      // Add key project files and directories
      const foldersToInclude = [
        'client', 
        'server', 
        'public', 
        'shared', 
        'extensions',
        'scripts'
      ];
      
      // Add root config files
      archive.glob('*.json');
      archive.glob('*.js');
      archive.glob('*.ts');
      archive.glob('*.html');
      archive.glob('*.md');
      
      // Add key folders
      for (const folder of foldersToInclude) {
        if (fs.existsSync(folder)) {
          archive.directory(folder, folder);
        }
      }
      
      archive.finalize();
    } catch (error) {
      console.error("Error preparing project download:", error);
      res.status(500).send("Failed to prepare project download");
    }
  });
  
  // Backup utility page
  app.get("/backup", (req, res) => {
    // Check if the request is coming from a mobile device
    const userAgent = req.headers['user-agent'] || '';
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
    
    if (isMobile) {
      res.sendFile(path.join(process.cwd(), "public/mobile-backup-guide.html"));
    } else {
      res.sendFile(path.join(process.cwd(), "public/backup.html"));
    }
  });
  
  // API endpoint to create a backup
  app.post("/api/backups/create", async (req, res) => {
    try {
      // Only allow authenticated users to create backups
      if (!req.isAuthenticated()) {
        return res.status(401).json({ success: false, message: "Authentication required" });
      }
      
      const backupType = req.body.type || 'full';
      console.log(`Creating ${backupType} backup...`);
      
      // Import the backup module dynamically
      const { runBackup } = await import('../scripts/backup.js');
      
      // Run the backup process
      const result = await runBackup();
      
      if (result.success) {
        return res.status(200).json({
          success: true,
          message: "Backup created successfully",
          backupPath: result.backupPath,
          timestamp: result.timestamp
        });
      } else {
        return res.status(500).json({
          success: false,
          message: `Backup failed: ${result.error}`
        });
      }
    } catch (error) {
      console.error("Error creating backup:", error);
      return res.status(500).json({
        success: false,
        message: `An error occurred during backup: ${error.message}`
      });
    }
  });
  
  // API endpoint to download a backup file
  app.get("/api/backups/download/:filename", (req, res) => {
    try {
      // Only allow authenticated users to download backups
      if (!req.isAuthenticated()) {
        return res.status(401).send("Authentication required");
      }
      
      const filename = req.params.filename;
      const backupDir = path.join(process.cwd(), "backups");
      
      if (filename === 'latest') {
        // Find the most recent backup file
        const files = fs.readdirSync(backupDir)
          .filter(file => file.startsWith('spinvault-backup-'))
          .sort()
          .reverse();
        
        if (files.length === 0) {
          return res.status(404).send("No backup files found");
        }
        
        const latestBackup = files[0];
        return res.download(path.join(backupDir, latestBackup));
      } else {
        // Check if the requested file exists and is within the backups directory
        const backupPath = path.join(backupDir, filename);
        
        if (!fs.existsSync(backupPath)) {
          return res.status(404).send("Backup file not found");
        }
        
        return res.download(backupPath);
      }
    } catch (error) {
      console.error("Error downloading backup:", error);
      return res.status(500).send("An error occurred while downloading the backup");
    }
  });
  
  // API endpoint to list all backups
  app.get("/api/backups", (req, res) => {
    try {
      // Only allow authenticated users to view backups
      if (!req.isAuthenticated()) {
        return res.status(401).json({ success: false, message: "Authentication required" });
      }
      
      const backupDir = path.join(process.cwd(), "backups");
      
      // Check if backup directory exists
      if (!fs.existsSync(backupDir)) {
        return res.json({ success: true, backups: [] });
      }
      
      // Get all backup files
      const files = fs.readdirSync(backupDir)
        .filter(file => file.startsWith('spinvault-backup-'))
        .map(file => {
          const stats = fs.statSync(path.join(backupDir, file));
          return {
            filename: file,
            timestamp: file.replace('spinvault-backup-', '').replace('.zip', ''),
            size: stats.size,
            created: stats.mtime
          };
        })
        .sort((a, b) => b.created.getTime() - a.created.getTime());
      
      return res.json({
        success: true,
        backups: files
      });
    } catch (error) {
      console.error("Error listing backups:", error);
      return res.status(500).json({
        success: false,
        message: `An error occurred while listing backups: ${error.message}`
      });
    }
  });
  
  // Sets up /api/register, /api/login, /api/logout, /api/user, /api/demo
  setupAuth(app);
  
  // Register notification routes
  app.use(notificationsRouter);
  
  // Return the current application URL for the extension
  app.get("/api/app-url", (req, res) => {
    // Get the host from request or use default
    const host = req.headers.host || "localhost:5000";
    const protocol = req.protocol || "http";
    res.json({ url: `${protocol}://${host}` });
  });
  
  // Extension endpoints
  // Save rewards from Chrome extension
  app.post("/api/rewards/save", async (req, res) => {
    try {
      // Check for authentication
      if (!req.isAuthenticated()) {
        return res.status(401).json({ success: false, message: "Authentication required" });
      }
      
      const userId = req.user.id;
      const { rewards } = req.body;
      
      if (!rewards || !Array.isArray(rewards)) {
        return res.status(400).json({ success: false, message: "Invalid rewards data" });
      }
      
      console.log(`Saving ${rewards.length} rewards for user ${userId}`);
      
      const savedRewards = [];
      
      // Process each reward
      for (const reward of rewards) {
        try {
          // Validate and structure the reward data
          const rewardData = {
            userId,
            site: reward.site || 'Unknown',
            reward: reward.title || reward.reward || 'Unknown Reward',
            category: reward.category || 'OTHER',
            expiresAt: reward.expiryDate ? new Date(reward.expiryDate) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
            url: reward.url || '',
            detectedAt: reward.detectedAt ? new Date(reward.detectedAt) : new Date(),
            // Additional metadata
            metadata: {
              game: reward.game || null,
              bonusAmount: reward.bonusAmount || null,
              spins: reward.spins || null,
              wagering: reward.wagering || null
            }
          };
          
          // Check for duplicates by title and site - get all user rewards and filter
          const allUserRewards = await storage.getRewards(userId);
          const existingReward = allUserRewards.filter(r => 
            r.site === rewardData.site && r.reward === rewardData.reward
          );
          
          if (existingReward.length === 0) {
            const savedReward = await storage.createReward(rewardData);
            savedRewards.push(savedReward);
          } else {
            console.log(`Duplicate reward skipped: ${rewardData.reward} from ${rewardData.site}`);
          }
        } catch (error) {
          console.error(`Error saving individual reward:`, error);
        }
      }
      
      return res.status(200).json({
        success: true,
        message: `Successfully saved ${savedRewards.length} rewards`,
        count: savedRewards.length,
        rewards: savedRewards
      });
    } catch (error) {
      console.error("Error saving rewards from extension:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to save rewards"
      });
    }
  });
  
  // Handle extension settings sync
  app.post("/api/extension/settings", async (req, res) => {
    try {
      // Require authentication for settings sync
      if (!req.isAuthenticated()) {
        return res.status(401).json({ success: false, message: "Authentication required" });
      }
      
      const userId = req.user.id;
      
      // Validate input - adapting to our schema structure
      const settingsInput = {
        userId,
        // Format for nested settings object
        settings: {
          enabledSites: req.body.enabledSites || ['Bet365', 'William Hill', 'Paddy Power'],
          autoSyncEnabled: req.body.autoSyncEnabled !== false,
          notificationsEnabled: req.body.notificationsEnabled !== false,
          detectionSettings: req.body.detectionSettings || {}
        },
        // These are direct fields, not in settings JSON
        dailyDetectionCount: req.body.dailyDetectionCount || 0,
        lastDetectionReset: req.body.lastDetectionReset ? new Date(req.body.lastDetectionReset) : new Date()
      };
      
      console.log(`Syncing extension settings for user ${userId}`);
      
      // Update the settings in the database
      const updatedSettings = await storage.updateExtensionSettings(userId, settingsInput);
      
      return res.status(200).json({
        success: true,
        message: "Settings synced successfully",
        settings: updatedSettings
      });
    } catch (error) {
      console.error("Error syncing extension settings:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to sync settings"
      });
    }
  });
  
  // Get extension settings for a user
  app.get("/api/extension/settings", async (req, res) => {
    try {
      // Require authentication to get settings
      if (!req.isAuthenticated()) {
        return res.status(401).json({ success: false, message: "Authentication required" });
      }
      
      const userId = req.user.id;
      const dbSettings = await storage.getExtensionSettings(userId);
      
      if (dbSettings) {
        // Format the response to match the expected structure
        // This creates a flat object with the settings fields from both root and settings property
        const responseSettings = {
          // Include root level fields
          id: dbSettings.id,
          userId: dbSettings.userId,
          dailyDetectionCount: dbSettings.dailyDetectionCount || 0,
          lastDetectionReset: dbSettings.lastDetectionReset || new Date(),
          updatedAt: dbSettings.updatedAt,
          
          // Include nested settings fields
          enabledSites: dbSettings.settings?.enabledSites || ['Bet365', 'William Hill', 'Paddy Power'],
          autoSyncEnabled: dbSettings.settings?.autoSyncEnabled !== false,
          notificationsEnabled: dbSettings.settings?.notificationsEnabled !== false,
          detectionSettings: dbSettings.settings?.detectionSettings || {}
        };
        
        return res.status(200).json({
          success: true,
          settings: responseSettings
        });
      } else {
        // If no settings exist yet, return default settings
        return res.status(200).json({
          success: true,
          settings: {
            enabledSites: ['Bet365', 'William Hill', 'Paddy Power'],
            autoSyncEnabled: true,
            notificationsEnabled: true,
            dailyDetectionCount: 0,
            lastDetectionReset: new Date(),
            detectionSettings: {}
          }
        });
      }
    } catch (error) {
      console.error("Error getting extension settings:", error);
      return res.status(500).json({
        success: false, 
        message: "Failed to get settings"
      });
    }
  });
  
  // Handle reward submissions from the extension
  app.post("/api/extension/rewards", async (req, res) => {
    try {
      // For testing/debugging, allow rewards without authentication
      const siteData = req.body.site || "Unknown Site";
      const rewardData = req.body.reward || "Unknown Reward";
      
      console.log(`Extension submitted reward from ${siteData}: ${rewardData}`);
      
      // If we have extension authentication with a user ID
      if (req.body.userId) {
        const userId = parseInt(req.body.userId);
        const user = await storage.getUser(userId);
        
        if (user) {
          // Save the reward
          const rewardToSave = {
            userId: user.id,
            site: siteData,
            reward: rewardData,
            category: req.body.category || 'OTHER',
            expiresAt: req.body.expiryDate ? new Date(req.body.expiryDate) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
            notes: req.body.notes || '',
            claimed: false
          };
          
          await storage.createReward(rewardToSave);
          console.log(`Saved extension reward for user ${userId}`);
          
          return res.status(200).json({ 
            success: true, 
            message: "Reward saved successfully" 
          });
        }
      }
      
      // In development, accept the reward anyway for testing
      if (process.env.NODE_ENV === 'development') {
        console.log('Accepted reward in development mode without authentication');
        return res.status(200).json({ 
          success: true, 
          message: "Reward accepted in development mode" 
        });
      }
      
      return res.status(401).json({ 
        success: false, 
        message: "Authentication required to save rewards" 
      });
    } catch (error) {
      console.error("Error in extension rewards endpoint:", error);
      return res.status(500).json({ 
        success: false,
        message: "Failed to process reward"
      });
    }
  });
  
  // Special API route for Chrome extension auth
  app.post("/api/extension/auth", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username) {
        return res.status(400).json({ success: false, message: "Username required" });
      }
      
      // Find the user
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(401).json({ success: false, message: "Invalid credentials" });
      }
      
      // Special case for extension token - skip password validation
      // This is just for testing, in a production app we would use a secure token system
      const isExtensionToken = password === 'extension-auth-token';
      let isValid = isExtensionToken;
      
      // If not using extension token, validate actual password
      if (!isExtensionToken && password) {
        try {
          // Try to import the password validation function
          const { comparePasswords } = await import('./auth');
          isValid = await comparePasswords(password, user.password);
        } catch (e) {
          console.warn('Could not import comparePasswords function, using fallback validation');
          // For testing only, don't do this in production
          isValid = true; 
        }
      }
      
      if (isValid) {
        // Log success for monitoring/debugging
        console.log(`Extension auth successful for user: ${username}`);
        
        return res.status(200).json({ 
          success: true, 
          user: {
            id: user.id,
            username: user.username,
            isPremium: user.isPremium || false
          }
        });
      } else {
        return res.status(401).json({ success: false, message: "Invalid credentials" });
      }
    } catch (error) {
      console.error("Error in extension auth:", error);
      return res.status(500).json({ success: false, message: "Authentication error" });
    }
  });

  // GET all rewards for current user
  app.get("/api/rewards", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      console.log("Fetching rewards for user ID:", req.user.id);
      const rewards = await storage.getRewards(req.user.id);
      console.log("Rewards fetched successfully:", rewards.length);
      res.json(rewards);
    } catch (error) {
      console.error("Error fetching rewards:", error);
      res.status(500).send("Error fetching rewards");
    }
  });
  
  // POST sync rewards from automatic detection
  app.post("/api/sync-rewards", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const { rewards = [] } = req.body;
      if (!Array.isArray(rewards) || rewards.length === 0) {
        return res.json({ success: true, savedCount: 0, rewards: [] });
      }
      
      const userId = req.user.id;
      const savedRewards = [];
      let savedCount = 0;
      
      // Process each reward
      for (const reward of rewards) {
        try {
          // Prepare the reward data
          const rewardData = {
            userId,
            site: reward.site || 'Unknown Site',
            reward: reward.reward || 'Unknown Reward',
            category: reward.category || null,
            expiresAt: reward.expiresAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Default to 7 days
            notes: reward.notes || '',
            claimed: false,
          };
          
          // Save the reward to the database
          const savedReward = await storage.createReward(rewardData);
          savedRewards.push(savedReward);
          savedCount++;
        } catch (error) {
          console.error('Error processing reward during sync:', error);
          // Continue with other rewards even if one fails
        }
      }
      
      console.log(`Auto-synced ${savedCount} rewards for user ${userId}`);
      res.json({ success: true, savedCount, rewards: savedRewards });
    } catch (error) {
      console.error("Error syncing rewards:", error);
      res.status(500).json({ success: false, error: "Failed to sync rewards" });
    }
  });
  
  // GET expiring rewards for notifications
  app.get("/api/rewards/expiring", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const userId = req.user!.id;
      const now = new Date();
      
      // Get rewards that expire within the next 24 hours and are not claimed
      const rewards = await storage.getRewards(userId);
      const expiringRewards = rewards.filter(reward => {
        const expiryDate = new Date(reward.expiresAt);
        const timeLeft = expiryDate.getTime() - now.getTime();
        const hoursLeft = timeLeft / (1000 * 60 * 60);
        
        return hoursLeft <= 24 && hoursLeft > 0 && !reward.claimed;
      });
      
      console.log(`Found ${expiringRewards.length} expiring rewards for user ${userId}`);
      res.json({ rewards: expiringRewards });
    } catch (error) {
      console.error("Error fetching expiring rewards:", error);
      res.status(500).send({ error: "Failed to fetch expiring rewards" });
    }
  });

  // GET a specific reward
  app.get("/api/rewards/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const rewardId = parseInt(req.params.id);
      const reward = await storage.getReward(rewardId);
      
      if (!reward || reward.userId !== req.user.id) {
        return res.status(404).send("Reward not found");
      }
      
      res.json(reward);
    } catch (error) {
      res.status(500).send("Error fetching reward");
    }
  });
  
  // Analyze a reward with AI to estimate its true value
  app.post("/api/rewards/:id/analyze", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const rewardId = parseInt(req.params.id);
      const reward = await storage.getReward(rewardId);
      
      if (!reward) {
        return res.status(404).json({ success: false, error: "Reward not found" });
      }
      
      // Only allow users to analyze their own rewards
      if (reward.userId !== req.user.id) {
        return res.status(403).json({ success: false, error: "Unauthorized" });
      }
      
      // If the user is not premium and has exceeded analysis limit
      if (!req.user.isPremium) {
        // Check if the user has already analyzed 3+ rewards in the last 24 hours
        const rewards = await storage.getRewards(req.user.id);
        const analyzedRewardsCount = 0; // In the future, we would track this in the database
        
        if (analyzedRewardsCount >= 3) {
          return res.status(403).json({ 
            success: false, 
            error: "Free tier limit reached",
            message: "Upgrade to premium for unlimited reward analysis",
            requiresUpgrade: true
          });
        }
      }
      
      // Import the analyzeRewardValue function using dynamic import
      // to avoid issues if OpenAI is not available
      const { analyzeRewardValue } = await import('./ai/reward-analyzer');
      
      // Analyze the reward
      const analysis = await analyzeRewardValue(
        reward.site,
        reward.reward,
        reward.category,
        reward.expiresAt
      );
      
      // TODO: In a future update, we could store the analysis in the database
      // For now, we just return it directly
      
      res.json({
        success: true,
        analysis
      });
    } catch (error) {
      console.error("Error analyzing reward:", error);
      res.status(500).json({ 
        success: false, 
        error: "Failed to analyze reward"
      });
    }
  });

  // CREATE a new reward
  app.post("/api/rewards", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const validatedData = insertRewardSchema.parse({
        ...req.body,
        userId: req.user.id,
      });
      
      const reward = await storage.createReward(validatedData);
      res.status(201).json(reward);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).send("Error creating reward");
    }
  });

  // UPDATE a reward (full update)
  app.put("/api/rewards/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const rewardId = parseInt(req.params.id);
      const validatedData = updateRewardSchema.parse(req.body);
      
      const updatedReward = await storage.updateReward(
        rewardId,
        req.user.id,
        validatedData
      );
      
      if (!updatedReward) {
        return res.status(404).send("Reward not found or unauthorized");
      }
      
      res.json(updatedReward);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).send("Error updating reward");
    }
  });
  
  // PATCH a reward (partial update, useful for progress tracking)
  app.patch("/api/rewards/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const rewardId = parseInt(req.params.id);
      
      // Validate the fields that are being updated
      const validatedData = updateRewardSchema.parse(req.body);
      
      // Special handling for progress updates
      if (validatedData.progressCurrent !== undefined) {
        console.log(`Updating progress for reward ${rewardId} to ${validatedData.progressCurrent}`);
        
        // If progressLastUpdated isn't provided, set it to now
        if (!validatedData.progressLastUpdated) {
          validatedData.progressLastUpdated = new Date();
        }
        
        // Check if we've reached the target
        const reward = await storage.getReward(rewardId);
        if (reward && 
            reward.progressTarget && 
            validatedData.progressCurrent >= reward.progressTarget && 
            !reward.claimed) {
          console.log(`Progress target reached for reward ${rewardId}`);
          
          // Optionally suggest claiming the reward
          // We don't auto-claim here as the user might want to verify first
        }
      }
      
      const updatedReward = await storage.updateReward(
        rewardId,
        req.user.id,
        validatedData
      );
      
      if (!updatedReward) {
        return res.status(404).send("Reward not found or unauthorized");
      }
      
      res.json(updatedReward);
    } catch (error) {
      console.error("Error updating reward:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).send("Error updating reward");
    }
  });

  // DELETE a reward
  app.delete("/api/rewards/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const rewardId = parseInt(req.params.id);
      const deleted = await storage.deleteReward(rewardId, req.user.id);
      
      if (!deleted) {
        return res.status(404).send("Reward not found or unauthorized");
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).send("Error deleting reward");
    }
  });
  
  // DELETE multiple rewards
  app.post("/api/rewards/delete-multiple", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({
        success: false,
        error: "Unauthorized"
      });
    }
    
    try {
      const { ids } = req.body;
      
      if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({
          success: false,
          error: "Invalid or empty reward IDs array"
        });
      }
      
      const userId = req.user.id;
      const results = await Promise.all(
        ids.map(id => storage.deleteReward(parseInt(id), userId))
      );
      
      const deletedCount = results.filter(Boolean).length;
      
      res.json({
        success: true,
        deletedCount,
        message: `Successfully deleted ${deletedCount} rewards`
      });
    } catch (error) {
      console.error("Error deleting multiple rewards:", error);
      res.status(500).json({
        success: false,
        error: "Failed to delete rewards"
      });
    }
  });

  // Enhanced reward detection using AI and pattern matching
  app.post("/api/detect-reward", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const { content, url } = req.body;
      
      // Development mode - allow empty content for testing
      const isDevelopment = process.env.NODE_ENV === 'development';
      
      if (!content && !isDevelopment) {
        return res.status(400).json({ 
          success: false,
          error: "Content is required for detection" 
        });
      }
      
      // If no content is provided, return an error
      if (!content) {
        return res.status(400).json({ 
          success: false,
          error: "Content is required for reward detection. Please provide the page content to scan." 
        });
      }
      
      // Use the detection service to find rewards with actual content
      const result = await detectionService.detectFromContent(content, url, req.user.id);
      
      res.json(result);
    } catch (error) {
      console.error("Error detecting reward:", error);
      res.status(500).json({
        success: false,
        error: "Error detecting reward"
      });
    }
  });
  
  // Extension API endpoint - allows Chrome extension to submit rewards
  app.post("/api/extension/rewards", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const rewardData = req.body;
      
      // Validate the reward data
      if (!rewardData.site || !rewardData.reward) {
        return res.status(400).json({ 
          success: false, 
          error: "Missing required fields" 
        });
      }
      
      // Create expiry date from expiresIn seconds (if provided)
      let expiresAt = new Date();
      if (rewardData.expiresIn) {
        expiresAt.setSeconds(expiresAt.getSeconds() + rewardData.expiresIn);
      } else {
        // Default 7 days if not provided
        expiresAt.setDate(expiresAt.getDate() + 7);
      }
      
      // Create a new reward with user ID from session
      const newReward = await storage.createReward({
        userId: req.user.id,
        site: rewardData.site,
        reward: rewardData.reward,
        expiresAt: expiresAt,
        claimed: false,
        category: rewardData.category || "OTHER",
        confidence: rewardData.confidence || "0.8"
      });
      
      res.status(201).json({
        success: true,
        reward: newReward
      });
    } catch (error) {
      console.error("Error saving reward from extension:", error);
      res.status(500).json({ 
        success: false,
        error: "Error saving reward" 
      });
    }
  });
  
  // Mobile API endpoints for reward detection
  
  // Image-based detection
  app.post("/api/mobile/detect-image", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const { imageBase64 } = req.body;

      if (!imageBase64) {
        return res.status(400).json({ error: 'Image data is required' });
      }

      // Check if user is premium (image detection is premium-only)
      const user = await storage.getUser(req.user.id);
      const isPremium = user?.isPremium && 
        (!user.premiumExpiresAt || new Date(user.premiumExpiresAt) > new Date());
      
      if (!isPremium) {
        return res.status(403).json({
          success: false,
          error: "Premium subscription required for image detection",
          requiresPremium: true
        });
      }
      
      // Strip out data:image/jpeg;base64, if it's included
      const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');
      
      // Run detection on the image
      const result = await detectionService.detectFromImage(base64Data, req.user.id);
      
      return res.json({
        success: result.success,
        rewards: result.rewards.map(reward => ({
          site: reward.site,
          reward: reward.reward,
          expiresAt: reward.expiresAt,
          category: reward.category
        })),
        message: result.success 
          ? `Found ${result.rewards.length} reward${result.rewards.length !== 1 ? 's' : ''}` 
          : 'No rewards detected'
      });
    } catch (error) {
      console.error('Error detecting rewards from image:', error);
      return res.status(500).json({ error: 'Failed to process image' });
    }
  });

  // QR code detection
  app.post("/api/mobile/detect-qrcode", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const { qrData } = req.body;

      if (!qrData) {
        return res.status(400).json({ error: 'QR code data is required' });
      }
      
      // Check if user is premium (all advanced detection is premium-only)
      const user = await storage.getUser(req.user.id);
      const isPremium = user?.isPremium && 
        (!user.premiumExpiresAt || new Date(user.premiumExpiresAt) > new Date());
      
      if (!isPremium) {
        return res.status(403).json({
          success: false,
          error: "Premium subscription required for QR code detection",
          requiresPremium: true
        });
      }
      
      // For QR codes, we assume they're URLs or special promo codes
      // First try to use it as a URL to fetch content
      let content = '';
      let url = '';
      
      if (qrData.startsWith('http')) {
        try {
          url = qrData;
          // We'd fetch the URL content here, but for security reasons,
          // we'll just analyze the URL itself in this implementation
          content = `Promo link: ${qrData}`;
        } catch (error) {
          console.error('Error fetching URL from QR code:', error);
          content = qrData; // Use the QR content directly if URL fetch fails
        }
      } else {
        // If it's not a URL, treat as a promo code
        content = `Promo code: ${qrData}`;
      }
      
      // Analyze the content
      const result = await detectionService.detectFromContent(content, url, req.user.id);
      
      return res.json({
        success: result.success,
        rewards: result.rewards.map(reward => ({
          site: reward.site,
          reward: reward.reward,
          expiresAt: reward.expiresAt,
          category: reward.category
        })),
        message: result.success 
          ? `Found ${result.rewards.length} reward${result.rewards.length !== 1 ? 's' : ''}` 
          : 'No rewards detected'
      });
    } catch (error) {
      console.error('Error detecting rewards from QR code:', error);
      return res.status(500).json({ error: 'Failed to process QR code' });
    }
  });

  // Text-based detection
  app.post("/api/mobile/detect-text", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const { text, url } = req.body;

      if (!text) {
        return res.status(400).json({ error: 'Text content is required' });
      }
      
      // Check if user is premium (all advanced detection is premium-only)
      const user = await storage.getUser(req.user.id);
      const isPremium = user?.isPremium && 
        (!user.premiumExpiresAt || new Date(user.premiumExpiresAt) > new Date());
      
      if (!isPremium) {
        return res.status(403).json({
          success: false,
          error: "Premium subscription required for text detection",
          requiresPremium: true
        });
      }
      
      // Analyze the text content
      const result = await detectionService.detectFromContent(text, url, req.user.id);
      
      return res.json({
        success: result.success,
        rewards: result.rewards.map(reward => ({
          site: reward.site,
          reward: reward.reward,
          expiresAt: reward.expiresAt,
          category: reward.category
        })),
        message: result.success 
          ? `Found ${result.rewards.length} reward${result.rewards.length !== 1 ? 's' : ''}` 
          : 'No rewards detected'
      });
    } catch (error) {
      console.error('Error detecting rewards from text:', error);
      return res.status(500).json({ error: 'Failed to process text' });
    }
  });
  
  // Backward compatibility: original image detection endpoint
  app.post("/api/detect-from-image", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const { imageData } = req.body;
      
      if (!imageData) {
        return res.status(400).json({ 
          success: false,
          error: "Image data is required" 
        });
      }
      
      // Check if user is premium (image detection is premium-only)
      const user = await storage.getUser(req.user.id);
      const isPremium = user?.isPremium && 
        (!user.premiumExpiresAt || new Date(user.premiumExpiresAt) > new Date());
      
      if (!isPremium) {
        return res.status(403).json({
          success: false,
          error: "Premium subscription required for image detection"
        });
      }
      
      // Use the detection service to analyze the image
      const result = await detectionService.detectFromImage(imageData, req.user.id);
      
      res.json(result);
    } catch (error) {
      console.error("Error detecting from image:", error);
      res.status(500).json({
        success: false,
        error: "Error detecting from image"
      });
    }
  });
  
  // Sync API for cross-device extension settings
  app.get("/api/extension/sync", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      // Get the user's extension settings
      const extensionSettings = await storage.getExtensionSettings(req.user.id);
      
      if (!extensionSettings) {
        return res.status(404).json({
          success: false,
          message: "No settings found"
        });
      }
      
      res.json({
        success: true,
        settings: extensionSettings
      });
    } catch (error) {
      console.error("Error retrieving extension settings:", error);
      res.status(500).json({ 
        success: false,
        error: "Error retrieving extension settings"
      });
    }
  });
  
  // Update extension sync settings
  app.post("/api/extension/sync", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const { settings } = req.body;
      
      if (!settings) {
        return res.status(400).json({
          success: false,
          error: "No settings provided" 
        });
      }
      
      // Format settings correctly for the database
      const formattedSettings = {
        userId: req.user.id,
        settings: {
          enabledSites: settings.enabledSites || ['Bet365', 'William Hill', 'Paddy Power'],
          autoSyncEnabled: settings.autoSyncEnabled !== false,
          notificationsEnabled: settings.notificationsEnabled !== false,
          detectionSettings: settings.detectionSettings || {}
        },
        dailyDetectionCount: settings.dailyDetectionCount || 0,
        lastDetectionReset: settings.lastDetectionReset ? new Date(settings.lastDetectionReset) : new Date()
      };
      
      // Store the user's extension settings
      const updatedSettings = await storage.updateExtensionSettings(req.user.id, formattedSettings);
      
      res.json({
        success: true,
        settings: updatedSettings
      });
    } catch (error) {
      console.error("Error saving extension settings:", error);
      res.status(500).json({ 
        success: false,
        error: "Error saving extension settings"
      });
    }
  });
  
  // Detection usage statistics endpoint
  app.get("/api/detection/stats", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      // Calculate simple detection statistics based on rewards
      const rewards = await storage.getRewards(req.user.id);
      const now = new Date();
      
      // Get settings for usage stats
      const settings = await storage.getExtensionSettings(req.user.id);
      
      // Calculate reward stats
      const activeRewards = rewards.filter(r => new Date(r.expiresAt) > now && !r.claimed);
      const claimedRewards = rewards.filter(r => r.claimed);
      const expiredRewards = rewards.filter(r => new Date(r.expiresAt) <= now && !r.claimed);
      
      // Group by site
      const bySite = rewards.reduce((acc: Record<string, number>, reward) => {
        acc[reward.site] = (acc[reward.site] || 0) + 1;
        return acc;
      }, {});
      
      // Group by category
      const byCategory = rewards.reduce((acc: Record<string, number>, reward) => {
        const category = reward.category || 'OTHER';
        acc[category] = (acc[category] || 0) + 1;
        return acc;
      }, {});
      
      // Basic usage stats
      const usageStats = {
        dailyDetectionCount: settings?.dailyDetectionCount || 0,
        totalRewardsDetected: rewards.length,
        successRate: rewards.length > 0 ? 1.0 : 0
      };
      
      res.json({
        success: true,
        detection: {
          totalRewards: rewards.length,
          activeRewards: activeRewards.length,
          claimedRewards: claimedRewards.length,
          expiredRewards: expiredRewards.length,
          bySite,
          byCategory
        },
        usage: usageStats
      });
    } catch (error) {
      console.error("Error getting detection stats:", error);
      res.status(500).json({
        success: false,
        error: "Error getting detection stats"
      });
    }
  });
  
  // Mobile API endpoints
  
  // Mobile API endpoint for analyzing images of gambling sites
  app.post("/api/mobile/analyze-image", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const { image } = req.body;
      
      if (!image) {
        return res.status(400).json({
          success: false,
          error: "No image data provided"
        });
      }
      
      // Check if premium status is needed for AI analysis
      const user = req.user;
      if (!user.isPremium) {
        // Check usage count for free tier
        const MAX_FREE_ANALYSES = 5;
        // In a production app, we would check if the user has exceeded their daily limit
        // For demo purposes, we'll allow all analyses
      }
      
      // Import AI integration functions
      const { analyzeImageWithAI } = await import('./detection/ai-integration');
      
      console.log("Processing mobile image analysis...");
      
      // Process the image with AI
      const analysisResult = await analyzeImageWithAI(image);
      
      if (analysisResult.success && analysisResult.rewards.length > 0) {
        // Save detected rewards to the database
        const savedRewards = [];
        
        for (const reward of analysisResult.rewards) {
          try {
            const newReward = await storage.createReward({
              userId: req.user.id,
              site: reward.site,
              reward: reward.reward,
              expiresAt: reward.expiresAt,
              claimed: false,
              category: reward.category || "OTHER",
              confidence: reward.confidence ? reward.confidence.toString() : "0.7"
            });
            
            savedRewards.push(newReward);
          } catch (err) {
            console.error("Error saving detected reward:", err);
          }
        }
        
        // Return the saved rewards
        res.json({
          success: true,
          message: `Found ${savedRewards.length} rewards`,
          rewards: savedRewards
        });
      } else {
        // No rewards found
        res.json({
          success: true,
          message: "No rewards detected in the image",
          rewards: []
        });
      }
    } catch (error) {
      console.error("Error analyzing image:", error);
      res.status(500).json({
        success: false,
        error: "Error analyzing image"
      });
    }
  });
  
  // Custom Categories API endpoints
  
  // GET all custom categories for current user
  app.get("/api/custom-categories", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const categories = await storage.getCustomCategories(req.user.id);
      res.json(categories);
    } catch (error) {
      console.error("Error fetching custom categories:", error);
      res.status(500).send("Error fetching custom categories");
    }
  });
  
  // GET a specific custom category
  app.get("/api/custom-categories/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const categoryId = parseInt(req.params.id);
      const category = await storage.getCustomCategory(categoryId);
      
      if (!category || category.userId !== req.user.id) {
        return res.status(404).send("Category not found");
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).send("Error fetching category");
    }
  });
  
  // CREATE a new custom category
  app.post("/api/custom-categories", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const validatedData = insertCustomCategorySchema.parse({
        ...req.body,
        userId: req.user.id,
      });
      
      const category = await storage.createCustomCategory(validatedData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).send("Error creating custom category");
    }
  });
  
  // UPDATE a custom category
  app.put("/api/custom-categories/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const categoryId = parseInt(req.params.id);
      const validatedData = updateCustomCategorySchema.parse(req.body);
      
      const updatedCategory = await storage.updateCustomCategory(
        categoryId,
        req.user.id,
        validatedData
      );
      
      if (!updatedCategory) {
        return res.status(404).send("Category not found or unauthorized");
      }
      
      res.json(updatedCategory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).send("Error updating custom category");
    }
  });
  
  // DELETE a custom category
  app.delete("/api/custom-categories/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const categoryId = parseInt(req.params.id);
      const deleted = await storage.deleteCustomCategory(categoryId, req.user.id);
      
      if (!deleted) {
        return res.status(404).send("Category not found or unauthorized");
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).send("Error deleting custom category");
    }
  });
  
  // Shared reward endpoint - allows viewing a reward without authentication
  app.get("/api/share/reward/:id", async (req, res) => {
    try {
      const rewardId = parseInt(req.params.id);
      
      if (isNaN(rewardId)) {
        return res.status(400).json({
          success: false,
          error: "Invalid reward ID"
        });
      }
      
      const reward = await storage.getReward(rewardId);
      
      if (!reward) {
        return res.status(404).json({
          success: false,
          error: "Reward not found"
        });
      }
      
      // Remove sensitive user information 
      const { userId, ...safeReward } = reward;
      
      res.json({
        success: true,
        reward: safeReward
      });
    } catch (error) {
      console.error("Error fetching shared reward:", error);
      res.status(500).json({
        success: false,
        error: "Error fetching shared reward"
      });
    }
  });

  // Premium subscription endpoints
  
  // Social Insights API endpoints
  
  // Get anonymized reward insights from all users
  app.get("/api/social/insights", async (req, res) => {
    try {
      // Get anonymized global reward stats
      const stats = await storage.getAnonymizedRewardStats();
      
      res.json({
        success: true,
        stats
      });
    } catch (error) {
      console.error("Error getting social insights:", error);
      res.status(500).json({
        success: false,
        error: "Error fetching social insights"
      });
    }
  });
  
  // Reward statistics endpoint - provides data for visualizations
  app.get("/api/stats/rewards", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const timeframe = req.query.timeframe || "30days";
      const userId = req.user.id;
      
      // Get the user's rewards
      let rewards = await storage.getRewards(userId);
      
      // Filter rewards based on timeframe
      const now = new Date();
      let startDate = new Date();
      
      // Set start date based on timeframe
      if (timeframe === "7days") {
        startDate.setDate(now.getDate() - 7);
      } else if (timeframe === "30days") {
        startDate.setDate(now.getDate() - 30);
      } else if (timeframe === "90days") {
        startDate.setDate(now.getDate() - 90);
      } else {
        // "all" - no filtering needed
        startDate = new Date(0); // Beginning of time
      }
      
      // Filter rewards by date
      const filteredRewards = rewards.filter(reward => 
        new Date(reward.createdAt) >= startDate
      );
      
      // Calculate statistics
      const totalRewards = filteredRewards.length;
      
      // Mock total value calculation - in a real app this would use real analysis data
      // This is just a placeholder for demonstration
      let totalValue = 0;
      let averageValue = 0;
      
      // Calculate mock values based on reward types
      filteredRewards.forEach(reward => {
        let estimatedValue = 0;
        if (reward.reward.toLowerCase().includes("free bet")) {
          estimatedValue = Math.random() * 30 + 10; // £10-40 for free bets
        } else if (reward.reward.toLowerCase().includes("free spin")) {
          estimatedValue = Math.random() * 15 + 5; // £5-20 for free spins
        } else if (reward.reward.toLowerCase().includes("cashback")) {
          estimatedValue = Math.random() * 50 + 20; // £20-70 for cashback
        } else {
          estimatedValue = Math.random() * 20 + 5; // £5-25 for others
        }
        totalValue += estimatedValue;
      });
      
      averageValue = totalRewards > 0 ? totalValue / totalRewards : 0;
      
      // Group rewards by site
      const siteDistribution = filteredRewards.reduce((acc, reward) => {
        acc[reward.site] = (acc[reward.site] || 0) + 1;
        return acc;
      }, {});
      
      // Group rewards by category
      const categoryDistribution = filteredRewards.reduce((acc, reward) => {
        const category = reward.category || "OTHER";
        acc[category] = (acc[category] || 0) + 1;
        return acc;
      }, {});
      
      // Return the statistics
      res.json({
        success: true,
        timeframe,
        totalRewards,
        totalValue,
        averageValue,
        siteDistribution,
        categoryDistribution
      });
    } catch (error) {
      console.error("Error fetching reward statistics:", error);
      res.status(500).json({
        success: false,
        error: "Error fetching reward statistics"
      });
    }
  });
  
  // Get user's daily reward accumulation summary
  app.get("/api/stats/rewards/daily-summary", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const userId = req.user.id;
      
      // Get the user's daily reward summary
      const summary = await storage.getUserDailyRewardSummary(userId);
      
      res.json({
        success: true,
        summary
      });
    } catch (error) {
      console.error("Error fetching daily reward summary:", error);
      res.status(500).json({
        success: false,
        error: "Failed to fetch daily reward summary"
      });
    }
  });
  
  // Get leaderboard of top reward finders (anonymized usernames)
  app.get("/api/social/leaderboard", async (req, res) => {
    try {
      const leaderboard = await storage.getRewardLeaderboard();
      
      // Anonymize usernames for privacy
      const anonymizedLeaderboard = leaderboard.map((entry, index) => ({
        rank: index + 1,
        username: `User${entry.id}`,
        rewardCount: entry.rewardCount,
        totalValue: entry.totalValue || 0
      }));
      
      res.json({
        success: true,
        leaderboard: anonymizedLeaderboard
      });
    } catch (error) {
      console.error("Error getting leaderboard:", error);
      res.status(500).json({
        success: false,
        error: "Error fetching leaderboard data"
      });
    }
  });
  
  // Get trending reward sites and categories
  app.get("/api/social/trending", async (req, res) => {
    try {
      // Get trending data
      const trendingData = await storage.getTrendingRewardData();
      
      res.json({
        success: true,
        trending: trendingData
      });
    } catch (error) {
      console.error("Error getting trending data:", error);
      res.status(500).json({
        success: false,
        error: "Error fetching trending data"
      });
    }
  });

  // Check premium status
  app.get("/api/premium/status", async (req, res) => {
    if (!req.isAuthenticated()) {
      // For extension compatibility, return JSON even for auth failures
      return res.status(401).json({ 
        success: false, 
        message: "Unauthorized",
        isPremium: false
      });
    }
    
    try {
      console.log(`Checking premium status for user ID: ${req.user.id}`);
      const user = await storage.getUser(req.user.id);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found",
          isPremium: false
        });
      }
      
      // Check if premium and not expired
      const isPremium = user.isPremium && 
        (user.premiumExpiresAt === null || new Date(user.premiumExpiresAt) > new Date());
      
      console.log(`User ${user.username} premium status: ${isPremium ? 'Premium' : 'Free'}`);
      
      // If premium status was checked from the extension, update the user record with current time
      // This helps track extension usage
      const source = req.headers['x-source'] || 'unknown';
      if (source === 'extension') {
        // We don't need to await this, it can happen in the background
        storage.updateUser(user.id, { lastExtensionActivity: new Date() })
          .catch(err => console.error('Failed to update lastExtensionActivity:', err));
      }
      
      res.json({
        success: true,
        isPremium,
        expiresAt: user.premiumExpiresAt,
        username: user.username,
        id: user.id
      });
    } catch (error) {
      console.error("Error checking premium status:", error);
      res.status(500).json({
        success: false,
        message: "Error checking premium status",
        isPremium: false
      });
    }
  });
  
  // Stripe payment intent for one-time payments (unused, as we'll use subscriptions)
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const { amount } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res
        .status(500)
        .json({ message: "Error creating payment intent: " + error.message });
    }
  });
  
  // Create or retrieve a subscription for the user
  app.post('/api/get-or-create-subscription', async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      let user = req.user;
      console.log("Processing subscription request for user:", user.username);
      
      // If user already has a subscription, retrieve it
      if (user.stripeSubscriptionId) {
        try {
          console.log("User has existing subscription ID:", user.stripeSubscriptionId);
          const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId, {
            expand: ['latest_invoice.payment_intent']
          });
          
          // Handle invoice/payment intent
          let clientSecret = null;
          if (typeof subscription.latest_invoice !== 'string') {
            if (subscription.latest_invoice?.payment_intent && 
                typeof subscription.latest_invoice.payment_intent !== 'string') {
              clientSecret = subscription.latest_invoice.payment_intent.client_secret;
            }
          }
          
          res.json({
            subscriptionId: subscription.id,
            clientSecret,
          });
          
          return;
        } catch (err) {
          console.warn("Could not retrieve subscription, continuing with creation:", err);
          // Continue to create a new subscription
        }
      }
      
      // TEMPORARY SOLUTION FOR TESTING: Skip actual Stripe API call and mock success
      // Since we're in development and don't have real Stripe price IDs
      console.log("Creating mock subscription for testing");
      
      // Update the user as premium immediately for testing
      try {
        await storage.updateUserPremiumStatus(user.id, true, new Date(Date.now() + 30 * 24 * 60 * 60 * 1000));
        console.log("User premium status updated successfully");
        
        // Return a fake client secret
        return res.json({
          success: true,
          subscriptionId: "sub_mock_" + Math.random().toString(36).substring(2, 15),
          clientSecret: "pi_mock_secret_" + Math.random().toString(36).substring(2, 15),
        });
      } catch (updateError: any) {
        console.error("Error updating premium status:", updateError);
        throw new Error("Failed to update premium status: " + (updateError.message || "Unknown error"));
      }

      /* COMMENTED OUT REAL IMPLEMENTATION FOR PRODUCTION
      // Create new Stripe customer
      const customer = await stripe.customers.create({
        email: user.email || email,
        name: user.username,
      });
      
      // Save the customer ID to the user record
      const updatedUserWithCustomerId = await storage.updateStripeCustomerId(user.id, customer.id);
      if (updatedUserWithCustomerId) {
        user = updatedUserWithCustomerId;
      }
      
      // Get the price ID from request or use a default
      const { priceId } = req.body; 
      
      // Create a subscription with the price ID
      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price: priceId,
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });
      
      // Update the user record with subscription info
      await storage.updateUserStripeInfo(user.id, {
        stripeCustomerId: customer.id,
        stripeSubscriptionId: subscription.id
      });
      
      // Extract client secret from subscription
      let clientSecret = null;
      if (typeof subscription.latest_invoice !== 'string') {
        if (subscription.latest_invoice?.payment_intent && 
            typeof subscription.latest_invoice.payment_intent !== 'string') {
          clientSecret = subscription.latest_invoice.payment_intent.client_secret;
        }
      }
      
      // Return the client secret to complete the payment
      res.json({
        subscriptionId: subscription.id,
        clientSecret,
      });
      */
    } catch (error: any) {
      console.error("Error creating subscription:", error.message);
      console.error("Full error details:", JSON.stringify(error, null, 2));
      return res.status(400).json({ 
        success: false,
        error: { message: error.message } 
      });
    }
  });
  
  // Webhook for Stripe events like successful payments
  app.post('/api/webhook', async (req, res) => {
    const payload = req.body;
    let event;
    
    // Verify the event came from Stripe
    try {
      const sigHeader = req.headers['stripe-signature'] as string;
      const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
      
      if (endpointSecret) {
        event = stripe.webhooks.constructEvent(payload, sigHeader, endpointSecret);
      } else {
        // For development without webhook signature verification
        event = payload;
      }
    } catch (err: any) {
      console.error(`Webhook signature verification failed: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }
    
    // Handle specific events
    try {
      switch (event.type) {
        case 'customer.subscription.created':
        case 'customer.subscription.updated':
          const subscription = event.data.object;
          
          // Find the user with this subscription ID
          // This would require a new storage method to lookup by stripeSubscriptionId
          // For now we'll handle this through the client-side completion
          console.log(`Subscription ${subscription.id} was ${event.type.split('.')[2]}`);
          break;
          
        case 'invoice.payment_succeeded':
          const invoice = event.data.object;
          // Activate premium features when payment succeeds
          if (invoice.subscription) {
            // Again, we'd need to lookup the user by subscription ID
            console.log(`Payment succeeded for subscription ${invoice.subscription}`);
          }
          break;
          
        case 'customer.subscription.deleted':
          // Handle cancellation
          const canceledSubscription = event.data.object;
          console.log(`Subscription ${canceledSubscription.id} was canceled`);
          break;
          
        default:
          console.log(`Unhandled event type: ${event.type}`);
      }
      
      res.json({ received: true });
    } catch (error) {
      console.error(`Error handling webhook: ${error}`);
      res.status(500).send('Webhook handler failed');
    }
  });

  // ===== Offerings API endpoints =====
  // GET all offerings with optional filters
  app.get("/api/offerings", async (req, res) => {
    try {
      const filters: any = {};
      
      // Apply filters if provided in query parameters
      if (req.query.isNewMemberOffer !== undefined) {
        filters.isNewMemberOffer = req.query.isNewMemberOffer === 'true';
      }
      
      if (req.query.category) {
        filters.category = req.query.category as string;
      }
      
      if (req.query.site) {
        filters.site = req.query.site as string;
      }
      
      const offerings = await storage.getOfferings(filters);
      res.json(offerings);
    } catch (error) {
      console.error("Error fetching offerings:", error);
      res.status(500).send("Error fetching offerings");
    }
  });

  // GET a specific offering
  app.get("/api/offerings/:id", async (req, res) => {
    try {
      const offeringId = parseInt(req.params.id);
      const offering = await storage.getOffering(offeringId);
      
      if (!offering) {
        return res.status(404).send("Offering not found");
      }
      
      res.json(offering);
    } catch (error) {
      res.status(500).send("Error fetching offering");
    }
  });

  // CREATE a new offering (admin only)
  app.post("/api/offerings", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Unauthorized: Admin access required");
    }
    
    try {
      const validatedData = insertOfferingSchema.parse(req.body);
      const offering = await storage.createOffering(validatedData);
      res.status(201).json(offering);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).send("Error creating offering");
    }
  });

  // UPDATE an offering (admin only)
  app.put("/api/offerings/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Unauthorized: Admin access required");
    }
    
    try {
      const offeringId = parseInt(req.params.id);
      const validatedData = updateOfferingSchema.parse(req.body);
      
      const updatedOffering = await storage.updateOffering(
        offeringId,
        validatedData
      );
      
      if (!updatedOffering) {
        return res.status(404).send("Offering not found");
      }
      
      res.json(updatedOffering);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).send("Error updating offering");
    }
  });

  // DELETE an offering (admin only)
  app.delete("/api/offerings/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).send("Unauthorized: Admin access required");
    }
    
    try {
      const offeringId = parseInt(req.params.id);
      const deleted = await storage.deleteOffering(offeringId);
      
      if (!deleted) {
        return res.status(404).send("Offering not found");
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).send("Error deleting offering");
    }
  });

  // CLAIM an offering (copy it to user's rewards)
  app.post("/api/offerings/:id/claim", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    
    try {
      const offeringId = parseInt(req.params.id);
      const offering = await storage.getOffering(offeringId);
      
      if (!offering) {
        return res.status(404).send("Offering not found");
      }
      
      // Create a reward from the offering - use offering title as the reward
      const defaultRewardTitle = `${offering.title || "Promotion"} (${offering.site})`;
      
      const reward = await storage.createReward({
        userId: req.user.id,
        site: offering.site,
        reward: defaultRewardTitle, // Make sure we never have null 
        expiresAt: offering.expiresAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Use offering expiry or default 7 days
        claimed: false,
        category: offering.category || "OTHER",
        confidence: "1.0" // High confidence since it's from our database - stored as string in DB
      });
      
      // If there's a URL, send that back for redirection
      if (offering.url) {
        res.status(201).json({ 
          success: true,
          message: "Offering claimed successfully",
          reward,
          redirectUrl: offering.url
        });
      } else {
        res.status(201).json({ 
          success: true,
          message: "Offering claimed successfully",
          reward
        });
      }
    } catch (error) {
      console.error("Error claiming offering:", error);
      res.status(500).send("Error claiming offering");
    }
  });

  // Extension download page
  app.get('/extension', (req, res) => {
    res.redirect('/extension-download.html');
  });

  // Serve dist directory for downloads
  app.use('/dist', express.static(path.resolve(process.cwd(), 'dist')));

  const httpServer = createServer(app);
  return httpServer;
}
