import { Router } from "express";
import { storage } from "./storage";
import { NotificationStatus, updateNotificationSchema } from "@shared/schema";
import { z } from "zod";
import { checkExpiringRewards, getUserNotificationSettings, initNotificationService, updateUserNotificationSettings } from "./services/notification-service";
import { initSendGrid } from "./services/email-service";

// Create router
export const notificationsRouter = Router();

// Initialize notification service
initNotificationService();

// Get all notifications for the current user
notificationsRouter.get("/api/notifications", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    const userId = req.user.id;
    const statusFilter = req.query.status as string;
    const typeFilter = req.query.type as string;
    
    // Apply filters if provided
    const filters: { status?: string; type?: string } = {};
    if (statusFilter) filters.status = statusFilter;
    if (typeFilter) filters.type = typeFilter;
    
    const notifications = await storage.getNotifications(userId, filters);
    
    return res.status(200).json({ 
      success: true, 
      notifications 
    });
  } catch (error) {
    console.error("Error getting notifications:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error retrieving notifications" 
    });
  }
});

// Get unread count
notificationsRouter.get("/api/notifications/unread-count", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    const userId = req.user.id;
    const count = await storage.getUnreadNotificationsCount(userId);
    
    return res.status(200).json({ 
      success: true, 
      count 
    });
  } catch (error) {
    console.error("Error getting unread count:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error retrieving unread count" 
    });
  }
});

// Mark notification as read
notificationsRouter.patch("/api/notifications/:id/read", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    const userId = req.user.id;
    const notificationId = parseInt(req.params.id, 10);
    
    if (isNaN(notificationId)) {
      return res.status(400).json({ success: false, message: "Invalid notification ID" });
    }
    
    const updatedNotification = await storage.markNotificationAsRead(notificationId, userId);
    
    if (!updatedNotification) {
      return res.status(404).json({ success: false, message: "Notification not found" });
    }
    
    return res.status(200).json({ 
      success: true, 
      notification: updatedNotification 
    });
  } catch (error) {
    console.error("Error marking notification as read:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error updating notification" 
    });
  }
});

// Mark all notifications as read
notificationsRouter.post("/api/notifications/mark-all-read", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    const userId = req.user.id;
    const success = await storage.markAllNotificationsAsRead(userId);
    
    return res.status(200).json({ 
      success,
      message: success ? "All notifications marked as read" : "Failed to mark notifications as read" 
    });
  } catch (error) {
    console.error("Error marking all notifications as read:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error updating notifications" 
    });
  }
});

// Delete a notification
notificationsRouter.delete("/api/notifications/:id", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    const userId = req.user.id;
    const notificationId = parseInt(req.params.id, 10);
    
    if (isNaN(notificationId)) {
      return res.status(400).json({ success: false, message: "Invalid notification ID" });
    }
    
    const success = await storage.deleteNotification(notificationId, userId);
    
    if (!success) {
      return res.status(404).json({ success: false, message: "Notification not found" });
    }
    
    return res.status(200).json({ 
      success: true, 
      message: "Notification deleted successfully" 
    });
  } catch (error) {
    console.error("Error deleting notification:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error deleting notification" 
    });
  }
});

// Get notification settings
notificationsRouter.get("/api/notification-settings", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    const userId = req.user.id;
    const settings = await getUserNotificationSettings(userId);
    
    if (!settings) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    
    return res.status(200).json({ 
      success: true, 
      settings 
    });
  } catch (error) {
    console.error("Error getting notification settings:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error retrieving notification settings" 
    });
  }
});

// Update notification settings
notificationsRouter.patch("/api/notification-settings", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    const userId = req.user.id;
    
    // Validate input
    const schema = z.object({
      notificationsEnabled: z.boolean().optional(),
      emailNotificationsEnabled: z.boolean().optional(),
      pushNotificationsEnabled: z.boolean().optional(),
      expiringRewardsNotificationsEnabled: z.boolean().optional(),
      emailAddress: z.string().email().optional(),
    });

    const validationResult = schema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({ 
        success: false, 
        message: "Invalid settings data", 
        errors: validationResult.error.errors 
      });
    }
    
    const settings = validationResult.data;
    const success = await updateUserNotificationSettings(userId, settings);
    
    if (!success) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    
    // Get updated settings to return
    const updatedSettings = await getUserNotificationSettings(userId);
    
    return res.status(200).json({ 
      success: true, 
      message: "Notification settings updated successfully",
      settings: updatedSettings
    });
  } catch (error) {
    console.error("Error updating notification settings:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error updating notification settings" 
    });
  }
});

// Admin route to manually check for expiring rewards (protected)
notificationsRouter.post("/api/admin/check-expiring-rewards", async (req, res) => {
  try {
    // Only authenticated users for now - we'll add proper admin checks later
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    // In the future, add admin role check when we implement admin roles
    
    const daysThreshold = req.body.daysThreshold || 3;
    
    await checkExpiringRewards(daysThreshold);
    
    return res.status(200).json({ 
      success: true, 
      message: `Checked for rewards expiring within ${daysThreshold} days` 
    });
  } catch (error) {
    console.error("Error checking expiring rewards:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error checking expiring rewards" 
    });
  }
});

// Setup route for email notifications
notificationsRouter.post("/api/notifications/setup-email", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    // Check if SendGrid API key is available
    if (!process.env.SENDGRID_API_KEY) {
      return res.status(503).json({ 
        success: false, 
        message: "Email notifications not available. SendGrid API key not configured." 
      });
    }
    
    // Validate email
    const schema = z.object({
      email: z.string().email()
    });
    
    const validationResult = schema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({ 
        success: false, 
        message: "Invalid email address", 
        errors: validationResult.error.errors 
      });
    }
    
    const { email } = validationResult.data;
    const userId = req.user.id;
    
    // Update user email
    const user = await storage.updateUserEmail(userId, email);
    
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    
    // Initialize SendGrid if not already initialized
    initSendGrid();
    
    // Update user preferences to enable email notifications
    await updateUserNotificationSettings(userId, {
      emailNotificationsEnabled: true,
      notificationsEnabled: true,
      emailAddress: email
    });
    
    return res.status(200).json({ 
      success: true, 
      message: "Email notifications setup successfully" 
    });
  } catch (error) {
    console.error("Error setting up email notifications:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error setting up email notifications" 
    });
  }
});

// Manually process a single notification by ID (for testing/debugging)
// Testing version without authentication for debugging purposes
notificationsRouter.post("/api/debug/process-notification/:id", async (req, res) => {
  try {
    const notificationId = parseInt(req.params.id, 10);
    if (isNaN(notificationId)) {
      return res.status(400).json({ success: false, message: "Invalid notification ID" });
    }
    
    // Get the notification
    const notification = await storage.getNotification(notificationId);
    
    if (!notification) {
      return res.status(404).json({ success: false, message: "Notification not found" });
    }
    
    // Import the needed function
    const { processNotification } = await import('./services/notification-service');
    
    // Process the notification
    console.log(`[notifications] Manual processing of notification ${notificationId}`);
    const success = await processNotification(notification);
    
    return res.status(200).json({ 
      success, 
      message: success ? "Notification processed successfully" : "Failed to process notification" 
    });
  } catch (error) {
    console.error("Error processing notification:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error processing notification" 
    });
  }
});

// Authenticated version for production use
notificationsRouter.post("/api/notifications/process-single/:id", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ success: false, message: "Authentication required" });
    }
    
    const notificationId = parseInt(req.params.id, 10);
    if (isNaN(notificationId)) {
      return res.status(400).json({ success: false, message: "Invalid notification ID" });
    }
    
    // Get the notification
    const notification = await storage.getNotification(notificationId);
    
    if (!notification) {
      return res.status(404).json({ success: false, message: "Notification not found" });
    }
    
    // Import the needed function
    const { processNotification } = await import('./services/notification-service');
    
    // Process the notification
    console.log(`[notifications] Manual processing of notification ${notificationId}`);
    const success = await processNotification(notification);
    
    return res.status(200).json({ 
      success, 
      message: success ? "Notification processed successfully" : "Failed to process notification" 
    });
  } catch (error) {
    console.error("Error processing notification:", error);
    return res.status(500).json({ 
      success: false, 
      message: "Error processing notification" 
    });
  }
});