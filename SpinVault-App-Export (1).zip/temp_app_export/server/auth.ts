import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";
import { z } from "zod";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "spinvault-session-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 7 * 24 * 60 * 60 * 1000, // 1 week
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (err) {
        return done(err);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // User registration
  app.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).send("Username already exists");
      }

      const user = await storage.createUser({
        ...req.body,
        password: await hashPassword(req.body.password),
      });

      req.login(user, (err) => {
        if (err) return next(err);
        // Return user without password
        const { password, ...userWithoutPassword } = user;
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      next(error);
    }
  });

  // User login
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).send("Invalid username or password");
      }
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        const { password, ...userWithoutPassword } = user;
        return res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  // User logout
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  // Get current user
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const { password, ...userWithoutPassword } = req.user;
    res.json(userWithoutPassword);
  });

  // Demo user login
  app.post("/api/demo", async (req, res, next) => {
    try {
      // Check if demo user exists
      let demoUser = await storage.getUserByUsername("demo");
      
      // Create demo user if it doesn't exist
      if (!demoUser) {
        demoUser = await storage.createUser({
          username: "demo",
          password: await hashPassword("demo123"),
        });
        
        // Add sample rewards for the demo user with various expiration times
        const now = new Date();
        
        // Demo reward that expires in 4 hours
        await storage.createReward({
          userId: demoUser.id,
          site: "Bet365",
          reward: "£50 Bonus Match",
          expiresAt: new Date(now.getTime() + 3600 * 4 * 1000),
          category: "DEPOSIT_MATCH",
          confidence: "0.9"
        });
        
        // Demo reward that expires in 2 hours
        await storage.createReward({
          userId: demoUser.id,
          site: "Paddy Power",
          reward: "£5 Cashback",
          expiresAt: new Date(now.getTime() + 3600 * 2 * 1000),
          category: "BONUS_CASH",
          confidence: "0.8"
        });
        
        // Demo reward that expires in 1 hour
        await storage.createReward({
          userId: demoUser.id,
          site: "Mecca Bingo",
          reward: "20 Free Spins",
          expiresAt: new Date(now.getTime() + 3600 * 1000),
          category: "FREE_SPINS",
          confidence: "0.95"
        });
        
        // Demo reward that's nearly expired (5 minutes)
        await storage.createReward({
          userId: demoUser.id,
          site: "William Hill",
          reward: "£10 Free Bet",
          expiresAt: new Date(now.getTime() + 300 * 1000),
          category: "FREE_BET",
          confidence: "0.85"
        });
        
        // Demo reward that's already claimed
        await storage.createReward({
          userId: demoUser.id,
          site: "Coral",
          reward: "100% Deposit Match",
          expiresAt: new Date(now.getTime() + 3600 * 24 * 1000), // 24 hours
          claimed: true,
          category: "DEPOSIT_MATCH",
          confidence: "0.9"
        });
        
        // Demo reward that expires tomorrow
        await storage.createReward({
          userId: demoUser.id,
          site: "Ladbrokes",
          reward: "50 Bonus Spins",
          expiresAt: new Date(now.getTime() + 3600 * 24 * 1000), // 24 hours
          category: "FREE_SPINS",
          confidence: "0.7"
        });
      }
      
      req.login(demoUser, (err) => {
        if (err) return next(err);
        const { password, ...userWithoutPassword } = demoUser;
        res.status(200).json(userWithoutPassword);
      });
    } catch (error) {
      next(error);
    }
  });
}
