/**
 * Routes for scanner integration with the API and Chrome extension
 */
import { Express } from 'express';
import { scanAllSites, savePromoOfferings } from './proxy-scanner';
import { storage } from './storage';
import { RewardCategory } from '@shared/schema';

export function registerScannerRoutes(app: Express): void {
  // API endpoint for detecting rewards from a specific gambling site
  app.post("/api/extension/detect-rewards", async (req, res) => {
    try {
      // Get the site info from the request
      const { site, url, pageContent } = req.body;
      
      if (!site || !url) {
        return res.status(400).json({
          success: false,
          message: "Missing site or URL information"
        });
      }
      
      console.log(`[server] Extension requested reward detection for: ${site}`);
      
      // Check if user is logged in
      const userId = req.isAuthenticated() ? req.user.id : null;
      console.log(`[server] User status: ${userId ? 'Authenticated' : 'Anonymous'}`);
      
      // Even if we don't have page content, we can still check our database for known offers
      const existingOfferings = await storage.getOfferings({ site });
      
      // Format the existing offerings as rewards
      const dbRewards = existingOfferings.map(offering => ({
        site: offering.site,
        reward: offering.title,
        category: offering.category,
        expiresAt: offering.expiresAt,
        notes: offering.description,
        isNewMemberOffer: offering.isNewMemberOffer
      }));
      
      console.log(`[server] Found ${dbRewards.length} existing offers for ${site}`);
      
      // If we have page content, analyze it for additional rewards
      // This would normally use AI, but it's currently hitting rate limits
      let detectedRewards: any[] = [];
      
      // Return combined results
      return res.json({
        success: true,
        rewards: [...dbRewards, ...detectedRewards],
        message: `Found ${dbRewards.length + detectedRewards.length} rewards for ${site}`
      });
    } catch (error) {
      console.error('[server] Error detecting rewards:', error);
      return res.status(500).json({
        success: false,
        message: "Error detecting rewards"
      });
    }
  });
  
  // API endpoint to manually trigger a scan of all gambling sites
  app.post("/api/admin/trigger-scan", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized"
      });
    }
    
    // In a full implementation, we'd check if user is admin
    // For now, we'll allow any authenticated user to trigger a scan
    
    try {
      console.log(`[server] Manual scan triggered by user ${req.user.id}`);
      
      // Start scan in the background
      setTimeout(async () => {
        try {
          const rewards = await scanAllSites();
          await savePromoOfferings(rewards);
          console.log(`[server] Manual scan completed. Found ${rewards.length} rewards.`);
        } catch (error) {
          console.error('[server] Error in manual scan:', error);
        }
      }, 0);
      
      // Immediately return success
      return res.json({
        success: true,
        message: "Scan started in the background"
      });
    } catch (error) {
      console.error('[server] Error triggering scan:', error);
      return res.status(500).json({
        success: false,
        message: "Error triggering scan"
      });
    }
  });
  
  // API endpoint to get all detected offerings for a site
  app.get("/api/public/offerings", async (req, res) => {
    try {
      const { site } = req.query;
      
      // Build filter based on query params
      const filter: any = {};
      if (site) {
        filter.site = site;
      }
      
      const offerings = await storage.getOfferings(filter);
      
      return res.json({
        success: true,
        offerings
      });
    } catch (error) {
      console.error('[server] Error fetching offerings:', error);
      return res.status(500).json({
        success: false,
        message: "Error fetching offerings"
      });
    }
  });
  
  // API endpoint to sync user's personalized rewards with the extension
  app.get("/api/extension/sync-rewards", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized"
      });
    }
    
    try {
      const userId = req.user.id;
      
      // Get the user's rewards
      const rewards = await storage.getRewards(userId);
      
      // Also get public offerings
      const offerings = await storage.getOfferings();
      
      return res.json({
        success: true,
        rewards,
        offerings
      });
    } catch (error) {
      console.error('[server] Error syncing rewards:', error);
      return res.status(500).json({
        success: false,
        message: "Error syncing rewards"
      });
    }
  });
  
  // API endpoint to submit a reward from the extension
  app.post("/api/extension/submit-reward", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized"
      });
    }
    
    try {
      const userId = req.user.id;
      const { site, reward, category, expiresAt, notes, url } = req.body;
      
      if (!site || !reward) {
        return res.status(400).json({
          success: false,
          message: "Missing required fields"
        });
      }
      
      // Create a new reward
      const newReward = await storage.createReward({
        userId,
        site,
        reward,
        category: category || RewardCategory.OTHER,
        expiresAt: expiresAt ? new Date(expiresAt) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        offerLink: notes || '',
        claimed: false
      });
      
      return res.json({
        success: true,
        reward: newReward,
        message: "Reward submitted successfully"
      });
    } catch (error) {
      console.error('[server] Error submitting reward:', error);
      return res.status(500).json({
        success: false,
        message: "Error submitting reward"
      });
    }
  });
}