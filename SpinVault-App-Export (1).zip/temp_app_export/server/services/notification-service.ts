import { storage } from "../storage";
import { initSendGrid } from "./email-service";
import { 
  NotificationType, 
  NotificationChannel, 
  NotificationStatus,
  InsertNotification,
  Notification,
  users
} from "@shared/schema";
import { db } from "../db";
import { eq } from "drizzle-orm";
import cron from "node-cron";

// Tracking variable for notification service
let notificationServiceInitialized = false;
let expiringRewardsNotificationsEnabled = true;
const DEFAULT_EXPIRY_NOTIFICATION_THRESHOLD = 3; // Days before expiry to notify

// Process any pending notifications scheduled to be sent
async function processPendingNotifications() {
  try {
    console.log('[notifications] Processing pending notifications...');
    
    // Get all pending notifications that are scheduled to be sent now or in the past
    const pendingNotifications = await storage.getPendingNotifications();
    
    if (pendingNotifications.length === 0) {
      console.log('[notifications] No pending notifications to process');
      return;
    }
    
    console.log(`[notifications] Processing ${pendingNotifications.length} pending notifications`);
    
    for (const notification of pendingNotifications) {
      await processNotification(notification);
    }
  } catch (error) {
    console.error('[notifications] Error processing pending notifications:', error);
  }
}

// Process a single notification based on its type and channel
async function processNotification(notification: Notification): Promise<boolean> {
  try {
    console.log(`[notifications] Processing notification ${notification.id} of type ${notification.type}`);
    
    // Different handling based on notification channel
    let success = false;
    
    switch (notification.channel) {
      case NotificationChannel.EMAIL:
        success = await processEmailNotification(notification);
        break;
      
      case NotificationChannel.PUSH:
        success = await processPushNotification(notification);
        break;
      
      case NotificationChannel.IN_APP:
        // In-app notifications are already created, just mark as sent
        success = true;
        break;
      
      default:
        console.warn(`[notifications] Unsupported notification channel: ${notification.channel}`);
        success = false;
    }
    
    // Update notification status based on processing result
    if (success) {
      await storage.updateNotification(notification.id, {
        status: NotificationStatus.SENT,
        sentAt: new Date()
      });
      console.log(`[notifications] Successfully processed notification ${notification.id}`);
    } else {
      await storage.updateNotification(notification.id, {
        status: NotificationStatus.FAILED
      });
      console.error(`[notifications] Failed to process notification ${notification.id}`);
    }
    
    return success;
  } catch (error) {
    console.error(`[notifications] Error processing notification ${notification.id}:`, error);
    
    // Update notification as failed
    await storage.updateNotification(notification.id, {
      status: NotificationStatus.FAILED
    });
    
    return false;
  }
}

// Process email notifications
async function processEmailNotification(notification: Notification): Promise<boolean> {
  try {
    const user = await storage.getUser(notification.userId);
    
    if (!user || !user.email) {
      console.log(`[notifications] Cannot send email: User ${notification.userId} not found or has no email`);
      return false;
    }
    
    // Import email service only when needed to avoid circular dependencies
    const { sendEmail, generateEmailHtml } = await import('./email-service');
    
    // Add recipient email to metadata for tracking purposes
    const metadata = typeof notification.metadata === 'string' 
      ? JSON.parse(notification.metadata) 
      : (notification.metadata || {});
      
    // Update metadata with recipient email
    const updatedMetadata = {
      ...metadata,
      recipientEmail: user.email
    };
    
    // Update notification with the recipient email
    await storage.updateNotification(notification.id, {
      metadata: updatedMetadata
    });
    
    // Generate email content
    const html = generateEmailHtml(notification);
    
    // Send email
    const success = await sendEmail(
      user.email,
      notification.title,
      html
    );
    
    return success;
  } catch (error) {
    console.error('[notifications] Error processing email notification:', error);
    return false;
  }
}

// Process push notifications - placeholder for future implementation
async function processPushNotification(notification: Notification): Promise<boolean> {
  console.log('[notifications] Push notifications not yet implemented');
  return false;
}

// Create and schedule notifications for rewards about to expire
async function createExpiringRewardNotifications(daysThreshold: number = DEFAULT_EXPIRY_NOTIFICATION_THRESHOLD) {
  try {
    if (!expiringRewardsNotificationsEnabled) {
      console.log('[notifications] Expiring rewards notifications are disabled');
      return;
    }
    
    console.log(`[notifications] Checking for rewards expiring in ${daysThreshold} days...`);
    
    // Get rewards expiring within the threshold
    const expiringRewards = await storage.getExpiringRewardsForNotification(daysThreshold);
    
    if (expiringRewards.length === 0) {
      console.log('[notifications] No rewards expiring soon');
      return;
    }
    
    console.log(`[notifications] Found ${expiringRewards.length} rewards expiring soon`);
    
    // Group by user to avoid sending too many notifications
    const rewardsByUser = expiringRewards.reduce<Record<number, any[]>>((acc, reward) => {
      const userId = reward.userId;
      if (!acc[userId]) {
        acc[userId] = [];
      }
      acc[userId].push(reward);
      return acc;
    }, {});
    
    // Create notifications for each user
    for (const [userId, userRewards] of Object.entries(rewardsByUser)) {
      const userIdNum = parseInt(userId, 10);
      const user = await storage.getUser(userIdNum);
      
      if (!user) {
        console.log(`[notifications] User ${userId} not found, skipping notifications`);
        continue;
      }
      
      // Check user notification preferences
      // This is a placeholder - we'll add proper user preferences later
      const userPreferences = user.preferences as Record<string, any> || {};
      const notificationsEnabled = userPreferences.notificationsEnabled !== false;
      
      if (!notificationsEnabled) {
        console.log(`[notifications] Notifications are disabled for user ${userId}`);
        continue;
      }
      
      // Different notification strategies based on number of expiring rewards
      if (userRewards.length === 1) {
        // Single reward notification
        const reward = userRewards[0];
        
        // Format notification content
        const title = `Your ${reward.site} reward is expiring soon!`;
        const message = `Your reward "${reward.reward}" from ${reward.site} is expiring in ${Math.floor(reward.daysUntilExpiry)} days. Don't miss out!`;
        
        // Create in-app notification
        await createNotification({
          userId: userIdNum,
          type: NotificationType.REWARD_EXPIRING,
          channel: NotificationChannel.IN_APP,
          title,
          message,
          status: NotificationStatus.SENT, // In-app notifications are sent immediately
          relatedId: reward.rewardId,
          metadata: { daysUntilExpiry: reward.daysUntilExpiry }
        });
        
        // If user has email, schedule email notification
        if (user.email) {
          await createNotification({
            userId: userIdNum,
            type: NotificationType.REWARD_EXPIRING,
            channel: NotificationChannel.EMAIL,
            title,
            message,
            relatedId: reward.rewardId,
            metadata: { daysUntilExpiry: reward.daysUntilExpiry },
            scheduledFor: new Date() // Send immediately
          });
        }
      } else {
        // Multiple rewards notification (batch notification)
        const expiringCount = userRewards.length;
        
        // Format notification content for multiple rewards
        const title = `${expiringCount} rewards expiring soon!`;
        const message = `You have ${expiringCount} rewards expiring soon. Log in to see your expiring rewards and claim them before they expire!`;
        
        // Create in-app notification
        await createNotification({
          userId: userIdNum,
          type: NotificationType.REWARD_EXPIRING,
          channel: NotificationChannel.IN_APP,
          title,
          message,
          status: NotificationStatus.SENT, // In-app notifications are sent immediately
          metadata: { 
            rewardCount: expiringCount,
            rewardIds: userRewards.map((r: any) => r.rewardId)
          }
        });
        
        // If user has email, schedule email notification
        if (user.email) {
          await createNotification({
            userId: userIdNum,
            type: NotificationType.REWARD_EXPIRING,
            channel: NotificationChannel.EMAIL,
            title,
            message,
            metadata: { 
              rewardCount: expiringCount,
              rewardIds: userRewards.map((r: any) => r.rewardId),
              rewards: userRewards.map((r: any) => ({
                id: r.rewardId,
                site: r.site,
                reward: r.reward,
                expiresAt: r.expiresAt,
                daysUntilExpiry: r.daysUntilExpiry
              }))
            },
            scheduledFor: new Date() // Send immediately
          });
        }
      }
    }
    
    console.log('[notifications] Created expiring reward notifications');
  } catch (error) {
    console.error('[notifications] Error creating expiring reward notifications:', error);
  }
}

// Helper function to create a notification
async function createNotification(notification: InsertNotification): Promise<Notification | null> {
  try {
    return await storage.createNotification(notification);
  } catch (error) {
    console.error('[notifications] Error creating notification:', error);
    return null;
  }
}

// Initialize the notification service
export function initNotificationService() {
  if (notificationServiceInitialized) {
    console.log('[notifications] Notification service already initialized');
    return true;
  }
  
  console.log('[notifications] Initializing notification service...');
  
  // Initialize SendGrid for email notifications
  const sendGridInitialized = initSendGrid();
  
  // Schedule notification processing (every 5 minutes)
  cron.schedule('*/5 * * * *', async () => {
    console.log('[notifications] Running scheduled notification processing');
    await processPendingNotifications();
  });
  
  // Schedule expiring rewards check (once a day at 9 AM)
  cron.schedule('0 9 * * *', async () => {
    console.log('[notifications] Running daily expiring rewards check');
    await createExpiringRewardNotifications();
  });
  
  // Run initial processing on startup
  processPendingNotifications().catch(console.error);
  
  notificationServiceInitialized = true;
  console.log('[notifications] Notification service initialized successfully');
  
  return true;
}

// Enable or disable expiring rewards notifications
export function setExpiringRewardsNotificationsEnabled(enabled: boolean) {
  expiringRewardsNotificationsEnabled = enabled;
  console.log(`[notifications] Expiring rewards notifications ${enabled ? 'enabled' : 'disabled'}`);
}

// Manually trigger expiring rewards check
export async function checkExpiringRewards(daysThreshold: number = DEFAULT_EXPIRY_NOTIFICATION_THRESHOLD) {
  return await createExpiringRewardNotifications(daysThreshold);
}

// Get notification settings for a user
export async function getUserNotificationSettings(userId: number) {
  const user = await storage.getUser(userId);
  if (!user) {
    return null;
  }
  
  // Extract notification settings from user preferences
  const preferences = user.preferences as any || {};
  return {
    notificationsEnabled: preferences.notificationsEnabled !== false,
    emailNotificationsEnabled: !!user.email && (preferences.emailNotificationsEnabled !== false),
    pushNotificationsEnabled: preferences.pushNotificationsEnabled === true,
    expiringRewardsNotificationsEnabled: preferences.expiringRewardsNotificationsEnabled !== false,
    emailAddress: user.email
  };
}

// Update notification settings for a user
export async function updateUserNotificationSettings(
  userId: number, 
  settings: { 
    notificationsEnabled?: boolean; 
    emailNotificationsEnabled?: boolean;
    pushNotificationsEnabled?: boolean;
    expiringRewardsNotificationsEnabled?: boolean;
    emailAddress?: string;
  }
) {
  const user = await storage.getUser(userId);
  if (!user) {
    return false;
  }
  
  // Update email address if provided
  if (settings.emailAddress !== undefined) {
    await storage.updateUserEmail(userId, settings.emailAddress);
  }
  
  // Extract existing preferences
  const preferences = user.preferences as any || {};
  
  // Update preferences with new settings
  const updatedPreferences = {
    ...preferences,
    notificationsEnabled: 
      settings.notificationsEnabled !== undefined 
        ? settings.notificationsEnabled 
        : preferences.notificationsEnabled !== false,
    emailNotificationsEnabled: 
      settings.emailNotificationsEnabled !== undefined 
        ? settings.emailNotificationsEnabled 
        : preferences.emailNotificationsEnabled !== false,
    pushNotificationsEnabled: 
      settings.pushNotificationsEnabled !== undefined 
        ? settings.pushNotificationsEnabled 
        : preferences.pushNotificationsEnabled === true,
    expiringRewardsNotificationsEnabled: 
      settings.expiringRewardsNotificationsEnabled !== undefined 
        ? settings.expiringRewardsNotificationsEnabled 
        : preferences.expiringRewardsNotificationsEnabled !== false
  };
  
  // Update user preferences
  await db.update(users)
    .set({ preferences: updatedPreferences })
    .where(eq(users.id, userId));
  
  return true;
}

// Export processNotification for testing
export { processNotification, processPendingNotifications };