/**
 * Daily Scanning Service for Gambling Promotions
 * 
 * This service runs on a schedule to scan popular gambling websites
 * and automatically detect new offers and promotions, storing them in the offerings table.
 */

import cron from 'node-cron';
import axios from 'axios';
import * as cheerio from 'cheerio';
import OpenAI from "openai";
import { log } from '../vite';
import { storage } from '../storage';
import { db } from '../db';
import { offerings } from '@shared/schema';
import { RewardCategory } from '@shared/schema';
import { and, eq } from 'drizzle-orm';
import { analyzeRewardValue } from '../ai/reward-analyzer';

// Initialize OpenAI with API key
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Sites to scan for offers (expand as needed)
const SITES_TO_SCAN = [
  {
    name: 'Bet365',
    url: 'https://www.bet365.com/promotions',
    selectors: {
      promotions: '.promotion-item',
      title: '.promotion-title',
      description: '.promotion-description',
      expiry: '.promotion-expiry'
    }
  },
  {
    name: 'Paddy Power',
    url: 'https://www.paddypower.com/promotions',
    selectors: {
      promotions: '.promotion',
      title: '.promotion__title',
      description: '.promotion__desc',
      expiry: '.promotion__dates'
    }
  },
  {
    name: 'Sky Bet',
    url: 'https://www.skybet.com/promotions',
    selectors: {
      promotions: '.promotion-card',
      title: '.promotion-card__title',
      description: '.promotion-card__description',
      expiry: '.promotion-card__footer'
    }
  },
  {
    name: 'William Hill',
    url: 'https://www.williamhill.com/promotions',
    selectors: {
      promotions: '.promotion-card',
      title: 'h3',
      description: '.promotion-text',
      expiry: '.promotion-dates'
    }
  },
  {
    name: 'Ladbrokes',
    url: 'https://www.ladbrokes.com/promotions',
    selectors: {
      promotions: '.promotion-container',
      title: '.promotion-title',
      description: '.promotion-description',
      expiry: '.promotion-dates'
    }
  }
];

/**
 * Processes text with OpenAI to determine if it contains a gambling reward/offer
 */
async function processWithAI(title: string, description: string, site: string): Promise<{
  isReward: boolean;
  category: string;
  confidence: number;
  valueEstimate: number | null;
  isNewMemberOffer: boolean;
}> {
  try {
    // Use OpenAI to analyze text and extract reward information
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are a specialized AI for analyzing gambling site promotions and rewards. 
                   Extract and categorize the following reward details accurately.`
        },
        {
          role: "user",
          content: `Analyze this gambling site promotion from ${site}:\n
                   Title: ${title}\n
                   Description: ${description}\n
                   
                   Identify if this is a gambling reward/offer, what category it belongs to, and extract key details.
                   Respond with JSON in this format:
                   {
                     "isReward": boolean, // Is this a valid gambling reward/offer?
                     "category": string, // One of: "FREE_SPINS", "BONUS_CASH", "DEPOSIT_MATCH", "FREE_BET", "BINGO_TICKETS", "LOYALTY_POINTS", "OTHER"
                     "confidence": number, // 0-1 score of how confident you are in this classification
                     "valueEstimate": number or null, // Estimated monetary value in GBP if detectable, null if not
                     "isNewMemberOffer": boolean // Is this specifically for new customers/sign-ups?
                   }`
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content);

    return {
      isReward: result.isReward,
      category: result.category,
      confidence: result.confidence,
      valueEstimate: result.valueEstimate,
      isNewMemberOffer: result.isNewMemberOffer
    };
  } catch (error) {
    console.error("Error processing with AI:", error);
    return {
      isReward: false,
      category: "OTHER",
      confidence: 0,
      valueEstimate: null,
      isNewMemberOffer: false
    };
  }
}

/**
 * Parse an expiry date from common date formats
 */
function parseExpiryDate(text: string): Date | null {
  // Try to extract common date patterns
  const dateRegex = /(\d{1,2}[\/\.\-]\d{1,2}[\/\.\-]\d{2,4})|(\d{1,2}(?:st|nd|rd|th)? [A-Za-z]+ \d{4})|(\d{4}-\d{2}-\d{2})/;
  const match = text.match(dateRegex);
  
  if (match) {
    return new Date(match[0]);
  }
  
  // Default to 30 days from now if no date found
  const date = new Date();
  date.setDate(date.getDate() + 30);
  return date;
}

/**
 * Scan a single site for promotions
 */
async function scanSite(site: typeof SITES_TO_SCAN[0]): Promise<any[]> {
  try {
    log(`Scanning ${site.name} for promotions...`, 'scanner');
    
    // Add more headers to mimic a real browser and avoid geo-restrictions
    const response = await axios.get(site.url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Sec-Ch-Ua': '"Chromium";v="112", "Google Chrome";v="112"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1'
      },
      timeout: 10000, // 10 second timeout
      maxRedirects: 5
    });
    
    // Log success
    log(`Successfully accessed ${site.name}`, 'scanner');
    
    // Check for redirect to geo-blocking page
    if (response.data.includes('unavailable in your location') || 
        response.data.includes('access denied') || 
        response.data.includes('not available')) {
      log(`Geo-restriction detected for ${site.name}`, 'scanner');
      return [];
    }
    
    const $ = cheerio.load(response.data);
    const promotions = [];
    
    // Basic page validity check
    if ($(site.selectors.promotions).length === 0) {
      log(`No promotions found on ${site.name} - potential page structure change or blocking`, 'scanner');
      
      // Save page content for debugging if needed
      // fs.writeFileSync(`debug-${site.name.toLowerCase()}.html`, response.data);
      
      return [];
    }
    
    // Extract promotion data
    $(site.selectors.promotions).each((i, el) => {
      try {
        const title = $(el).find(site.selectors.title).text().trim();
        const description = $(el).find(site.selectors.description).text().trim();
        const expiryText = $(el).find(site.selectors.expiry).text().trim();
        
        // Only process if we have at least a title
        if (title) {
          promotions.push({
            title,
            description,
            expiryText
          });
        }
      } catch (err) {
        // Silently continue to next element
      }
    });
    
    log(`Found ${promotions.length} promotions on ${site.name}`, 'scanner');
    return promotions;
  } catch (error: any) {
    // More detailed error logging
    if (error.response) {
      // The request was made and the server responded with a status code
      log(`Error scanning ${site.name}: Status ${error.response.status}`, 'scanner');
    } else if (error.request) {
      // The request was made but no response was received
      log(`Error scanning ${site.name}: No response received - network issue`, 'scanner');
    } else {
      // Something happened in setting up the request
      log(`Error scanning ${site.name}: ${error.message}`, 'scanner');
    }
    return [];
  }
}

// Fallback predefined rewards for demonstration purposes
const FALLBACK_REWARDS = [
  {
    site: 'Bet365',
    title: 'Welcome Bonus: 100% Match up to £50',
    description: 'New customers only. Min deposit £5. Bet Credits available for use upon settlement of bets to value of qualifying deposit. Min odds, bet and payment method exclusions apply.',
    expiryText: '30 days from registration',
    category: RewardCategory.DEPOSIT_MATCH,
    confidence: '0.95',
    isNewMemberOffer: true,
    value: '£50'
  },
  {
    site: 'Paddy Power',
    title: '£10 Risk Free First Bet',
    description: 'New customers only. Place your FIRST bet on any sportsbook market and if it loses we will refund your stake in CASH. Max refund for this offer is £10.',
    expiryText: '14 days after registration',
    category: RewardCategory.FREE_BET,
    confidence: '0.92',
    isNewMemberOffer: true,
    value: '£10'
  },
  {
    site: 'William Hill',
    title: '50 Free Spins on Selected Slots',
    description: 'Opt in required. Free spins on selected games only. Wagering and terms apply.',
    expiryText: '7 days',
    category: RewardCategory.FREE_SPINS,
    confidence: '0.89',
    isNewMemberOffer: false,
    value: '£5'
  },
  {
    site: 'Coral',
    title: 'Bet £5 Get £20 in Free Bets',
    description: 'New customer offer. Place a single £5 Sportsbook bet and get £20 in free bets. Valid for 7 days on selected bets with odds of 1.5 or greater.',
    expiryText: '7 days',
    category: RewardCategory.FREE_BET,
    confidence: '0.94',
    isNewMemberOffer: true,
    value: '£20'
  },
  {
    site: 'Ladbrokes',
    title: '£20 in Free Bets When You Bet £5',
    description: 'New customers only. 18+. Min qualifying bet £5 at odds of 1/2 or greater. Free Bets credited within 24 hours and valid for 7 days.',
    expiryText: '7 days after credited',
    category: RewardCategory.FREE_BET,
    confidence: '0.92',
    isNewMemberOffer: true,
    value: '£20'
  }
];

/**
 * Main function to scan all sites and save detected offers
 * @export - Exported to allow manual triggering
 */
export async function scanAllSites() {
  log('Starting daily scan of gambling sites for promotions...', 'scanner');
  
  let totalDetectedRewards = 0;
  
  // First try to scan real sites
  for (const site of SITES_TO_SCAN) {
    try {
      const promotions = await scanSite(site);
      
      for (const promo of promotions) {
        try {
          // Use AI to analyze and classify the promotion
          const analysis = await processWithAI(
            promo.title, 
            promo.description, 
            site.name
          );
          
          // Only save if confident this is a reward
          if (analysis.isReward && analysis.confidence > 0.7) {
            // Check if we already have this offer
            const existingOffers = await db.select().from(offerings).where(
              and(
                eq(offerings.site, site.name),
                eq(offerings.title, promo.title)
              )
            );
            
            if (existingOffers.length === 0) {
              // Parse or generate expiry date
              const expiryDate = parseExpiryDate(promo.expiryText);
              
              // Save the new offering
              await storage.createOffering({
                site: site.name,
                title: promo.title,
                category: analysis.category as RewardCategory,
                description: promo.description,
                value: `£${analysis.valueEstimate}`,
                requirements: null, // Would need more sophisticated parsing
                detectedAt: new Date(),
                expiresAt: expiryDate,
                isNewMemberOffer: analysis.isNewMemberOffer,
                url: site.url,
                isLimitedTime: true
              });
              
              totalDetectedRewards++;
              log(`New offer detected: ${promo.title} from ${site.name}`, 'scanner');
            }
          }
        } catch (error) {
          console.error(`Error processing promotion from ${site.name}:`, error);
        }
      }
    } catch (error) {
      console.error(`Error processing site ${site.name}:`, error);
    }
  }
  
  // Check the current database
  const existingOffers = await db.select().from(offerings);
  
  // If we couldn't detect any offers from real sites and we have no existing offerings,
  // use the fallbacks to ensure we have demo data
  if (totalDetectedRewards === 0 && existingOffers.length === 0) {
    log('No rewards detected from live sites. Adding fallback rewards for demonstration.', 'scanner');
    
    for (const fallback of FALLBACK_REWARDS) {
      try {
        // Parse or generate expiry date
        const expiryDate = parseExpiryDate(fallback.expiryText);
        
        // Save the fallback offering
        await storage.createOffering({
          site: fallback.site,
          title: fallback.title,
          category: fallback.category,
          description: fallback.description,
          value: fallback.value,
          requirements: null,
          detectedAt: new Date(),
          expiresAt: expiryDate,
          isNewMemberOffer: fallback.isNewMemberOffer,
          url: SITES_TO_SCAN.find(site => site.name === fallback.site)?.url || 'https://example.com',
          isLimitedTime: true
        });
        
        log(`Added fallback offer: ${fallback.title} from ${fallback.site}`, 'scanner');
      } catch (error) {
        console.error(`Error adding fallback offer from ${fallback.site}:`, error);
      }
    }
  }
  
  log(`Completed daily scan of gambling sites. ${totalDetectedRewards} new offers detected.`, 'scanner');
}

/**
 * Start the scheduler for daily scanning
 * 
 * Schedule explanation:
 * - Runs at 02:00 AM every day (when server traffic is low)
 * - '0 2 * * *' = minute 0 of hour 2, any day, any month, any day of week
 */
export function startDailyScanner() {
  log('Initializing daily reward scanning service...', 'scanner');
  
  // Schedule the job to run at 2:00 AM daily
  cron.schedule('0 2 * * *', async () => {
    try {
      await scanAllSites();
    } catch (error) {
      console.error('Error in daily scanner:', error);
    }
  });
  
  // Also run once at startup to ensure we have the latest offers
  setTimeout(() => {
    scanAllSites().catch(err => {
      console.error('Error running initial scan:', err);
    });
  }, 5000); // Wait 5 seconds after server start to run the scan
  
  log('Daily reward scanning service initialized successfully', 'scanner');
}