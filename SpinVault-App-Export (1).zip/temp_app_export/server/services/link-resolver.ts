/**
 * Link Resolver Service
 * 
 * This service helps resolve gambling site offer links to ensure they point
 * to the correct specific promotion pages rather than just the site homepage.
 * 
 * It maintains the most accurate and up-to-date information by:
 * 1. Checking for direct promotion links
 * 2. Analyzing page content to find exact matching promotions
 * 3. Verifying link validity before returning
 * 4. Adding cache invalidation after 4 hours to ensure freshness
 */

import axios from 'axios';
import * as cheerio from 'cheerio';
import { log } from '../vite';

// Cache for resolved URLs with a 4-hour expiry to ensure freshness
interface CacheEntry {
  url: string;
  timestamp: number;
}

const linkCache: Record<string, CacheEntry> = {}; 
const CACHE_EXPIRY_MS = 4 * 60 * 60 * 1000; // 4 hours

interface SiteConfig {
  domain: string;
  offerPattern: RegExp;
  fallbackPattern?: RegExp;
  promoPath: string;
  promoIdParam?: string;
  requiresAuth?: boolean;
}

// Configuration for major gambling sites and their promotion URL structures
const siteConfigs: Record<string, SiteConfig> = {
  'Bet365': {
    domain: 'bet365.com',
    offerPattern: /(?:promo|offer|bonus)[=\/]([a-zA-Z0-9_-]+)/i,
    fallbackPattern: /([a-zA-Z0-9_-]{6,})/i,
    promoPath: '/promotions',
    promoIdParam: 'offer',
    requiresAuth: true
  },
  'Paddy Power': {
    domain: 'paddypower.com',
    offerPattern: /(?:promotion|promo)[=\/]([a-zA-Z0-9_-]+)/i,
    promoPath: '/promotions',
    requiresAuth: true
  },
  'Sky Bet': {
    domain: 'skybet.com',
    offerPattern: /(?:promotion|offer)[=\/]([a-zA-Z0-9_-]+)/i,
    promoPath: '/promotions',
    promoIdParam: 'id'
  },
  'William Hill': {
    domain: 'williamhill.com',
    offerPattern: /(?:promotion|p)[=\/]([a-zA-Z0-9_-]+)/i,
    promoPath: '/promotions',
    promoIdParam: 'pid'
  },
  'Ladbrokes': {
    domain: 'ladbrokes.com',
    offerPattern: /(?:promo|offer)[=\/]([a-zA-Z0-9_-]+)/i,
    promoPath: '/promotions'
  },
  'Coral': {
    domain: 'coral.co.uk',
    offerPattern: /(?:promotion|offer)[=\/]([a-zA-Z0-9_-]+)/i,
    promoPath: '/promotions'
  },
  'Betfred': {
    domain: 'betfred.com',
    offerPattern: /(?:promo|promotions)[=\/]([a-zA-Z0-9_-]+)/i,
    promoPath: '/promotions'
  },
  'Mecca Bingo': {
    domain: 'meccabingo.com',
    offerPattern: /(?:offer|promotion)[=\/]([a-zA-Z0-9_-]+)/i,
    promoPath: '/promotions'
  },
  '888Casino': {
    domain: '888casino.com',
    offerPattern: /(?:offer|bonus)[=\/]([a-zA-Z0-9_-]+)/i,
    promoPath: '/promotions'
  },
  'Heart Bingo': {
    domain: 'heartbingo.co.uk',
    offerPattern: /(?:offer|promotion)[=\/]([a-zA-Z0-9_-]+)/i,
    promoPath: '/promotions'
  }
};

/**
 * Attempts to transform a generic URL into a specific promotion URL
 * 
 * @param site The gambling site name
 * @param url The URL to transform (can be generic or specific)
 * @param offerTitle Optional title to help identify the correct offer
 * @returns A properly formatted promotion URL
 */
export async function resolveOfferLink(site: string, url: string, offerTitle?: string): Promise<string> {
  try {
    // Create a cache key from the inputs
    const cacheKey = `${site}:${url}:${offerTitle || ''}`;
    
    // Check cache first
    const now = Date.now();
    const cachedEntry = linkCache[cacheKey];
    if (cachedEntry && (now - cachedEntry.timestamp) < CACHE_EXPIRY_MS) {
      log(`Using cached URL for ${site}:${offerTitle || 'No title'}`, 'link-resolver');
      return cachedEntry.url;
    }
    
    // Return as-is if already seems to be a specific promotion URL
    if (url.includes('promotion') || url.includes('promo') || url.includes('offer') || url.includes('bonus')) {
      // This seems to be already a specific offer URL, update the cache and return it
      linkCache[cacheKey] = { url, timestamp: now };
      return url;
    }

    const config = siteConfigs[site];
    if (!config) {
      // If no specific configuration, return the URL as-is
      return url;
    }

    // Ensure URL has protocol
    if (!url.startsWith('http')) {
      url = `https://${url}`;
    }

    // Check if URL is for the correct domain
    if (!url.includes(config.domain)) {
      // URL doesn't match expected domain, so try to create one based on config
      url = `https://www.${config.domain}${config.promoPath}`;
    }

    // For sites requiring authentication, we can't scrape for specific promotion links,
    // but we can still try to form a more accurate URL
    if (config.requiresAuth && offerTitle) {
      // Extract potential offer ID from the title if available
      const idMatch = offerTitle.match(/\b([A-Z0-9]{5,})\b/i);
      if (idMatch && idMatch[1]) {
        const potentialId = idMatch[1];
        const promotionUrl = `https://www.${config.domain}${config.promoPath}`;
        
        // If we have a promoIdParam, try to construct a URL with it
        if (config.promoIdParam) {
          const specificUrl = `${promotionUrl}?${config.promoIdParam}=${potentialId}`;
          linkCache[cacheKey] = { url: specificUrl, timestamp: now };
          return specificUrl;
        }
      }
      
      // If no ID found or no param to use, return generic URL
      linkCache[cacheKey] = { url, timestamp: now };
      return url;
    }

    // Try to scrape the promotions page to find the specific offer
    if (offerTitle) {
      // First, try to validate the URL - don't waste time scraping invalid URLs
      const validation = await validateOfferLink(url);
      if (!validation.valid) {
        log(`URL for ${site} is not valid: ${validation.message}`, 'link-resolver');
        // Fall back to the promotions page
        const fallbackUrl = `https://www.${config.domain}${config.promoPath}`;
        linkCache[cacheKey] = { url: fallbackUrl, timestamp: now };
        return fallbackUrl;
      }
      
      try {
        log(`Scraping promotion page for ${site}: ${url}`, 'link-resolver');
        const response = await axios.get(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html',
            'Accept-Language': 'en-US,en;q=0.9'
          },
          timeout: 7000 // Increased timeout for more reliability
        });

        if (response.status === 200) {
          const $ = cheerio.load(response.data);
          
          // First, look for exact or close matches in link text
          let bestMatch: {el: any, score: number} | null = null;
          
          // Convert offer title to lowercase for comparison and remove common filler words
          const normalizedOfferTitle = offerTitle.toLowerCase()
            .replace(/\b(get|up|to|free|offer|promotion|promo|bonus|exclusive|limited|time|only|deposit)\b/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
          
          // Look for links that might contain the offer
          $('a').each((_, el) => {
            const href = $(el).attr('href');
            if (!href) return;
            
            // Get both the link text and any text in child elements
            const linkText = $(el).text().toLowerCase();
            const childText = $(el).find('*').text().toLowerCase();
            const fullText = `${linkText} ${childText}`;
            
            // Skip navigation, login, and other common non-offer links
            if (linkText.includes('login') || linkText.includes('sign in') || 
                linkText.includes('register') || linkText.includes('home') ||
                linkText.includes('support') || linkText.length < 5) {
              return;
            }
            
            // Calculate match score based on word overlap
            const offerWords = normalizedOfferTitle.split(' ').filter(w => w.length > 2);
            let matchCount = 0;
            
            offerWords.forEach(word => {
              if (fullText.includes(word)) matchCount++;
            });
            
            const score = matchCount / offerWords.length;
            
            // If we have a good match and it looks like a promotion link
            if (score > 0.5 && (
                href.includes('promotion') || 
                href.includes('offer') || 
                href.includes('bonus') || 
                config.offerPattern.test(href))) {
              
              if (!bestMatch || score > bestMatch.score) {
                bestMatch = { el, score };
              }
            }
          });
          
          if (bestMatch) {
            let promoLink = $(bestMatch.el).attr('href');
            
            // Make sure the link is absolute
            if (promoLink && !promoLink.startsWith('http')) {
              promoLink = new URL(promoLink, url).toString();
            }
            
            if (promoLink) {
              log(`Found specific promotion link for "${offerTitle}" with score ${bestMatch.score}`, 'link-resolver');
              linkCache[cacheKey] = { url: promoLink, timestamp: now };
              return promoLink;
            }
          } else {
            // If no specific match found, log that information
            log(`No specific match found for "${offerTitle}" on ${site}`, 'link-resolver');
          }
        }
      } catch (error: any) {
        // Failed to scrape - log but continue with default URL
        log(`Failed to scrape promotion page for ${site}: ${error.message}`, 'link-resolver');
      }
    }

    // If scraping failed or no specific offer was found, return the promotions page URL
    linkCache[cacheKey] = { url, timestamp: now };
    return url;
  } catch (error: any) {
    log(`Error in resolveOfferLink: ${error.message}`, 'link-resolver');
    return url; // Return original URL as fallback
  }
}

/**
 * Validates a given URL to check if it's accessible and returns proper content
 * 
 * @param url The URL to validate
 * @returns Object containing validation status and message
 */
export async function validateOfferLink(url: string): Promise<{ valid: boolean; message: string }> {
  try {
    // Ensure URL has protocol
    if (!url.startsWith('http')) {
      url = `https://${url}`;
    }

    // Send a HEAD request to check if the URL is valid
    const response = await axios.head(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      },
      timeout: 5000,
      validateStatus: () => true // Accept any status code
    });

    if (response.status >= 200 && response.status < 400) {
      return { valid: true, message: 'Link is valid and accessible' };
    } else if (response.status === 403) {
      // This is common for gambling sites that block scraping
      return { valid: true, message: 'Link requires authentication but appears valid' };
    } else {
      return { valid: false, message: `Link returned status code ${response.status}` };
    }
  } catch (error) {
    return { valid: false, message: `Error validating link: ${error.message}` };
  }
}

/**
 * Extracts site name from URL
 * 
 * @param url The URL to extract site name from
 * @returns The extracted site name or null if not found
 */
export function extractSiteFromUrl(url: string): string | null {
  try {
    if (!url.startsWith('http')) {
      url = `https://${url}`;
    }
    
    const hostname = new URL(url).hostname.toLowerCase();
    
    for (const [siteName, config] of Object.entries(siteConfigs)) {
      if (hostname.includes(config.domain.toLowerCase())) {
        return siteName;
      }
    }
    
    return null;
  } catch (error) {
    return null;
  }
}