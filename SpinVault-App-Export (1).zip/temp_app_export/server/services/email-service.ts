import { MailService } from '@sendgrid/mail';
import { Notification } from '@shared/schema';

// Initialize SendGrid
let mailService: MailService | null = null;

/**
 * Initialize SendGrid with API key
 */
export function initSendGrid() {
  if (!process.env.SENDGRID_API_KEY) {
    console.log('SendGrid API key not found. Email notifications will not be sent.');
    return false;
  }

  try {
    mailService = new MailService();
    mailService.setApiKey(process.env.SENDGRID_API_KEY);
    console.log('SendGrid initialized successfully');
    return true;
  } catch (error) {
    console.error('Error initializing SendGrid:', error);
    mailService = null;
    return false;
  }
}

/**
 * Send email using SendGrid
 * @param to Recipient email address
 * @param subject Email subject
 * @param html HTML content of the email
 * @param text Plain text content of the email (fallback)
 * @returns Boolean indicating if the email was sent successfully
 */
export async function sendEmail(to: string, subject: string, html: string, text?: string): Promise<boolean> {
  if (!mailService) {
    console.log('SendGrid not initialized. Email not sent.');
    return false;
  }

  try {
    // Use Gmail address for testing
    const fromEmail = process.env.SENDGRID_FROM_EMAIL || 'SpinVaultbuilder@gmail.com';
    const fromName = process.env.SENDGRID_FROM_NAME || 'SpinVault';

    console.log(`Sending email from ${fromEmail} to ${to} with subject "${subject}"`);
    
    await mailService.send({
      to,
      from: {
        email: fromEmail,
        name: fromName
      },
      subject,
      html,
      text: text || html.replace(/<[^>]*>/g, '') // Strip HTML if text not provided
    });

    console.log(`Email sent to ${to}`);
    return true;
  } catch (error: any) { // Type assertion for error
    console.error('Error sending email:', error);
    
    // Log detailed error information for debugging SendGrid issues
    if (error.response && error.response.body && error.response.body.errors) {
      console.error('SendGrid detailed errors:', JSON.stringify(error.response.body.errors, null, 2));
    }
    
    return false;
  }
}

/**
 * Generate HTML for a notification email
 * @param notification Notification object
 * @returns HTML string for email
 */
export function generateEmailHtml(notification: Notification): string {
  const baseUrl = process.env.APP_URL || 'https://spinvault.app';
  
  // Basic email template with SpinVault branding
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${notification.title}</title>
      <style>
        body { 
          font-family: Arial, sans-serif; 
          margin: 0; 
          padding: 0; 
          background-color: #f9fafb; 
          color: #1f2937; 
        }
        .container { 
          max-width: 600px; 
          margin: 0 auto; 
          padding: 20px; 
        }
        .header { 
          background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
          color: white; 
          padding: 20px; 
          text-align: center; 
          border-radius: 8px 8px 0 0; 
        }
        .content { 
          background: white; 
          padding: 20px; 
          border-radius: 0 0 8px 8px; 
          border: 1px solid #e5e7eb; 
          border-top: none; 
        }
        .button {
          display: inline-block;
          background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
          color: white;
          text-decoration: none;
          padding: 10px 20px;
          border-radius: 4px;
          margin-top: 15px;
        }
        .footer { 
          text-align: center; 
          margin-top: 20px; 
          font-size: 12px; 
          color: #6b7280; 
        }
        .reward-card {
          border: 1px solid #e5e7eb;
          border-radius: 6px;
          padding: 15px;
          margin-top: 20px;
          background-color: #f9fafb;
        }
        .reward-title {
          font-weight: bold;
          margin-bottom: 5px;
        }
        .reward-site {
          color: #6b7280;
          font-size: 14px;
          margin-bottom: 10px;
        }
        .expires {
          color: #ef4444;
          font-size: 14px;
          font-weight: bold;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>SpinVault</h1>
        </div>
        <div class="content">
          <h2>${notification.title}</h2>
          <p>${notification.message}</p>
          
          ${renderRewardDetails(notification)}
          
          <a href="${baseUrl}" class="button">View in SpinVault</a>
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} SpinVault. All rights reserved.</p>
          <p>You received this email because you signed up for SpinVault notifications.</p>
          <p><a href="${baseUrl}/settings/notifications">Manage notification settings</a></p>
        </div>
      </div>
    </body>
    </html>
  `;
}

/**
 * Render reward details for email if applicable
 */
function renderRewardDetails(notification: Notification): string {
  // Handle metadata type
  const metadata = typeof notification.metadata === 'string' 
    ? JSON.parse(notification.metadata) 
    : (notification.metadata || {}) as Record<string, any>;
  
  if (
    notification.type === 'REWARD_EXPIRING' && 
    metadata.rewards && 
    Array.isArray(metadata.rewards) && 
    metadata.rewards.length > 0
  ) {
    const rewards = metadata.rewards as any[];
    
    return `
      <div class="rewards-container">
        <h3>Expiring Rewards:</h3>
        ${rewards.map((reward: any) => `
          <div class="reward-card">
            <div class="reward-title">${reward.reward}</div>
            <div class="reward-site">${reward.site}</div>
            <div class="expires">Expires in ${Math.floor(reward.daysUntilExpiry)} days</div>
          </div>
        `).join('')}
      </div>
    `;
  }
  
  return ''; // No reward details to show
}