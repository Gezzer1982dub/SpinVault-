/**
 * Shared Detection Models and Types
 * 
 * NOTE: This file is deprecated. The core functionality has been moved to index.ts
 */

// Just an empty file to avoid import errors