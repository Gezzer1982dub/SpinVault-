/**
 * AI-powered Reward Detection
 * 
 * This module provides advanced reward detection using OpenAI's GPT models
 * to analyze text and images for gambling rewards.
 */

import { RewardCategory } from "@shared/schema";
import OpenAI from "openai";
import { DetectionResult, DetectedReward } from "./index";

// Initialize OpenAI API client if API key exists
const openai = process.env.OPENAI_API_KEY 
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

/**
 * Analyze an image with AI to extract rewards
 * 
 * @param imageBase64 Base64-encoded image data
 * @returns Extracted text and reward detection result
 */
export async function analyzeImageWithAI(imageBase64: string): Promise<DetectionResult> {
  try {
    // Check if OpenAI API key is available
    if (!process.env.OPENAI_API_KEY) {
      console.warn("OpenAI API key not set, skipping AI image analysis");
      return {
        success: false,
        rewards: [],
        confidence: 0,
        source: "image"
      };
    }

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    // Use GPT-4o to analyze the image
    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this image from a gambling site and extract any rewards, promotions, or offers. Look for free bets, free spins, bonus cash, and other gambling rewards. Return the results in JSON format with the following structure: { 'rewards': [ { 'site': string, 'reward': string, 'expiryText': string, 'category': string, 'confidence': number from 0-1 } ] }"
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${imageBase64}`
              }
            }
          ]
        }
      ],
      max_tokens: 800,
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content || "{}";
    const parsedContent = JSON.parse(content);

    // Format the rewards data
    const rewards = (parsedContent.rewards || []).map((reward: any) => {
      return {
        site: reward.site || "Unknown",
        reward: reward.reward,
        expiresAt: parseExpiryDate(reward.expiryText),
        confidence: reward.confidence || 0.7,
        category: reward.category || RewardCategory.OTHER
      };
    });

    const detectionResult: DetectionResult = {
      success: rewards.length > 0,
      rewards,
      confidence: calculateAverageConfidence(rewards),
      source: "image"
    };

    console.log("AI image analysis result:", JSON.stringify(detectionResult, null, 2));
    return detectionResult;
  } catch (error) {
    console.error("Error analyzing image with AI:", error);
    return {
      success: false,
      rewards: [],
      confidence: 0,
      source: "image"
    };
  }
}

/**
 * Analyze text content with AI to extract rewards
 * 
 * @param text Text to analyze
 * @param url URL of the page (optional)
 * @returns Enhanced detection result
 */
export async function analyzeTextWithAI(text: string, url?: string): Promise<DetectionResult> {
  try {
    // Check if OpenAI API key is available
    if (!process.env.OPENAI_API_KEY) {
      console.warn("OpenAI API key not set, skipping AI text analysis");
      return {
        success: false,
        rewards: [],
        confidence: 0,
        source: "text"
      };
    }

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    // Extract site name from URL if available
    let siteName = "Unknown";
    if (url) {
      try {
        const urlObj = new URL(url);
        siteName = urlObj.hostname.replace('www.', '').split('.')[0];
        siteName = siteName.charAt(0).toUpperCase() + siteName.slice(1); // Capitalize
      } catch {
        // Keep default site name
      }
    }

    // Prompt engineering for better reward extraction
    const siteContext = url ? `This text is from ${siteName} (${url}).` : "";
    const prompt = `${siteContext} Analyze this text from a gambling site and extract any rewards, promotions, or offers. Look specifically for:
- Free bets (e.g., "£10 Free Bet")
- Free spins (e.g., "50 Free Spins on Starburst")
- Deposit matches (e.g., "100% up to £100")
- Cashback offers (e.g., "10% Cashback up to £50")
- Bonus funds (e.g., "£20 Bonus Cash")
- Loyalty rewards (e.g., "500 Loyalty Points")
- Bingo tickets (e.g., "20 Free Bingo Tickets")

Return the results in JSON format with the following structure: { 'rewards': [ { 'site': string, 'reward': string, 'expiryText': string, 'category': string, 'confidence': number from 0-1 } ] }

Text to analyze:
${text.substring(0, 4000)} // Limit to first 4000 chars for token limits`;

    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "user", content: prompt }
      ],
      max_tokens: 800,
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content || "{}";
    const parsedContent = JSON.parse(content);

    // Format the rewards data
    const rewards = (parsedContent.rewards || []).map((reward: any) => {
      return {
        site: reward.site || siteName,
        reward: reward.reward,
        expiresAt: parseExpiryDate(reward.expiryText),
        confidence: reward.confidence || 0.7,
        category: reward.category as RewardCategory || RewardCategory.OTHER
      };
    });

    const detectionResult: DetectionResult = {
      success: rewards.length > 0,
      rewards,
      confidence: calculateAverageConfidence(rewards),
      source: "text"
    };

    console.log("AI text analysis result:", JSON.stringify(detectionResult, null, 2));
    return detectionResult;
  } catch (error) {
    console.error("Error analyzing text with AI:", error);
    return {
      success: false,
      rewards: [],
      confidence: 0,
      source: "text"
    };
  }
}

/**
 * Parse expiry date from various formats
 */
function parseExpiryDate(expiryText: string): Date {
  const now = new Date();
  
  if (!expiryText) {
    // Default expiry of 7 days if no expiry text
    const defaultExpiry = new Date();
    defaultExpiry.setDate(defaultExpiry.getDate() + 7);
    return defaultExpiry;
  }
  
  try {
    // Check for "X days/hours/minutes" format
    const daysMatch = expiryText.match(/(\d+)\s*days?/i);
    if (daysMatch) {
      const days = parseInt(daysMatch[1]);
      const expiry = new Date();
      expiry.setDate(expiry.getDate() + days);
      return expiry;
    }
    
    const hoursMatch = expiryText.match(/(\d+)\s*hours?/i);
    if (hoursMatch) {
      const hours = parseInt(hoursMatch[1]);
      const expiry = new Date();
      expiry.setHours(expiry.getHours() + hours);
      return expiry;
    }
    
    // Check for date format
    const dateMatch = expiryText.match(/(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})/);
    if (dateMatch) {
      // This assumes day/month/year format
      const day = parseInt(dateMatch[1]);
      const month = parseInt(dateMatch[2]) - 1; // JS months are 0-indexed
      const year = parseInt(dateMatch[3]);
      
      // Handle 2-digit years
      const fullYear = year < 100 ? 2000 + year : year;
      
      return new Date(fullYear, month, day);
    }
    
    // Default expiry of 7 days if format not recognized
    const defaultExpiry = new Date();
    defaultExpiry.setDate(defaultExpiry.getDate() + 7);
    return defaultExpiry;
  } catch (error) {
    console.error("Error parsing expiry date:", error);
    // Default expiry of 7 days on error
    const defaultExpiry = new Date();
    defaultExpiry.setDate(defaultExpiry.getDate() + 7);
    return defaultExpiry;
  }
}

/**
 * Calculate average confidence from rewards
 */
function calculateAverageConfidence(rewards: any[]): number {
  if (rewards.length === 0) return 0;
  
  const sum = rewards.reduce((total, reward) => total + (reward.confidence || 0), 0);
  return sum / rewards.length;
}