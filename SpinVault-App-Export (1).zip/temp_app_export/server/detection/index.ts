/**
 * Detection Module
 * 
 * This is the main entry point for the detection system, exporting the core
 * functionality for use in the rest of the application.
 */

import { InsertReward, RewardCategory } from "@shared/schema";
import { storage } from "../storage";
import OpenAI from "openai";

// Initialize OpenAI API client if API key exists
const openai = process.env.OPENAI_API_KEY 
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

// Core interfaces
export interface DetectionResult {
  success: boolean;
  rewards: DetectedReward[];
  confidence: number; // 0-1 score indicating confidence in detection
  source: string; // where the reward was detected
}

export interface DetectedReward {
  site: string;
  reward: string;
  expiresAt: Date;
  confidence: number; // 0-1 score for this specific reward
  raw?: string; // Raw text that was detected
  category?: RewardCategory;
}

// Site-specific patterns for reward detection
interface SitePattern {
  siteName: string;
  patterns: RegExp[];
  expiryPatterns: RegExp[];
  rewardMapper: (match: string) => string;
  categoryMapper: (match: string) => RewardCategory;
}

const sitePatterns: SitePattern[] = [
  // Bet365 patterns - Enhanced with more specific patterns and improved expiry detection
  {
    siteName: "Bet365",
    patterns: [
      /(?:free bet|bonus|reward|offer|free credit)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins|bonus spins)/i,
      /(?:£|\$|€)?(\d+(?:\.\d+)?)(?:\s+)?(?:deposit match|matched bet|matched deposit|deposit bonus)/i,
      /(\d+)%\s+(?:match|matched|deposit bonus|deposit match)/i,
      /(?:£|\$|€)?(\d+(?:\.\d+)?)\s+(?:risk[- ]free bet|insured bet)/i,
      /(?:bet|stake|wager)\s+(?:£|\$|€)?(\d+(?:\.\d+)?)\s+(?:get|receive)\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /available(?:\s+for)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /(?:valid|available) until (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /expires (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /valid (?:from .+? )?(?:to|until) (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i
    ],
    rewardMapper: (match: string): string => {
      if (match.toLowerCase().includes('free spins') || match.toLowerCase().includes('bonus spins')) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        // Look for game name
        const gameNameMatch = match.match(/(?:on|for|at)\s+["']?([A-Za-z0-9\s'\-&]+)(?:slot|game)?["']?/i);
        const gameName = gameNameMatch ? gameNameMatch[1].trim() : "slots";
        return `${spins} Free Spins on ${gameName}`;
      } else if (match.toLowerCase().includes('deposit match') || match.toLowerCase().includes('deposit bonus') || match.toLowerCase().includes('matched deposit')) {
        // Check for percentage match
        const percentMatch = match.match(/(\d+)%/i);
        if (percentMatch) {
          return `${percentMatch[1]}% Deposit Match`;
        }
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Deposit Match`;
      } else if (match.toLowerCase().includes('risk-free') || match.toLowerCase().includes('insured bet')) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Risk-Free Bet`;
      } else if (match.match(/bet\s+(?:£|\$|€)?(\d+(?:\.\d+)?)\s+get\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i)) {
        const betAmount = match.match(/bet\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i)?.[1] || "10";
        const getAmount = match.match(/get\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i)?.[1] || "10";
        return `Bet £${betAmount} Get £${getAmount}`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Free Bet`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      const lowerMatch = match.toLowerCase();
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        return RewardCategory.FREE_SPINS;
      } else if (lowerMatch.includes('deposit match') || lowerMatch.includes('deposit bonus') || lowerMatch.includes('matched deposit')) {
        return RewardCategory.DEPOSIT_MATCH;
      } else if (lowerMatch.includes('free bet') || lowerMatch.includes('risk-free') || lowerMatch.includes('insured bet')) {
        return RewardCategory.FREE_BET;
      } else if (lowerMatch.includes('cash back') || lowerMatch.includes('cashback') || lowerMatch.includes('money back')) {
        return RewardCategory.BONUS_CASH;
      } else if (lowerMatch.includes('loyalty') || lowerMatch.includes('points')) {
        return RewardCategory.LOYALTY_POINTS;
      } else if (lowerMatch.includes('bingo') || lowerMatch.includes('ticket')) {
        return RewardCategory.BINGO_TICKETS;
      } else {
        return RewardCategory.OTHER;
      }
    }
  },
  
  // Paddy Power patterns - Enhanced with more specific patterns and improved detection
  {
    siteName: "Paddy Power",
    patterns: [
      /(?:free bet|bonus|reward|offer|free credit)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins|bonus spins)/i,
      /(?:£|\$|€)?(\d+(?:\.\d+)?)(?:\s+)?(?:money back|cash back|cashback|bonus)/i,
      /(?:power up|power price|price boost|enhanced odds)/i,
      /(?:£|\$|€)?(\d+(?:\.\d+)?)\s+(?:risk[- ]free bet|insured bet)/i,
      /acca\s+(?:insurance|boost)/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /available(?:\s+for)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /(?:valid|available) until (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /expires (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /valid (?:from .+? )?(?:to|until) (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i
    ],
    rewardMapper: (match: string): string => {
      const lowerMatch = match.toLowerCase();
      
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        const spins = match.match(/(\d+)/)?.[1] || "20";
        // Look for game name
        const gameNameMatch = match.match(/(?:on|for|at)\s+["']?([A-Za-z0-9\s'\-&]+)(?:slot|game)?["']?/i);
        const gameName = gameNameMatch ? gameNameMatch[1].trim() : "slots";
        return `${spins} Free Spins on ${gameName}`;
      } else if (lowerMatch.includes('money back') || lowerMatch.includes('cash back') || lowerMatch.includes('cashback')) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "5";
        return `£${amount} Money Back`;
      } else if (lowerMatch.includes('power up') || lowerMatch.includes('power price') || lowerMatch.includes('price boost') || lowerMatch.includes('enhanced odds')) {
        return 'Odds Boost';
      } else if (lowerMatch.includes('acca insurance') || lowerMatch.includes('acca boost')) {
        return 'Acca Insurance';
      } else if (lowerMatch.includes('risk-free') || lowerMatch.includes('insured bet')) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Risk-Free Bet`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Free Bet`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      const lowerMatch = match.toLowerCase();
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        return RewardCategory.FREE_SPINS;
      } else if (lowerMatch.includes('money back') || lowerMatch.includes('cash back') || lowerMatch.includes('cashback')) {
        return RewardCategory.BONUS_CASH;
      } else if (lowerMatch.includes('free bet') || lowerMatch.includes('risk-free') || lowerMatch.includes('insured bet')) {
        return RewardCategory.FREE_BET;
      } else if (lowerMatch.includes('acca') || lowerMatch.includes('boost') || lowerMatch.includes('enhanced odds')) {
        return RewardCategory.OTHER;
      } else if (lowerMatch.includes('loyalty') || lowerMatch.includes('points')) {
        return RewardCategory.LOYALTY_POINTS;
      } else if (lowerMatch.includes('bingo') || lowerMatch.includes('ticket')) {
        return RewardCategory.BINGO_TICKETS;
      } else {
        return RewardCategory.OTHER;
      }
    }
  },
  
  // William Hill patterns
  {
    siteName: "William Hill",
    patterns: [
      /(?:free bet|bonus|reward|offer|insurance)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins|bonus spins)/i,
      /bet\s+(?:£|\$|€)?(\d+(?:\.\d+)?)\s+get\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /acca\s+(?:insurance|boost|club)/i,
      /golden\s+chip/i,
      /scratch\s+of\s+the\s+day/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /available(?:\s+for)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /(?:valid|available) until (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /expires (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i
    ],
    rewardMapper: (match: string): string => {
      const lowerMatch = match.toLowerCase();
      
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        return `${spins} Free Spins`;
      } else if (lowerMatch.match(/bet\s+(?:£|\$|€)?(\d+(?:\.\d+)?)\s+get\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i)) {
        const betAmount = match.match(/bet\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i)?.[1] || "10";
        const getAmount = match.match(/get\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i)?.[1] || "30";
        return `Bet £${betAmount} Get £${getAmount}`;
      } else if (lowerMatch.includes('acca')) {
        return 'Acca Insurance';
      } else if (lowerMatch.includes('golden chip')) {
        return 'Golden Chip';
      } else if (lowerMatch.includes('scratch')) {
        return 'Scratch of the Day';
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Free Bet`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      const lowerMatch = match.toLowerCase();
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        return RewardCategory.FREE_SPINS;
      } else if (lowerMatch.includes('free bet') || lowerMatch.match(/bet\s+(?:£|\$|€)?(\d+(?:\.\d+)?)\s+get\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i)) {
        return RewardCategory.FREE_BET;
      } else if (lowerMatch.includes('golden chip') || lowerMatch.includes('scratch')) {
        return RewardCategory.BONUS_CASH;
      } else if (lowerMatch.includes('acca')) {
        return RewardCategory.OTHER;
      } else {
        return RewardCategory.OTHER;
      }
    }
  },
  
  // SkyBet patterns
  {
    siteName: "Sky Bet",
    patterns: [
      /(?:free bet|bonus|reward|offer)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins|bonus spins)/i,
      /price\s+boost/i,
      /(?:club|reward|loyalty)\s+(?:boost|bonus)/i,
      /(?:£|\$|€)?(\d+(?:\.\d+)?)\s+in\s+free\s+bets/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /available(?:\s+for)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /(?:valid|available) until (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /expires (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i
    ],
    rewardMapper: (match: string): string => {
      const lowerMatch = match.toLowerCase();
      
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        return `${spins} Free Spins`;
      } else if (lowerMatch.includes('price boost')) {
        return 'Price Boost';
      } else if (lowerMatch.includes('club') || lowerMatch.includes('reward') || lowerMatch.includes('loyalty')) {
        return 'Club Reward';
      } else if (lowerMatch.includes('in free bets')) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} in Free Bets`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Free Bet`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      const lowerMatch = match.toLowerCase();
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        return RewardCategory.FREE_SPINS;
      } else if (lowerMatch.includes('free bet') || lowerMatch.includes('in free bets')) {
        return RewardCategory.FREE_BET;
      } else if (lowerMatch.includes('price boost')) {
        return RewardCategory.OTHER;
      } else if (lowerMatch.includes('club') || lowerMatch.includes('reward') || lowerMatch.includes('loyalty')) {
        return RewardCategory.LOYALTY_POINTS;
      } else {
        return RewardCategory.OTHER;
      }
    }
  },
  
  // Betfred patterns
  {
    siteName: "Betfred",
    patterns: [
      /(?:free bet|bonus|reward|offer)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins|bonus spins)/i,
      /double\s+delight/i,
      /hat[-\s]?trick\s+heaven/i,
      /(?:£|\$|€)?(\d+(?:\.\d+)?)\s+(?:when|if)/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /available(?:\s+for)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /(?:valid|available) until (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /expires (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i
    ],
    rewardMapper: (match: string): string => {
      const lowerMatch = match.toLowerCase();
      
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        return `${spins} Free Spins`;
      } else if (lowerMatch.includes('double delight')) {
        return 'Double Delight';
      } else if (lowerMatch.includes('hat-trick heaven') || lowerMatch.includes('hat trick heaven')) {
        return 'Hat-Trick Heaven';
      } else if (lowerMatch.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)\s+(?:when|if)/i)) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Special Offer`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Free Bet`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      const lowerMatch = match.toLowerCase();
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        return RewardCategory.FREE_SPINS;
      } else if (lowerMatch.includes('free bet')) {
        return RewardCategory.FREE_BET;
      } else if (lowerMatch.includes('double delight') || lowerMatch.includes('hat-trick heaven') || lowerMatch.includes('hat trick heaven')) {
        return RewardCategory.BONUS_CASH;
      } else {
        return RewardCategory.OTHER;
      }
    }
  },
  
  // Coral patterns
  {
    siteName: "Coral",
    patterns: [
      /(?:free bet|bonus|reward|offer)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins|bonus spins)/i,
      /smart\s+boost/i,
      /in[-\s]play\s+boost/i,
      /(\d+)\s+free\s+bingo\s+tickets/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /available(?:\s+for)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /(?:valid|available) until (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /expires (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i
    ],
    rewardMapper: (match: string): string => {
      const lowerMatch = match.toLowerCase();
      
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        return `${spins} Free Spins`;
      } else if (lowerMatch.includes('smart boost')) {
        return 'Smart Boost';
      } else if (lowerMatch.includes('in-play boost') || lowerMatch.includes('in play boost')) {
        return 'In-Play Boost';
      } else if (lowerMatch.match(/(\d+)\s+free\s+bingo\s+tickets/i)) {
        const tickets = match.match(/(\d+)\s+free\s+bingo\s+tickets/i)?.[1] || "5";
        return `${tickets} Free Bingo Tickets`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Free Bet`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      const lowerMatch = match.toLowerCase();
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        return RewardCategory.FREE_SPINS;
      } else if (lowerMatch.includes('free bet')) {
        return RewardCategory.FREE_BET;
      } else if (lowerMatch.includes('smart boost') || lowerMatch.includes('in-play boost') || lowerMatch.includes('in play boost')) {
        return RewardCategory.OTHER;
      } else if (lowerMatch.includes('bingo')) {
        return RewardCategory.BINGO_TICKETS;
      } else {
        return RewardCategory.OTHER;
      }
    }
  },
  
  // Ladbrokes patterns
  {
    siteName: "Ladbrokes",
    patterns: [
      /(?:free bet|bonus|reward|offer)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins|bonus spins)/i,
      /odds\s+boost/i,
      /1-2-free/i,
      /(\d+)\s+free\s+bingo\s+tickets/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /available(?:\s+for)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /(?:valid|available) until (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /expires (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i
    ],
    rewardMapper: (match: string): string => {
      const lowerMatch = match.toLowerCase();
      
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        return `${spins} Free Spins`;
      } else if (lowerMatch.includes('odds boost')) {
        return 'Odds Boost';
      } else if (lowerMatch.includes('1-2-free')) {
        return '1-2-Free Promotion';
      } else if (lowerMatch.match(/(\d+)\s+free\s+bingo\s+tickets/i)) {
        const tickets = match.match(/(\d+)\s+free\s+bingo\s+tickets/i)?.[1] || "5";
        return `${tickets} Free Bingo Tickets`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Free Bet`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      const lowerMatch = match.toLowerCase();
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins')) {
        return RewardCategory.FREE_SPINS;
      } else if (lowerMatch.includes('free bet')) {
        return RewardCategory.FREE_BET;
      } else if (lowerMatch.includes('odds boost') || lowerMatch.includes('1-2-free')) {
        return RewardCategory.OTHER;
      } else if (lowerMatch.includes('bingo')) {
        return RewardCategory.BINGO_TICKETS;
      } else {
        return RewardCategory.OTHER;
      }
    }
  },
  
  // 888Casino patterns
  {
    siteName: "888 Casino",
    patterns: [
      /(?:free bet|bonus|reward|offer)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins|bonus spins|no deposit spins|extra spins)/i,
      /no deposit bonus/i,
      /daily\s+jackpot/i,
      /(\d+)%\s+deposit\s+match/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /available(?:\s+for)?\s+(\d+)\s+(?:days|hours|weeks)/i,
      /(?:valid|available) until (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
      /expires (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i
    ],
    rewardMapper: (match: string): string => {
      const lowerMatch = match.toLowerCase();
      
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins') || 
          lowerMatch.includes('no deposit spins') || lowerMatch.includes('extra spins')) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        return `${spins} Free Spins`;
      } else if (lowerMatch.includes('no deposit bonus')) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "5";
        return `£${amount} No Deposit Bonus`;
      } else if (lowerMatch.includes('daily jackpot')) {
        return 'Daily Jackpot';
      } else if (lowerMatch.match(/(\d+)%\s+deposit\s+match/i)) {
        const percentage = match.match(/(\d+)%/i)?.[1] || "100";
        return `${percentage}% Deposit Match`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Casino Bonus`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      const lowerMatch = match.toLowerCase();
      if (lowerMatch.includes('free spins') || lowerMatch.includes('bonus spins') || 
          lowerMatch.includes('no deposit spins') || lowerMatch.includes('extra spins')) {
        return RewardCategory.FREE_SPINS;
      } else if (lowerMatch.includes('deposit match')) {
        return RewardCategory.DEPOSIT_MATCH;
      } else if (lowerMatch.includes('no deposit bonus') || lowerMatch.includes('daily jackpot')) {
        return RewardCategory.BONUS_CASH;
      } else {
        return RewardCategory.OTHER;
      }
    }
  }
];

// Enhanced generic patterns with more comprehensive coverage
const genericPatterns = [
  // Free bets and bonuses
  /(?:free bet|bonus|reward|offer|credit|prize)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
  /(?:£|\$|€)?(\d+(?:\.\d+)?)\s+(?:free bet|bonus|reward)/i,
  
  // Free spins
  /(\d+)(?:\s+)?(?:free spins|bonus spins|extra spins|spins|games)/i,
  /(?:free|bonus|extra)\s+(\d+)(?:\s+)?(?:spins|games)/i,
  
  // Deposit matches and cashback
  /(?:£|\$|€)?(\d+(?:\.\d+)?)(?:\s+)?(?:deposit match|matched bet|cash back|cashback|money back)/i,
  /(\d+)%\s+(?:match|matched|deposit bonus|deposit match|cashback)/i,
  
  // Bet and get offers
  /(?:bet|stake|wager)\s+(?:£|\$|€)?(\d+(?:\.\d+)?)\s+(?:get|receive|win)\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
  
  // Risk-free bets
  /(?:£|\$|€)?(\d+(?:\.\d+)?)\s+(?:risk[\s-]free|insurance|insured)\s+bet/i,
  
  // Bingo tickets
  /(\d+)\s+(?:free)?\s+bingo\s+tickets/i,
  
  // Odds enhancements
  /(?:odds boost|price boost|enhanced odds|boosted odds)/i,
  
  // Welcome offers
  /welcome\s+(?:offer|bonus|package)/i,
  /new\s+customer\s+(?:offer|deal|exclusive)/i,
  
  // Loyalty points
  /(\d+)(?:\s+)?(?:loyalty\s+points|reward\s+points|comp\s+points)/i,
  
  // Special time-limited promotions
  /(?:today|daily|weekly)\s+(?:special|offer|promotion|deal)/i,
  
  // Promo codes
  /promo\s+code[:\s]+([A-Z0-9_-]+)/i,
  /use\s+code[:\s]+([A-Z0-9_-]+)/i,
  /bonus\s+code[:\s]+([A-Z0-9_-]+)/i
];

// Enhanced generic expiry patterns with better date format detection
const genericExpiryPatterns = [
  // Relative time frames
  /valid(?:\s+for|until)?\s+(\d+)\s+(?:days?|hours?|weeks?|months?)/i,
  /expires?(?:\s+in|\s+on|\s+after)?\s+(\d+)\s+(?:days?|hours?|weeks?|months?)/i,
  /available(?:\s+for)?\s+(\d+)\s+(?:days?|hours?|weeks?|months?)/i,
  /(?:offer|promotion)\s+ends\s+(?:in|after)\s+(\d+)\s+(?:days?|hours?|weeks?|months?)/i,
  
  // Specific date formats (DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY)
  /(?:valid|available) until (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
  /expires (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
  /valid (?:from .+? )?(?:to|until) (\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
  /(?:offer|promotion) ends (?:on )?(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/i,
  
  // Date with month names
  /(?:valid|expires|ends) (?:on|until)?\s+(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?(January|February|March|April|May|June|July|August|September|October|November|December)/i,
  /(?:valid|available) (?:until|to)\s+(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?(January|February|March|April|May|June|July|August|September|October|November|December)/i,
  
  // "Today only" or similar
  /today only/i,
  /valid today/i,
  /24 hours only/i
];

/**
 * Main detection function that analyzes content from a gambling site
 * to identify potential rewards
 */
export function detectRewards(content: string, url?: string): DetectionResult {
  // Basic preprocessing
  content = content.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  
  // Try to identify the site from the URL - Enhanced with more gambling sites
  let siteName = null;
  if (url) {
    const domain = url.toLowerCase().match(/\/\/([^\/]+)/)?.[1] || url.toLowerCase();
    if (domain.includes('bet365')) siteName = 'Bet365';
    if (domain.includes('paddypower')) siteName = 'Paddy Power';
    if (domain.includes('williamhill')) siteName = 'William Hill';
    if (domain.includes('skybet')) siteName = 'Sky Bet';
    if (domain.includes('betfred')) siteName = 'Betfred';
    if (domain.includes('coral')) siteName = 'Coral';
    if (domain.includes('ladbrokes')) siteName = 'Ladbrokes';
    if (domain.includes('888casino') || domain.includes('888.com')) siteName = '888 Casino';
    if (domain.includes('betfair')) siteName = 'Betfair';
    if (domain.includes('unibet')) siteName = 'Unibet';
    if (domain.includes('pokerstars')) siteName = 'PokerStars';
    if (domain.includes('mrgreen')) siteName = 'Mr Green';
    if (domain.includes('betway')) siteName = 'Betway';
    if (domain.includes('10bet')) siteName = '10Bet';
    if (domain.includes('leovegas')) siteName = 'LeoVegas';
  }
  
  // Find the matching site pattern
  const sitePattern = sitePatterns.find(pattern => 
    pattern.siteName.toLowerCase() === siteName?.toLowerCase()
  );
  
  // Detect rewards
  let detectedRewards: DetectedReward[] = [];
  
  if (sitePattern) {
    // Use site-specific patterns
    for (const pattern of sitePattern.patterns) {
      const matches = content.match(new RegExp(pattern, 'gi')) || [];
      
      for (const match of matches) {
        // Extract the expiry date
        const expiryDate = extractExpiryDate(content, sitePattern.expiryPatterns);
        
        // Map the matched text to a reward description
        const rewardText = sitePattern.rewardMapper(match);
        
        // Determine the category
        const category = sitePattern.categoryMapper(match);
        
        detectedRewards.push({
          site: sitePattern.siteName,
          reward: rewardText,
          expiresAt: expiryDate,
          confidence: 0.8,
          raw: match,
          category
        });
      }
    }
  } else {
    // Use generic patterns
    for (const pattern of genericPatterns) {
      const matches = content.match(new RegExp(pattern, 'gi')) || [];
      
      for (const match of matches) {
        // Extract the expiry date
        const expiryDate = extractExpiryDate(content, genericExpiryPatterns);
        
        // Basic reward text
        let rewardText = match;
        let category = RewardCategory.OTHER;
        
        // Simple categorization
        if (match.match(/free spins/i)) {
          const spins = match.match(/(\d+)/)?.[1] || "10";
          rewardText = `${spins} Free Spins`;
          category = RewardCategory.FREE_SPINS;
        } else if (match.match(/free bet/i)) {
          const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
          rewardText = `£${amount} Free Bet`;
          category = RewardCategory.FREE_BET;
        }
        
        detectedRewards.push({
          site: siteName || "Unknown Site",
          reward: rewardText,
          expiresAt: expiryDate,
          confidence: 0.6,
          raw: match,
          category
        });
      }
    }
  }
  
  // Calculate overall confidence
  const overallConfidence = detectedRewards.length > 0
    ? detectedRewards.reduce((sum, reward) => sum + reward.confidence, 0) / detectedRewards.length
    : 0;
  
  return {
    success: detectedRewards.length > 0,
    rewards: detectedRewards,
    confidence: overallConfidence,
    source: "pattern_detection"
  };
}

/**
 * Extract expiry date from content - Enhanced with better date parsing
 */
function extractExpiryDate(content: string, patterns: RegExp[]): Date {
  const now = new Date();
  
  // First check for today only
  const todayPatterns = [/today only/i, /valid today/i, /24 hours only/i];
  for (const pattern of todayPatterns) {
    if (content.match(pattern)) {
      const date = new Date();
      date.setHours(23, 59, 59, 999); // End of today
      return date;
    }
  }
  
  // Check all patterns
  for (const pattern of patterns) {
    const match = content.match(pattern);
    
    if (match && match[1]) {
      // If it's a number of days/hours/weeks
      if (match[1].match(/^\d+$/)) {
        const value = parseInt(match[1]);
        
        const date = new Date();
        
        // Determine unit from the matched string
        if (match[0].includes('hour')) {
          date.setHours(date.getHours() + value);
          return date;
        } else if (match[0].includes('week')) {
          date.setDate(date.getDate() + (value * 7));
          return date;
        } else if (match[0].includes('month')) {
          date.setMonth(date.getMonth() + value);
          return date;
        } else {
          // Default to days
          date.setDate(date.getDate() + value);
          return date;
        }
      }
      
      // Check for date with format DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY
      const dateFormatMatch = match[0].match(/(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/);
      if (dateFormatMatch) {
        const day = parseInt(dateFormatMatch[1]);
        const month = parseInt(dateFormatMatch[2]) - 1; // JS months are 0-indexed
        
        let year = new Date().getFullYear();
        if (dateFormatMatch[3]) {
          year = parseInt(dateFormatMatch[3]);
          // Handle 2-digit years
          if (year < 100) {
            year += 2000;
          }
        }
        
        const date = new Date(year, month, day, 23, 59, 59);
        
        // Validate date is in the future
        if (date > now) {
          return date;
        }
      }
      
      // Check for date with month names
      const monthNameMatch = match[0].match(/(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?(January|February|March|April|May|June|July|August|September|October|November|December)/i);
      if (monthNameMatch) {
        const day = parseInt(monthNameMatch[1]);
        const monthName = monthNameMatch[2].toLowerCase();
        
        const monthMap: {[key: string]: number} = {
          'january': 0, 'february': 1, 'march': 2, 'april': 3, 'may': 4, 'june': 5,
          'july': 6, 'august': 7, 'september': 8, 'october': 9, 'november': 10, 'december': 11
        };
        
        const month = monthMap[monthName];
        let year = new Date().getFullYear();
        
        // If the date would be in the past, assume next year
        const tempDate = new Date(year, month, day);
        if (tempDate < now) {
          year++;
        }
        
        const date = new Date(year, month, day, 23, 59, 59);
        return date;
      }
    }
  }
  
  // Default to 7 days from now if no pattern matches
  const date = new Date();
  date.setDate(date.getDate() + 7);
  return date;
}

/**
 * Extract text from an image using AI - Enhanced with improved detection capabilities
 */
export async function processScreenCapture(imageBase64: string): Promise<string> {
  // If OpenAI is available, use it to extract text
  if (openai) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
        messages: [
          {
            role: "system",
            content: `Extract all text visible in this image, preserving layout and formatting as much as possible.
            Focus specifically on gambling-related promotional offers, rewards, bonuses, and important dates.
            
            Pay special attention to:
            - Numerical values (£10, 100%, 50 Free Spins, etc.)
            - Promotional terms ("Free Bet", "Deposit Match", "Risk-Free", etc.)
            - Expiry dates or time limitations
            - Gambling site/brand names
            - Terms and conditions related to the rewards
            - Wagering requirements
            - Minimum odds or deposit requirements
            
            Extract text even if it appears in images, buttons, banners, or complex backgrounds.
            Maintain the structure of information when possible to preserve relationships between promotions and their terms.`
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Extract all gambling rewards and promotional text from this image:"
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${imageBase64}`
                }
              }
            ]
          }
        ],
        max_tokens: 1000,
        temperature: 0.3
      });
      
      return response.choices[0]?.message?.content || "";
    } catch (error) {
      console.error("Error processing image with AI:", error);
      return "Error processing image";
    }
  }
  
  // Fallback when OpenAI is not available
  return "OpenAI API key not configured. Please add OPENAI_API_KEY to enable image processing.";
}

/**
 * Analyze text with AI to detect rewards
 */
export async function analyzeTextWithAI(text: string, url?: string): Promise<DetectionResult> {
  // If OpenAI is available, use it for analysis - Enhanced with more sophisticated detection
  if (openai) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
        messages: [
          {
            role: "system",
            content: `You are an expert in identifying gambling rewards, promotions, and bonuses from website content. 
            Extract any offers, bonuses, free spins, or other rewards with high precision.
            
            ## Types of rewards to detect:
            - Free Bets (e.g., "£10 Free Bet", "Bet £10 Get £30 in Free Bets")
            - Free Spins (e.g., "50 Free Spins on Starburst", "100 Bonus Spins")
            - Deposit Matches (e.g., "100% up to £200", "50% Deposit Match")
            - Bonus Cash (e.g., "£20 Bonus", "£10 No Deposit Bonus")
            - Risk-Free Bets (e.g., "£10 Risk-Free First Bet", "Money Back If You Lose")
            - Bingo Tickets (e.g., "20 Free Bingo Tickets", "Buy 1 Get 5 Free")
            - Enhanced Odds (e.g., "Odds Boost on Liverpool to Win", "Enhanced Acca")
            - Loyalty/Reward Points (e.g., "2X Loyalty Points", "500 Comp Points")
            - Special offers (e.g., "Happy Hour Bonus", "Weekend Special")
            
            ## For each reward found, identify:
            1. The gambling site/brand (extract from URL or content context)
            2. The specific reward formatted clearly and precisely
            3. The expiry date or duration if visible (formatted as ISO date or "X days")
            4. Categorize precisely as one of: FREE_SPINS, BONUS_CASH, DEPOSIT_MATCH, FREE_BET, BINGO_TICKETS, LOYALTY_POINTS, or OTHER
            5. Assign a confidence score (0.0-1.0) based on how certain you are about this reward
            6. Include the raw text that contained the reward
            
            ## Guidelines for detection:
            - Focus on real, actionable rewards (ignore vague marketing language)
            - Look for specific values, amounts, and percentages
            - Detect rewards even if they're embedded in complex sentences or formats
            - If you're uncertain about a potential reward, include it with a lower confidence score
            - For ambiguous site names, try to determine from context or URL
            - When in doubt about category, use the most specific one that applies
            
            ## Special attention:
            - Look for any indications of expiry dates (e.g., "valid until", "expires in", "offer ends")
            - Detect T&Cs that might be associated with rewards (minimum odds, wagering requirements)
            - Notice patterns like "Bet X Get Y" which indicate specific promotional structures
            - Be aware of synonyms for rewards (e.g., "bonus spins" = "free spins")
            
            Respond in valid JSON format with this structure:
            {"rewards": [{"site": "string", "reward": "string", "expiresAt": "ISO date string or duration", "category": "category", "confidence": number, "raw": "extracted text"}]}`
          },
          {
            role: "user",
            content: `URL: ${url || 'Unknown'}\n\n${text}`
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 1500,
        temperature: 0.2
      });
      
      // Parse the AI response
      let result;
      try {
        const content = response.choices[0]?.message?.content || '{"rewards":[]}';
        result = JSON.parse(content);
      } catch (error) {
        console.error("Error parsing AI response:", error);
        result = { rewards: [] };
      }
      
      // Process the rewards
      const rewards = (result.rewards || []).map((reward: any) => {
        // Parse the expiry date
        let expiryDate = new Date();
        if (reward.expiresAt) {
          try {
            expiryDate = new Date(reward.expiresAt);
            if (isNaN(expiryDate.getTime())) {
              // If it contains 'days'
              const daysMatch = reward.expiresAt.match(/(\d+)\s*days?/i);
              if (daysMatch) {
                expiryDate = new Date();
                expiryDate.setDate(expiryDate.getDate() + parseInt(daysMatch[1]));
              } else {
                // Default to 7 days
                expiryDate = new Date();
                expiryDate.setDate(expiryDate.getDate() + 7);
              }
            }
          } catch (e) {
            // Default to 7 days from now
            expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + 7);
          }
        } else {
          // Default to 7 days from now
          expiryDate.setDate(expiryDate.getDate() + 7);
        }
        
        return {
          site: reward.site || (url ? new URL(url).hostname : "Unknown"),
          reward: reward.reward || "Unknown reward",
          expiresAt: expiryDate,
          category: reward.category || RewardCategory.OTHER,
          confidence: reward.confidence || 0.7,
          raw: reward.raw || reward.reward || "Unknown"
        };
      });
      
      return {
        success: rewards.length > 0,
        rewards,
        confidence: rewards.length > 0 
          ? rewards.reduce((sum, r) => sum + r.confidence, 0) / rewards.length 
          : 0,
        source: "ai_analysis"
      };
    } catch (error) {
      console.error("Error analyzing with AI:", error);
    }
  }
  
  // Fall back to pattern-based detection
  return detectRewards(text, url);
}

/**
 * Convert a DetectedReward to an InsertReward for database storage
 */
export function convertToInsertReward(detected: DetectedReward, userId: number): InsertReward {
  return {
    userId,
    site: detected.site,
    reward: detected.reward,
    expiresAt: detected.expiresAt,
    claimed: false,
    category: detected.category as string || RewardCategory.OTHER,
    confidence: detected.confidence.toString()
  };
}

/**
 * Main detection service class
 */
export class DetectionService {
  /**
   * Detect rewards from content (HTML or text)
   */
  async detectFromContent(
    content: string,
    url: string | undefined,
    userId: number
  ): Promise<DetectionResult> {
    try {
      // Try AI-based detection first if OpenAI is available
      let result: DetectionResult;
      
      if (openai) {
        // Use AI-enhanced detection
        result = await analyzeTextWithAI(content, url);
      } else {
        // Fall back to pattern-based detection
        result = detectRewards(content, url);
      }
      
      // Save the detected rewards if successful
      if (result.success) {
        for (const reward of result.rewards) {
          const insertReward = convertToInsertReward(reward, userId);
          await storage.createReward(insertReward);
        }
      }
      
      return result;
    } catch (error) {
      console.error("Error in detection service:", error);
      return {
        success: false,
        rewards: [],
        confidence: 0,
        source: "error"
      };
    }
  }
  
  /**
   * Detect rewards from an image
   */
  async detectFromImage(imageData: string, userId: number): Promise<DetectionResult> {
    try {
      // Extract text from the image
      const extractedText = await processScreenCapture(imageData);
      
      // Use the text detection on the extracted text
      return this.detectFromContent(extractedText, undefined, userId);
    } catch (error) {
      console.error("Error in image detection:", error);
      return {
        success: false,
        rewards: [],
        confidence: 0,
        source: "error"
      };
    }
  }
}

// Export an instance of the detection service
export const detectionService = new DetectionService();