/**
 * Detection Service
 * 
 * This service handles the integration between the detection algorithm
 * and the application, providing a clean API for reward detection.
 * 
 * NOTE: This file is deprecated. The core functionality has been moved to index.ts
 */

export class DetectionService {
  /**
   * Detect rewards from a URL or webpage content
   * 
   * @param content HTML or text content to analyze
   * @param url URL of the page (helps with site identification)
   * @param userId User ID to associate with detected rewards
   * @returns Result with detected rewards and success status
   */
  async detectFromContent(
    content: string,
    url: string | undefined,
    userId: number
  ): Promise<DetectionResult> {
    try {
      // Basic pattern-based detection
      const patternResult = detectRewards(content, url);
      
      // Enhanced AI-based detection for improved accuracy
      const aiResult = await analyzeTextWithAI(content, url);
      
      // Combine results, prioritizing AI detections but keeping pattern-based as fallback
      const combinedRewards = [
        ...aiResult.rewards,
        ...patternResult.rewards.filter(
          reward => !aiResult.rewards.some(
            aiReward => this.areRewardsTextSimilar(aiReward.reward, reward.reward)
          )
        )
      ];
      
      const result: DetectionResult = {
        success: combinedRewards.length > 0,
        rewards: combinedRewards,
        confidence: this.calculateAverageConfidence(combinedRewards),
        source: aiResult.rewards.length > 0 ? 
          (patternResult.rewards.length > 0 ? "ai_and_pattern" : "ai") : 
          "pattern"
      };
      
      // Save the detected rewards if successful
      if (result.success) {
        await this.saveDetectedRewards(result.rewards, userId);
        
        // Track successful detection
        await this.trackDetectionAttempt(userId, true);
      } else {
        // Track failed detection attempt
        await this.trackDetectionAttempt(userId, false);
      }
      
      return result;
    } catch (error) {
      console.error("Error in detection service:", error);
      return {
        success: false,
        rewards: [],
        confidence: 0,
        source: "error"
      };
    }
  }

  /**
   * Detect rewards from an image or screenshot (for mobile app)
   * 
   * @param imageData Base64-encoded image data
   * @param userId User ID to associate with detected rewards
   * @returns Result with detected rewards and success status
   */
  async detectFromImage(imageData: string, userId: number): Promise<DetectionResult> {
    try {
      // Extract text from image
      const extractedText = await processScreenCapture(imageData);
      
      // Use AI for image analysis to extract rewards
      const aiImageResult = await analyzeImageWithAI(imageData);
      
      // Also run pattern detection on the extracted text
      const patternResult = detectRewards(extractedText);
      
      // Combine results, prioritizing AI detections
      const combinedRewards = [
        ...aiImageResult.rewards,
        ...patternResult.rewards.filter(
          reward => !aiImageResult.rewards.some(
            aiReward => this.areRewardsTextSimilar(aiReward.reward, reward.reward)
          )
        )
      ];
      
      const result: DetectionResult = {
        success: combinedRewards.length > 0,
        rewards: combinedRewards,
        confidence: this.calculateAverageConfidence(combinedRewards),
        source: "image_detection"
      };
      
      // Save the detected rewards if successful
      if (result.success) {
        await this.saveDetectedRewards(result.rewards, userId);
        
        // Track successful detection
        await this.trackDetectionAttempt(userId, true);
      } else {
        // Track failed detection attempt
        await this.trackDetectionAttempt(userId, false);
      }
      
      return result;
    } catch (error) {
      console.error("Error in image detection:", error);
      return {
        success: false,
        rewards: [],
        confidence: 0,
        source: "error"
      };
    }
  }

  /**
   * Save detected rewards to storage
   * 
   * @param rewards Array of detected rewards
   * @param userId User ID to associate with rewards
   * @returns Array of saved reward objects
   */
  private async saveDetectedRewards(rewards: DetectedReward[], userId: number): Promise<Reward[]> {
    const savedRewards: Reward[] = [];
    
    for (const reward of rewards) {
      const insertReward = convertToInsertReward(reward, userId);
      
      // Check if this is a duplicate reward
      const isDuplicate = await this.isDuplicateReward(insertReward);
      if (!isDuplicate) {
        const savedReward = await storage.createReward(insertReward);
        savedRewards.push(savedReward);
      }
    }
    
    return savedRewards;
  }

  /**
   * Check if a reward already exists in the database
   * 
   * @param reward Reward to check for duplicates
   * @returns true if a duplicate exists, false otherwise
   */
  private async isDuplicateReward(reward: InsertReward): Promise<boolean> {
    const userRewards = await storage.getRewards(reward.userId);
    
    return userRewards.some(existingReward => 
      // Check if site is the same
      existingReward.site === reward.site && 
      // Check if reward text is similar
      this.areRewardsTextSimilar(existingReward.reward, reward.reward) &&
      // Check if the reward is not expired
      new Date(existingReward.expiresAt) > new Date() &&
      // Check if the reward is not claimed
      !existingReward.claimed
    );
  }

  /**
   * Compare two reward texts for similarity
   * 
   * @param text1 First reward text
   * @param text2 Second reward text
   * @returns true if the texts are considered similar
   */
  private areRewardsTextSimilar(text1: string, text2: string): boolean {
    // Simple similarity check: normalize and compare
    const normalize = (text: string) => text.toLowerCase().replace(/[^\w\s]/g, '').trim();
    
    const normalized1 = normalize(text1);
    const normalized2 = normalize(text2);
    
    // Check for exact match after normalization
    if (normalized1 === normalized2) return true;
    
    // Check Levenshtein distance for fuzzy matching
    const distance = this.levenshteinDistance(normalized1, normalized2);
    const maxLength = Math.max(normalized1.length, normalized2.length);
    
    // If the distance is less than 30% of the max length, consider them similar
    return distance / maxLength < 0.3;
  }

  /**
   * Calculate Levenshtein distance between two strings
   */
  private levenshteinDistance(a: string, b: string): number {
    const matrix: number[][] = [];
    
    // Initialize the matrix
    for (let i = 0; i <= a.length; i++) {
      matrix[i] = [i];
    }
    
    for (let j = 0; j <= b.length; j++) {
      matrix[0][j] = j;
    }
    
    // Fill the matrix
    for (let i = 1; i <= a.length; i++) {
      for (let j = 1; j <= b.length; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        matrix[i][j] = Math.min(
          matrix[i - 1][j] + 1,      // deletion
          matrix[i][j - 1] + 1,      // insertion
          matrix[i - 1][j - 1] + cost // substitution
        );
      }
    }
    
    return matrix[a.length][b.length];
  }

  /**
   * Get statistics about detected rewards
   * 
   * @param userId User ID to get statistics for
   * @returns Object with detection statistics
   */
  async getDetectionStats(userId: number): Promise<{
    totalRewards: number;
    activeRewards: number;
    claimedRewards: number;
    expiredRewards: number;
    bySite: { [site: string]: number };
    byCategory: { [category: string]: number };
  }> {
    const rewards = await storage.getRewards(userId);
    const now = new Date();
    
    const activeRewards = rewards.filter(
      r => new Date(r.expiresAt) > now && !r.claimed
    );
    
    const claimedRewards = rewards.filter(r => r.claimed);
    
    const expiredRewards = rewards.filter(
      r => new Date(r.expiresAt) <= now && !r.claimed
    );
    
    // Categorize rewards by site
    const bySite = rewards.reduce((acc: { [site: string]: number }, reward) => {
      acc[reward.site] = (acc[reward.site] || 0) + 1;
      return acc;
    }, {});
    
    // Categorize rewards by category
    const byCategory = rewards.reduce((acc: { [category: string]: number }, reward) => {
      const category = reward.category || 'OTHER';
      acc[category] = (acc[category] || 0) + 1;
      return acc;
    }, {});
    
    return {
      totalRewards: rewards.length,
      activeRewards: activeRewards.length,
      claimedRewards: claimedRewards.length,
      expiredRewards: expiredRewards.length,
      bySite,
      byCategory
    };
  }

  /**
   * Get usage statistics for the detection service
   * 
   * @param userId User ID to get usage for
   * @returns Usage statistics
   */
  async getUsageStats(userId: number): Promise<{
    dailyDetectionCount: number;
    monthlyDetectionCount: number;
    successRate: number;
  }> {
    const settings = await storage.getExtensionSettings(userId);
    
    if (!settings) {
      return {
        dailyDetectionCount: 0,
        monthlyDetectionCount: 0,
        successRate: 0
      };
    }
    
    const successRate = settings.detectionSuccessCount > 0
      ? settings.detectionSuccessCount / 
        (settings.detectionSuccessCount + settings.detectionFailureCount)
      : 0;
    
    return {
      dailyDetectionCount: settings.dailyDetectionCount || 0,
      monthlyDetectionCount: settings.monthlyDetectionCount || 0,
      successRate
    };
  }

  /**
   * Track a detection attempt
   * 
   * @param userId User ID making the detection
   * @param successful Whether the detection was successful
   */
  async trackDetectionAttempt(userId: number, successful: boolean): Promise<void> {
    // Get user settings
    let settings = await storage.getExtensionSettings(userId);
    
    // Create settings if they don't exist
    if (!settings) {
      settings = await storage.createExtensionSettings({
        userId,
        dailyDetectionCount: 0,
        monthlyDetectionCount: 0,
        detectionSuccessCount: 0,
        detectionFailureCount: 0,
        lastResetDate: new Date(),
        enableNotifications: true,
        enableAutoDetection: true,
        detectionFrequency: 'automatic',
        favoriteRewardSites: [],
        detectionSensitivity: 'medium'
      });
    }
    
    // Check if we need to reset the daily count
    const lastReset = new Date(settings.lastResetDate);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const resetDay = new Date(lastReset.getFullYear(), lastReset.getMonth(), lastReset.getDate());
    
    if (today.getTime() > resetDay.getTime()) {
      await this.resetDailyDetectionCount(userId);
      settings.dailyDetectionCount = 0;
    }
    
    // Check if we need to reset the monthly count
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonth = new Date(lastReset.getFullYear(), lastReset.getMonth(), 1);
    
    if (thisMonth.getTime() > lastMonth.getTime()) {
      // Reset monthly count on the first day of a new month
      await storage.updateExtensionSettings(userId, {
        monthlyDetectionCount: 0
      });
      settings.monthlyDetectionCount = 0;
    }
    
    // Update the counts
    await storage.updateExtensionSettings(userId, {
      dailyDetectionCount: (settings.dailyDetectionCount || 0) + 1,
      monthlyDetectionCount: (settings.monthlyDetectionCount || 0) + 1,
      detectionSuccessCount: (settings.detectionSuccessCount || 0) + (successful ? 1 : 0),
      detectionFailureCount: (settings.detectionFailureCount || 0) + (successful ? 0 : 1),
      lastResetDate: now
    });
  }

  /**
   * Reset the daily detection count
   * 
   * @param userId User ID to reset count for
   */
  private async resetDailyDetectionCount(userId: number): Promise<void> {
    await storage.updateExtensionSettings(userId, {
      dailyDetectionCount: 0,
      lastResetDate: new Date()
    });
  }

  /**
   * Calculate average confidence from rewards
   */
  private calculateAverageConfidence(rewards: DetectedReward[]): number {
    if (rewards.length === 0) return 0;
    
    return rewards.reduce((sum, reward) => sum + reward.confidence, 0) / rewards.length;
  }
}