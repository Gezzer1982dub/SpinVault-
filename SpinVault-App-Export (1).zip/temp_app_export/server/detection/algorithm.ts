/**
 * Enhanced Reward Detection Algorithm
 * 
 * This module implements advanced pattern recognition and text analysis
 * to detect gambling rewards across various websites with higher accuracy.
 * 
 * NOTE: This file is deprecated. The core functionality has been moved to index.ts
 */
interface SitePattern {
  siteName: string;
  patterns: RegExp[];
  expiryPatterns: RegExp[];
  rewardMapper: (match: string) => string;
  categoryMapper: (match: string) => RewardCategory;
}

const sitePatterns: SitePattern[] = [
  // Bet365 patterns
  {
    siteName: "Bet365",
    patterns: [
      /(?:free bet|bonus|reward|offer)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins)/i,
      /(?:£|\$|€)?(\d+(?:\.\d+)?)(?:\s+)?(?:deposit match|matched bet|matched deposit)/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours)/i,
      /available(?:\s+for)?\s+(\d+)\s+(?:days|hours)/i
    ],
    rewardMapper: (match: string): string => {
      if (match.match(/free spins/i)) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        return `${spins} Free Spins`;
      } else if (match.match(/deposit match|matched bet|matched deposit/i)) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Deposit Match`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Free Bet`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      if (match.match(/free spins/i)) {
        return RewardCategory.FREE_SPINS;
      } else if (match.match(/deposit match|matched bet|matched deposit/i)) {
        return RewardCategory.DEPOSIT_MATCH;
      } else if (match.match(/free bet/i)) {
        return RewardCategory.FREE_BET;
      } else if (match.match(/cash back|cashback/i)) {
        return RewardCategory.BONUS_CASH;
      } else {
        return RewardCategory.OTHER;
      }
    }
  },
  
  // Paddy Power patterns
  {
    siteName: "Paddy Power",
    patterns: [
      /(?:free bet|bonus|reward|offer)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
      /(\d+)(?:\s+)?(?:free spins)/i,
      /(?:£|\$|€)?(\d+(?:\.\d+)?)(?:\s+)?(?:money back|cash back)/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours)/i
    ],
    rewardMapper: (match: string): string => {
      if (match.match(/free spins/i)) {
        const spins = match.match(/(\d+)/)?.[1] || "20";
        return `${spins} Free Spins`;
      } else if (match.match(/money back|cash back/i)) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "5";
        return `£${amount} Money Back`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        return `£${amount} Free Bet`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      if (match.match(/free spins/i)) {
        return RewardCategory.FREE_SPINS;
      } else if (match.match(/money back|cash back/i)) {
        return RewardCategory.BONUS_CASH;
      } else if (match.match(/free bet/i)) {
        return RewardCategory.FREE_BET;
      } else {
        return RewardCategory.OTHER;
      }
    }
  },
  
  // Mecca Bingo patterns
  {
    siteName: "Mecca Bingo",
    patterns: [
      /(\d+)(?:\s+)?(?:free bingo tickets|bingo tickets)/i,
      /(\d+)(?:\s+)?(?:free spins)/i,
      /(?:£|\$|€)?(\d+(?:\.\d+)?)(?:\s+)?(?:bingo bonus|slots bonus)/i
    ],
    expiryPatterns: [
      /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours)/i,
      /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours)/i
    ],
    rewardMapper: (match: string): string => {
      if (match.match(/free bingo tickets|bingo tickets/i)) {
        const tickets = match.match(/(\d+)/)?.[1] || "5";
        return `${tickets} Bingo Tickets`;
      } else if (match.match(/free spins/i)) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        return `${spins} Free Spins`;
      } else {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "5";
        return `£${amount} Bingo Bonus`;
      }
    },
    categoryMapper: (match: string): RewardCategory => {
      if (match.match(/free bingo tickets|bingo tickets/i)) {
        return RewardCategory.BINGO_TICKETS;
      } else if (match.match(/free spins/i)) {
        return RewardCategory.FREE_SPINS;
      } else {
        return RewardCategory.BONUS_CASH;
      }
    }
  }
];

// Generic reward patterns that work across sites
const genericPatterns = [
  /(?:free bet|bonus|reward|offer)(?:\s+of)?\s+(?:£|\$|€)?(\d+(?:\.\d+)?)/i,
  /(\d+)(?:\s+)?(?:free spins)/i,
  /(?:£|\$|€)?(\d+(?:\.\d+)?)(?:\s+)?(?:deposit match|matched bet|cash back)/i,
  /(\d+)(?:\s+)?(?:bingo tickets|free tickets)/i,
  /(?:loyalty|reward) points:?\s+(\d+)/i
];

// Generic expiry patterns
const genericExpiryPatterns = [
  /valid(?:\s+for|until)?\s+(\d+)\s+(?:days|hours)/i,
  /expires(?:\s+in|\s+on)?\s+(\d+)\s+(?:days|hours)/i,
  /available(?:\s+for)?\s+(\d+)\s+(?:days|hours)/i,
  /valid until ([0-9]{1,2}(?:st|nd|rd|th)? [A-Za-z]+ [0-9]{4})/i,
  /expires (?:on )?([0-9]{1,2}(?:st|nd|rd|th)? [A-Za-z]+ [0-9]{4})/i,
  /expir(?:y|es|ation)(?:\s+date)?:?\s*([0-9]{1,2}\/[0-9]{1,2}\/[0-9]{2,4})/i,
  /valid until ([0-9]{1,2}\/[0-9]{1,2}\/[0-9]{2,4})/i
];

/**
 * Main detection function that analyzes content from a gambling site
 * to identify potential rewards
 * 
 * @param content Text content to analyze
 * @param url URL of the page (optional, helps with site identification)
 * @returns Detection result with any found rewards
 */
export function detectRewards(content: string, url?: string): DetectionResult {
  // Preprocess the content
  content = processTextContent(content);
  
  // Try to identify the site from the URL or content
  let siteName = identifySiteFromURL(url);
  
  // Find the matching site pattern
  const sitePattern = sitePatterns.find(pattern => 
    pattern.siteName.toLowerCase() === siteName?.toLowerCase()
  );
  
  // Detect rewards using the appropriate patterns
  let detectedRewards: DetectedReward[] = [];
  
  if (sitePattern) {
    detectedRewards = detectRewardsWithPattern(content, sitePattern);
    
    // If no rewards found with site-specific patterns, try generic patterns
    if (detectedRewards.length === 0) {
      detectedRewards = detectGenericRewards(content, sitePattern.siteName);
    }
  } else {
    // If no site pattern found, try generic detection
    detectedRewards = detectGenericRewards(content, siteName || "Unknown");
  }
  
  const result: DetectionResult = {
    success: detectedRewards.length > 0,
    rewards: detectedRewards,
    confidence: calculateOverallConfidence(detectedRewards),
    source: "pattern_detection"
  };
  
  return result;
}

/**
 * Detects rewards using site-specific patterns
 */
function detectRewardsWithPattern(content: string, sitePattern: SitePattern): DetectedReward[] {
  const rewards: DetectedReward[] = [];
  
  for (const pattern of sitePattern.patterns) {
    const matches = content.match(new RegExp(pattern, 'gi')) || [];
    
    for (const match of matches) {
      // Extract the expiry date (if available)
      const expiryDate = extractExpiryDate(content, sitePattern.expiryPatterns);
      
      // Map the matched text to a reward description
      const rewardText = sitePattern.rewardMapper(match);
      
      // Determine the category
      const category = sitePattern.categoryMapper(match);
      
      // Calculate confidence based on pattern specificity
      const confidence = 0.8; // Higher for site-specific patterns
      
      rewards.push({
        site: sitePattern.siteName,
        reward: rewardText,
        expiresAt: expiryDate,
        confidence,
        raw: match,
        category
      });
    }
  }
  
  return rewards;
}

/**
 * Detects rewards using generic patterns when site-specific detection fails
 */
function detectGenericRewards(content: string, siteName: string): DetectedReward[] {
  const rewards: DetectedReward[] = [];
  
  for (const pattern of genericPatterns) {
    const matches = content.match(new RegExp(pattern, 'gi')) || [];
    
    for (const match of matches) {
      // Extract the expiry date (if available)
      const expiryDate = extractExpiryDate(content, genericExpiryPatterns);
      
      // Determine reward text and category
      let rewardText = match;
      let category: RewardCategory = RewardCategory.OTHER;
      let confidence = 0.6; // Lower for generic patterns
      
      // Categorize based on patterns
      if (match.match(/free spins/i)) {
        const spins = match.match(/(\d+)/)?.[1] || "10";
        rewardText = `${spins} Free Spins`;
        category = RewardCategory.FREE_SPINS;
        confidence = 0.75;
      } else if (match.match(/bingo tickets/i)) {
        const tickets = match.match(/(\d+)/)?.[1] || "5";
        rewardText = `${tickets} Bingo Tickets`;
        category = RewardCategory.BINGO_TICKETS;
        confidence = 0.7;
      } else if (match.match(/deposit match|matched bet/i)) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        rewardText = `£${amount} Deposit Match`;
        category = RewardCategory.DEPOSIT_MATCH;
        confidence = 0.7;
      } else if (match.match(/free bet/i)) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "10";
        rewardText = `£${amount} Free Bet`;
        category = RewardCategory.FREE_BET;
        confidence = 0.75;
      } else if (match.match(/cash back|cashback|bonus/i)) {
        const amount = match.match(/(?:£|\$|€)?(\d+(?:\.\d+)?)/)?.[1] || "5";
        rewardText = `£${amount} Bonus Cash`;
        category = RewardCategory.BONUS_CASH;
        confidence = 0.7;
      } else if (match.match(/loyalty|reward points/i)) {
        const points = match.match(/(\d+)/)?.[1] || "100";
        rewardText = `${points} Loyalty Points`;
        category = RewardCategory.LOYALTY_POINTS;
        confidence = 0.65;
      }
      
      rewards.push({
        site: siteName,
        reward: rewardText,
        expiresAt: expiryDate,
        confidence,
        raw: match,
        category
      });
    }
  }
  
  return rewards;
}

/**
 * Extracts expiry date from content using provided patterns
 */
function extractExpiryDate(content: string, patterns: RegExp[]): Date {
  for (const pattern of patterns) {
    const match = content.match(pattern);
    
    if (match && match[1]) {
      // Try to parse the date
      if (match[1].match(/^\d+$/)) {
        // It's a number of days or hours
        const value = parseInt(match[1]);
        const unit = match[0].includes('hour') ? 'hours' : 'days';
        
        const date = new Date();
        if (unit === 'hours') {
          date.setHours(date.getHours() + value);
        } else {
          date.setDate(date.getDate() + value);
        }
        
        return date;
      } else if (match[1].includes('/')) {
        // It's a date in format DD/MM/YYYY or MM/DD/YYYY
        const parts = match[1].split('/');
        if (parts.length === 3) {
          // Try to determine the format based on value ranges
          let day: number, month: number, year: number;
          
          if (parseInt(parts[0]) > 12) {
            // First part is likely the day (DD/MM/YYYY)
            day = parseInt(parts[0]);
            month = parseInt(parts[1]) - 1; // JS months are 0-indexed
            year = parseInt(parts[2]);
            if (year < 100) year += 2000; // Handle 2-digit years
          } else {
            // First part could be month (MM/DD/YYYY) or day (DD/MM/YYYY)
            // Default to DD/MM/YYYY as it's more common in the UK
            day = parseInt(parts[0]);
            month = parseInt(parts[1]) - 1;
            year = parseInt(parts[2]);
            if (year < 100) year += 2000;
          }
          
          return new Date(year, month, day);
        }
      } else {
        // Try to parse as a natural language date
        try {
          return new Date(match[1]);
        } catch (e) {
          // If parsing fails, default to 7 days from now
          const date = new Date();
          date.setDate(date.getDate() + 7);
          return date;
        }
      }
    }
  }
  
  // Default to 7 days from now if no expiry date found
  const date = new Date();
  date.setDate(date.getDate() + 7);
  return date;
}

/**
 * Identify gambling site from URL
 */
function identifySiteFromURL(url?: string): string | null {
  if (!url) return null;
  
  // Extract domain from URL
  const domain = url.toLowerCase().match(/\/\/([^\/]+)/)?.[1] || url.toLowerCase();
  
  // Match domain to known gambling sites
  if (domain.includes('bet365')) return 'Bet365';
  if (domain.includes('paddypower')) return 'Paddy Power';
  if (domain.includes('skybet')) return 'Sky Bet';
  if (domain.includes('williamhill')) return 'William Hill';
  if (domain.includes('coral')) return 'Coral';
  if (domain.includes('ladbrokes')) return 'Ladbrokes';
  if (domain.includes('meccabingo')) return 'Mecca Bingo';
  if (domain.includes('betfred')) return 'Betfred';
  if (domain.includes('heartbingo')) return 'Heart Bingo';
  if (domain.includes('888casino')) return '888 Casino';
  if (domain.includes('888poker')) return '888 Poker';
  if (domain.includes('888sport')) return '888 Sport';
  
  // Unknown site
  return null;
}

/**
 * Calculate overall confidence based on individual reward confidences
 */
function calculateOverallConfidence(rewards: DetectedReward[]): number {
  if (rewards.length === 0) return 0;
  
  // Calculate weighted average of confidences
  let totalConfidence = 0;
  
  for (const reward of rewards) {
    totalConfidence += reward.confidence;
  }
  
  return totalConfidence / rewards.length;
}

/**
 * Process text content using advanced techniques like NLP
 * This could be expanded with more sophisticated text processing in the future
 */
export function processTextContent(content: string): string {
  // Basic preprocessing
  let processed = content;
  
  // Convert HTML to plain text (very simplistic implementation)
  processed = processed.replace(/<[^>]*>/g, ' ');
  
  // Remove extra whitespace
  processed = processed.replace(/\s+/g, ' ').trim();
  
  return processed;
}

/**
 * Screen capture processing for mobile app
 * This would integrate with the image recognition API in a real implementation
 */
export async function processScreenCapture(imageData: string): Promise<string> {
  // This is a simplified mock implementation
  // In a real app, this would use OCR to extract text from the image
  
  // For testing purposes only, return some extracted text
  return "Welcome to Bet365. Your bonus: £10 free bet. Valid for 7 days.";
}