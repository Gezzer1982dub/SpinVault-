import { 
  users, type User, type InsertUser, 
  rewards, type Reward, type InsertReward, type UpdateReward,
  customCategories, type CustomCategory, type InsertCustomCategory, type UpdateCustomCategory,
  extensionSettings, type ExtensionSettings, type InsertExtensionSettings,
  offerings, type Offering, type InsertOffering, type UpdateOffering,
  notifications, type Notification, type InsertNotification, type UpdateNotification
} from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db } from "./db";
import { eq, and, sql, desc } from "drizzle-orm";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPremiumStatus(id: number, isPremium: boolean, expiryDate?: Date): Promise<User | undefined>;
  
  // Stripe operations
  updateStripeCustomerId(id: number, stripeCustomerId: string): Promise<User | undefined>;
  updateUserStripeInfo(id: number, stripeInfo: { stripeCustomerId: string, stripeSubscriptionId: string }): Promise<User | undefined>;
  updateUserEmail(id: number, email: string): Promise<User | undefined>;
  
  // Reward operations
  getRewards(userId: number): Promise<Reward[]>;
  getReward(id: number): Promise<Reward | undefined>;
  createReward(reward: InsertReward): Promise<Reward>;
  updateReward(id: number, userId: number, reward: UpdateReward): Promise<Reward | undefined>;
  deleteReward(id: number, userId: number): Promise<boolean>;
  
  // Custom category operations
  getCustomCategories(userId: number): Promise<CustomCategory[]>;
  getCustomCategory(id: number): Promise<CustomCategory | undefined>;
  createCustomCategory(category: InsertCustomCategory): Promise<CustomCategory>;
  updateCustomCategory(id: number, userId: number, category: UpdateCustomCategory): Promise<CustomCategory | undefined>;
  deleteCustomCategory(id: number, userId: number): Promise<boolean>;
  
  // Extension settings operations
  getExtensionSettings(userId: number): Promise<ExtensionSettings | undefined>;
  createExtensionSettings(settings: InsertExtensionSettings): Promise<ExtensionSettings>;
  updateExtensionSettings(userId: number, settings: any): Promise<ExtensionSettings | undefined>;
  
  // Social insights operations
  getAnonymizedRewardStats(): Promise<any>;
  getRewardLeaderboard(): Promise<any[]>;
  getTrendingRewardData(): Promise<any>;
  
  // User daily reward summary
  getUserDailyRewardSummary(userId: number): Promise<any>;
  
  // Public offerings operations
  getOfferings(filters?: { 
    isNewMemberOffer?: boolean; 
    category?: string;
    site?: string;
  }): Promise<Offering[]>;
  getOffering(id: number): Promise<Offering | undefined>;
  createOffering(offering: InsertOffering): Promise<Offering>;
  updateOffering(id: number, offering: UpdateOffering): Promise<Offering | undefined>;
  deleteOffering(id: number): Promise<boolean>;
  
  // Notification operations
  getNotifications(userId: number, filters?: { status?: string; type?: string }): Promise<Notification[]>;
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  updateNotification(id: number, notification: UpdateNotification): Promise<Notification | undefined>;
  markNotificationAsRead(id: number, userId: number): Promise<Notification | undefined>;
  markAllNotificationsAsRead(userId: number): Promise<boolean>;
  deleteNotification(id: number, userId: number): Promise<boolean>;
  getUnreadNotificationsCount(userId: number): Promise<number>;
  getPendingNotifications(): Promise<Notification[]>;
  getExpiringRewardsForNotification(daysThreshold: number): Promise<any[]>;
  
  sessionStore: any; // Using any type to avoid session store type issues
}

export class DatabaseStorage implements IStorage {
  public sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0] || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0] || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async updateUserPremiumStatus(id: number, isPremium: boolean, expiryDate?: Date): Promise<User | undefined> {
    const result = await db.update(users)
      .set({
        isPremium,
        premiumExpiresAt: expiryDate 
      })
      .where(eq(users.id, id))
      .returning();
    
    return result[0] || undefined;
  }
  
  async updateStripeCustomerId(id: number, stripeCustomerId: string): Promise<User | undefined> {
    const result = await db.update(users)
      .set({ stripeCustomerId })
      .where(eq(users.id, id))
      .returning();
    
    return result[0] || undefined;
  }
  
  async updateUserStripeInfo(id: number, stripeInfo: { stripeCustomerId: string, stripeSubscriptionId: string }): Promise<User | undefined> {
    const result = await db.update(users)
      .set({
        stripeCustomerId: stripeInfo.stripeCustomerId,
        stripeSubscriptionId: stripeInfo.stripeSubscriptionId
      })
      .where(eq(users.id, id))
      .returning();
    
    return result[0] || undefined;
  }
  
  async updateUserEmail(id: number, email: string): Promise<User | undefined> {
    const result = await db.update(users)
      .set({ email })
      .where(eq(users.id, id))
      .returning();
    
    return result[0] || undefined;
  }

  async getRewards(userId: number): Promise<Reward[]> {
    return await db.select().from(rewards).where(eq(rewards.userId, userId));
  }

  async getReward(id: number): Promise<Reward | undefined> {
    const result = await db.select().from(rewards).where(eq(rewards.id, id));
    return result[0] || undefined;
  }

  async createReward(insertReward: InsertReward): Promise<Reward> {
    // Set default values if not provided
    const now = new Date();
    const rewardData = {
      ...insertReward,
      createdAt: insertReward.createdAt || now,
      expiresAt: insertReward.expiresAt || new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000), // Default 7 days
      claimed: insertReward.claimed !== undefined ? insertReward.claimed : false,
      category: insertReward.category || "OTHER"
    };
    
    const result = await db.insert(rewards).values(rewardData).returning();
    return result[0];
  }

  async updateReward(id: number, userId: number, updateData: UpdateReward): Promise<Reward | undefined> {
    const result = await db.update(rewards)
      .set(updateData)
      .where(and(eq(rewards.id, id), eq(rewards.userId, userId)))
      .returning();
    
    return result[0] || undefined;
  }

  async deleteReward(id: number, userId: number): Promise<boolean> {
    const result = await db.delete(rewards)
      .where(and(eq(rewards.id, id), eq(rewards.userId, userId)))
      .returning();
    
    return result.length > 0;
  }

  // Custom category methods
  async getCustomCategories(userId: number): Promise<CustomCategory[]> {
    return await db.select().from(customCategories).where(eq(customCategories.userId, userId));
  }

  async getCustomCategory(id: number): Promise<CustomCategory | undefined> {
    const result = await db.select().from(customCategories).where(eq(customCategories.id, id));
    return result[0] || undefined;
  }

  async createCustomCategory(category: InsertCustomCategory): Promise<CustomCategory> {
    const result = await db.insert(customCategories).values({
      ...category,
      createdAt: new Date()
    }).returning();
    
    return result[0];
  }

  async updateCustomCategory(id: number, userId: number, category: UpdateCustomCategory): Promise<CustomCategory | undefined> {
    const result = await db.update(customCategories)
      .set(category)
      .where(and(eq(customCategories.id, id), eq(customCategories.userId, userId)))
      .returning();
    
    return result[0] || undefined;
  }

  async deleteCustomCategory(id: number, userId: number): Promise<boolean> {
    // First, update any rewards using this category to use the default "OTHER" category
    await db.update(rewards)
      .set({ 
        customCategoryId: null,
        category: "OTHER" 
      })
      .where(and(
        eq(rewards.customCategoryId, id), 
        eq(rewards.userId, userId)
      ));
    
    // Then delete the custom category
    const result = await db.delete(customCategories)
      .where(and(eq(customCategories.id, id), eq(customCategories.userId, userId)))
      .returning();
    
    return result.length > 0;
  }

  // Extension settings methods
  async getExtensionSettings(userId: number): Promise<ExtensionSettings | undefined> {
    try {
      const result = await db.select()
        .from(extensionSettings)
        .where(eq(extensionSettings.userId, userId));
      
      // If no settings exist, return undefined
      if (!result[0]) {
        return undefined;
      }
      
      // Return the settings as they are from the database
      // The settings field already contains all the necessary data
      return result[0];
    } catch (error) {
      console.error("Error getting extension settings:", error);
      return undefined;
    }
  }

  async createExtensionSettings(settingsData: InsertExtensionSettings): Promise<ExtensionSettings> {
    try {
      // Handle nested settings safely with type checking
      const settingsObj = settingsData.settings as Record<string, any> || {};
      
      // Extract settings with type safety
      const enabledSites = Array.isArray(settingsObj.enabledSites) ? 
        settingsObj.enabledSites : 
        ['Bet365', 'William Hill', 'Paddy Power'];
      const autoSyncEnabled = typeof settingsObj.autoSyncEnabled === 'boolean' ? 
        settingsObj.autoSyncEnabled : 
        true;
      const notificationsEnabled = typeof settingsObj.notificationsEnabled === 'boolean' ? 
        settingsObj.notificationsEnabled : 
        true;
      const detectionSettings = typeof settingsObj.detectionSettings === 'object' ? 
        settingsObj.detectionSettings || {} : 
        {};

      // Convert from our schema format to the database format
      const dbData = {
        userId: settingsData.userId,
        dailyDetectionCount: settingsData.dailyDetectionCount || 0,
        lastDetectionReset: settingsData.lastDetectionReset || new Date(),
        // Store settings as a JSON object in the settings column
        settings: {
          enabledSites,
          autoSyncEnabled,
          notificationsEnabled,
          detectionSettings
        },
        updatedAt: new Date()
      };
      
      const result = await db.insert(extensionSettings)
        .values(dbData)
        .returning();
      
      return result[0];
    } catch (error) {
      console.error("Error creating extension settings:", error);
      throw error;
    }
  }

  async updateExtensionSettings(userId: number, settingsData: any): Promise<ExtensionSettings | undefined> {
    try {
      // First check if settings exist
      const existing = await this.getExtensionSettings(userId);
      
      if (!existing) {
        // Create new settings if they don't exist
        const settingsObj = settingsData.settings as Record<string, any> || {};
        
        return await this.createExtensionSettings({
          userId,
          settings: {
            enabledSites: settingsObj.enabledSites || settingsData.enabledSites || ['Bet365', 'William Hill', 'Paddy Power'],
            autoSyncEnabled: settingsObj.autoSyncEnabled !== undefined ? settingsObj.autoSyncEnabled : (settingsData.autoSyncEnabled !== false),
            notificationsEnabled: settingsObj.notificationsEnabled !== undefined ? settingsObj.notificationsEnabled : (settingsData.notificationsEnabled !== false),
            detectionSettings: settingsObj.detectionSettings || settingsData.detectionSettings || {}
          },
          dailyDetectionCount: settingsData.dailyDetectionCount || 0,
          lastDetectionReset: settingsData.lastDetectionReset || new Date()
        });
      }
      
      // Extract settings from existing data
      const existingSettings = existing.settings as Record<string, any> || {};
      
      // Handle both formats - direct properties or nested in settings property
      const settingsObj = settingsData.settings as Record<string, any> || {};
      
      // Update existing settings
      // For the database, combine the settings into a JSON object
      const result = await db.update(extensionSettings)
        .set({
          // Keep dailyDetectionCount as a separate column
          dailyDetectionCount: settingsData.dailyDetectionCount !== undefined ? 
            settingsData.dailyDetectionCount : 
            (existing.dailyDetectionCount || 0),
            
          // Update the settings JSON object
          settings: {
            enabledSites: settingsObj.enabledSites || settingsData.enabledSites || 
              (existingSettings.enabledSites || ['Bet365', 'William Hill', 'Paddy Power']),
            autoSyncEnabled: settingsObj.autoSyncEnabled !== undefined ? 
              settingsObj.autoSyncEnabled : 
              (settingsData.autoSyncEnabled !== undefined ? 
                settingsData.autoSyncEnabled : 
                (existingSettings.autoSyncEnabled !== false)),
            notificationsEnabled: settingsObj.notificationsEnabled !== undefined ? 
              settingsObj.notificationsEnabled : 
              (settingsData.notificationsEnabled !== undefined ? 
                settingsData.notificationsEnabled : 
                (existingSettings.notificationsEnabled !== false)),
            detectionSettings: settingsObj.detectionSettings || settingsData.detectionSettings || 
              (existingSettings.detectionSettings || {})
          },
          updatedAt: new Date()
        })
        .where(eq(extensionSettings.userId, userId))
        .returning();
      
      // Just return the database result as is
      return result[0];
    } catch (error) {
      console.error("Error updating extension settings:", error);
      return undefined;
    }
  }
  
  // Social insights methods
  async getAnonymizedRewardStats(): Promise<any> {
    // Aggregate data about reward types and categories across all users
    // We're using SQL here for complex aggregations
    const categoryStats = await db.execute(sql`
      SELECT 
        category, 
        COUNT(*) as count,
        MAX(created_at) as latest,
        AVG(CASE WHEN claimed = true THEN 1 ELSE 0 END) as claim_rate
      FROM rewards
      GROUP BY category
      ORDER BY count DESC
    `);
    
    const siteStats = await db.execute(sql`
      SELECT 
        site, 
        COUNT(*) as count
      FROM rewards
      GROUP BY site
      ORDER BY count DESC
      LIMIT 10
    `);
    
    const monthlyCounts = await db.execute(sql`
      SELECT 
        DATE_TRUNC('month', created_at) as month,
        COUNT(*) as count
      FROM rewards
      WHERE created_at > NOW() - INTERVAL '6 months'
      GROUP BY month
      ORDER BY month
    `);
    
    const expiryData = await db.execute(sql`
      SELECT 
        AVG(EXTRACT(EPOCH FROM (expires_at - created_at)) / 86400)::numeric(10,1) as avg_days_valid,
        COUNT(CASE WHEN expires_at < NOW() AND claimed = false THEN 1 END) as expired_unclaimed,
        COUNT(CASE WHEN expires_at > NOW() THEN 1 END) as active
      FROM rewards
    `);
    
    return {
      categories: categoryStats.rows,
      sites: siteStats.rows,
      monthly: monthlyCounts.rows,
      expiry: expiryData.rows[0]
    };
  }
  
  async getRewardLeaderboard(): Promise<any[]> {
    // Get top users by number of rewards found
    // Anonymized in the route handler
    const leaderboard = await db.execute(sql`
      SELECT 
        u.id,
        COUNT(r.id) as reward_count,
        SUM(CASE 
          WHEN r.category = 'FREE_SPINS' THEN 5
          WHEN r.category = 'BONUS_CASH' THEN 10
          WHEN r.category = 'DEPOSIT_MATCH' THEN 15
          WHEN r.category = 'FREE_BET' THEN 10
          WHEN r.category = 'BINGO_TICKETS' THEN 5
          WHEN r.category = 'LOYALTY_POINTS' THEN 2
          ELSE 1
        END) as total_value
      FROM users u
      JOIN rewards r ON u.id = r.user_id
      GROUP BY u.id
      ORDER BY reward_count DESC
      LIMIT 20
    `);
    
    return leaderboard.rows;
  }
  
  async getTrendingRewardData(): Promise<any> {
    // Get trending data over the last 7 days
    const trending = await db.execute(sql`
      WITH recent_rewards AS (
        SELECT *
        FROM rewards
        WHERE created_at > NOW() - INTERVAL '7 days'
      )
      
      SELECT 
        'sites' as type,
        json_agg(
          json_build_object(
            'name', r_site,
            'count', count,
            'trend', trend
          )
        ) as data
      FROM (
        SELECT 
          r.site as r_site,
          COUNT(*) as count,
          CASE 
            WHEN prev_count = 0 THEN 100
            ELSE ROUND(((COUNT(*) - prev_count) * 100.0 / prev_count)::numeric, 2)
          END as trend
        FROM recent_rewards r
        LEFT JOIN (
          SELECT 
            site as prev_site,
            COUNT(*) as prev_count
          FROM rewards
          WHERE 
            created_at BETWEEN NOW() - INTERVAL '14 days' AND NOW() - INTERVAL '7 days'
          GROUP BY prev_site
        ) prev ON r.site = prev.prev_site
        GROUP BY r.site, prev_count
        ORDER BY count DESC
        LIMIT 5
      ) sites
      
      UNION ALL
      
      SELECT 
        'categories' as type,
        json_agg(
          json_build_object(
            'name', r_category,
            'count', count,
            'trend', trend
          )
        ) as data
      FROM (
        SELECT 
          r.category as r_category,
          COUNT(*) as count,
          CASE 
            WHEN prev_count = 0 THEN 100
            ELSE ROUND(((COUNT(*) - prev_count) * 100.0 / prev_count)::numeric, 2)
          END as trend
        FROM recent_rewards r
        LEFT JOIN (
          SELECT 
            category as prev_category,
            COUNT(*) as prev_count
          FROM rewards
          WHERE 
            created_at BETWEEN NOW() - INTERVAL '14 days' AND NOW() - INTERVAL '7 days'
          GROUP BY prev_category
        ) prev ON r.category = prev.prev_category
        GROUP BY r.category, prev_count
        ORDER BY count DESC
        LIMIT 5
      ) categories
    `);
    
    // Format the return data
    const result = trending.rows.reduce<Record<string, any>>((acc, row: any) => {
      if (row && typeof row.type === 'string') {
        acc[row.type] = row.data;
      }
      return acc;
    }, {});
    
    return result;
  }
  
  /**
   * Get a user's daily reward summary with accumulation over time
   */
  async getUserDailyRewardSummary(userId: number): Promise<any> {
    // Get daily reward counts for the past 30 days
    const dailyRewards = await db.execute(sql`
      SELECT 
        DATE_TRUNC('day', created_at) as day,
        COUNT(*) as count,
        json_agg(
          json_build_object(
            'id', id,
            'site', site,
            'reward', reward,
            'category', category,
            'claimed', claimed
          )
        ) as rewards
      FROM rewards
      WHERE 
        user_id = ${userId} AND
        created_at > NOW() - INTERVAL '30 days'
      GROUP BY day
      ORDER BY day DESC
    `);
    
    // Get rewards by category for this user
    const categoryCounts = await db.execute(sql`
      SELECT 
        category,
        COUNT(*) as count,
        COUNT(CASE WHEN claimed = true THEN 1 END) as claimed_count,
        MAX(created_at) as latest
      FROM rewards
      WHERE user_id = ${userId}
      GROUP BY category
      ORDER BY count DESC
    `);
    
    // Get rewards by site for this user
    const siteCounts = await db.execute(sql`
      SELECT 
        site,
        COUNT(*) as count,
        MAX(created_at) as latest_reward
      FROM rewards
      WHERE user_id = ${userId}
      GROUP BY site
      ORDER BY count DESC
      LIMIT 10
    `);
    
    // Get expiring rewards info
    const expiryInfo = await db.execute(sql`
      SELECT 
        COUNT(CASE WHEN expires_at < NOW() THEN 1 END) as expired,
        COUNT(CASE WHEN 
          expires_at > NOW() AND 
          expires_at < NOW() + INTERVAL '7 days' 
        THEN 1 END) as expiring_soon,
        COUNT(CASE WHEN expires_at > NOW() THEN 1 END) as active
      FROM rewards
      WHERE user_id = ${userId}
    `);
    
    // Calculate value metrics
    const valueMetrics = await db.execute(sql`
      WITH reward_values AS (
        SELECT 
          id,
          category,
          CASE 
            WHEN category = 'FREE_SPINS' THEN 5
            WHEN category = 'BONUS_CASH' THEN 10
            WHEN category = 'DEPOSIT_MATCH' THEN 15
            WHEN category = 'FREE_BET' THEN 10
            WHEN category = 'BINGO_TICKETS' THEN 5
            WHEN category = 'LOYALTY_POINTS' THEN 2
            ELSE 1
          END as value
        FROM rewards
        WHERE user_id = ${userId}
      )
      SELECT 
        SUM(value) as total_value,
        AVG(value) as avg_value,
        SUM(value) / COUNT(DISTINCT DATE_TRUNC('day', r.created_at)) as value_per_day
      FROM reward_values rv
      JOIN rewards r ON rv.id = r.id
      WHERE r.created_at > NOW() - INTERVAL '30 days'
    `);
    
    return {
      daily: dailyRewards.rows,
      categories: categoryCounts.rows,
      sites: siteCounts.rows,
      expiry: expiryInfo.rows[0],
      value: valueMetrics.rows[0]
    };
  }
  
  // Public offerings methods
  async getOfferings(filters?: { 
    isNewMemberOffer?: boolean; 
    category?: string;
    site?: string;
  }): Promise<Offering[]> {
    let query = db.select().from(offerings);
    
    // Apply filters if provided
    if (filters) {
      if (filters.isNewMemberOffer !== undefined) {
        query = query.where(eq(offerings.isNewMemberOffer, filters.isNewMemberOffer));
      }
      
      if (filters.category) {
        query = query.where(eq(offerings.category, filters.category));
      }
      
      if (filters.site) {
        query = query.where(eq(offerings.site, filters.site));
      }
    }
    
    // Order by newest first
    query = query.orderBy(desc(offerings.detectedAt));
    
    return await query;
  }
  
  async getOffering(id: number): Promise<Offering | undefined> {
    const result = await db.select().from(offerings).where(eq(offerings.id, id));
    return result[0] || undefined;
  }
  
  async createOffering(insertOffering: InsertOffering): Promise<Offering> {
    const now = new Date();
    const offeringData = {
      ...insertOffering,
      detectedAt: insertOffering.detectedAt || now,
      updatedAt: insertOffering.updatedAt || now
    };
    
    const result = await db.insert(offerings).values(offeringData).returning();
    return result[0];
  }
  
  async updateOffering(id: number, updateData: UpdateOffering): Promise<Offering | undefined> {
    const result = await db.update(offerings)
      .set({
        ...updateData,
        updatedAt: new Date()
      })
      .where(eq(offerings.id, id))
      .returning();
    
    return result[0] || undefined;
  }
  
  async deleteOffering(id: number): Promise<boolean> {
    const result = await db.delete(offerings)
      .where(eq(offerings.id, id))
      .returning();
    
    return result.length > 0;
  }
  
  // Notification operations
  async getNotifications(userId: number, filters?: { status?: string; type?: string }): Promise<Notification[]> {
    try {
      let query = db.select().from(notifications).where(eq(notifications.userId, userId));
      
      if (filters) {
        if (filters.status) {
          query = query.where(eq(notifications.status, filters.status));
        }
        
        if (filters.type) {
          query = query.where(eq(notifications.type, filters.type));
        }
      }
      
      // Order by most recent first
      return await query.orderBy(desc(notifications.createdAt));
    } catch (error) {
      console.error("Error getting notifications:", error);
      return [];
    }
  }
  
  async getNotification(id: number): Promise<Notification | undefined> {
    try {
      const result = await db.select().from(notifications).where(eq(notifications.id, id));
      return result[0] || undefined;
    } catch (error) {
      console.error("Error getting notification:", error);
      return undefined;
    }
  }
  
  async createNotification(notification: InsertNotification): Promise<Notification> {
    try {
      const now = new Date();
      const notificationData = {
        ...notification,
        createdAt: now
      };
      
      const result = await db.insert(notifications).values(notificationData).returning();
      return result[0];
    } catch (error) {
      console.error("Error creating notification:", error);
      throw error;
    }
  }
  
  async updateNotification(id: number, updateData: UpdateNotification): Promise<Notification | undefined> {
    try {
      const result = await db.update(notifications)
        .set(updateData)
        .where(eq(notifications.id, id))
        .returning();
      
      return result[0] || undefined;
    } catch (error) {
      console.error("Error updating notification:", error);
      return undefined;
    }
  }
  
  async markNotificationAsRead(id: number, userId: number): Promise<Notification | undefined> {
    try {
      const now = new Date();
      
      const result = await db.update(notifications)
        .set({
          status: "READ",
          readAt: now
        })
        .where(and(eq(notifications.id, id), eq(notifications.userId, userId)))
        .returning();
      
      return result[0] || undefined;
    } catch (error) {
      console.error("Error marking notification as read:", error);
      return undefined;
    }
  }
  
  async markAllNotificationsAsRead(userId: number): Promise<boolean> {
    try {
      const now = new Date();
      
      await db.update(notifications)
        .set({
          status: "READ",
          readAt: now
        })
        .where(and(
          eq(notifications.userId, userId),
          eq(notifications.status, "SENT")
        ));
      
      return true;
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      return false;
    }
  }
  
  async deleteNotification(id: number, userId: number): Promise<boolean> {
    try {
      const result = await db.delete(notifications)
        .where(and(eq(notifications.id, id), eq(notifications.userId, userId)))
        .returning();
      
      return result.length > 0;
    } catch (error) {
      console.error("Error deleting notification:", error);
      return false;
    }
  }
  
  async getUnreadNotificationsCount(userId: number): Promise<number> {
    try {
      const result = await db.select({ count: sql`COUNT(*)` })
        .from(notifications)
        .where(and(
          eq(notifications.userId, userId),
          eq(notifications.status, "SENT")
        ));
      
      return parseInt(result[0].count as any, 10) || 0;
    } catch (error) {
      console.error("Error getting unread notification count:", error);
      return 0;
    }
  }
  
  async getPendingNotifications(): Promise<Notification[]> {
    try {
      const now = new Date();
      
      // Get all pending notifications that are scheduled to be sent now or in the past
      return await db.select()
        .from(notifications)
        .where(and(
          eq(notifications.status, "PENDING"),
          sql`${notifications.scheduledFor} <= ${now}`
        ))
        .orderBy(notifications.scheduledFor);
    } catch (error) {
      console.error("Error getting pending notifications:", error);
      return [];
    }
  }
  
  async getExpiringRewardsForNotification(daysThreshold: number): Promise<any[]> {
    try {
      const now = new Date();
      const thresholdDate = new Date(now.getTime() + (daysThreshold * 24 * 60 * 60 * 1000));
      
      // Get rewards that are expiring within the threshold days and not claimed
      const result = await db.select({
        rewardId: rewards.id,
        userId: rewards.userId,
        reward: rewards.reward,
        site: rewards.site,
        expiresAt: rewards.expiresAt,
        daysUntilExpiry: sql`EXTRACT(EPOCH FROM (${rewards.expiresAt} - NOW())) / 86400`
      })
      .from(rewards)
      .where(and(
        sql`${rewards.expiresAt} <= ${thresholdDate}`,
        sql`${rewards.expiresAt} > ${now}`,
        eq(rewards.claimed, false)
      ))
      .orderBy(rewards.expiresAt);
      
      return result;
    } catch (error) {
      console.error("Error getting expiring rewards for notification:", error);
      return [];
    }
  }
}

export const storage = new DatabaseStorage();
