import OpenAI from "openai";
import { RewardCategory } from "@shared/schema";

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. Do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface RewardAnalysis {
  estimatedValue: number;       // Monetary value in GBP
  expectedROI: number;          // Return on investment as percentage (0-100)
  difficulty: number;           // Scale of 1-10
  timeRequired: number;         // Minutes required to claim and use
  recommendedAction: string;    // Short suggestion on how to best use this reward
  tags: string[];               // Keywords associated with this reward
  confidence: number;           // Confidence in analysis (0-1)
}

export interface EnhancedReward {
  site: string;
  reward: string;
  expiresAt: Date;
  category: string | null;
  analysis: RewardAnalysis;
}

/**
 * Analyze a reward using GPT-4o to estimate its true value and provide insights
 */
export async function analyzeRewardValue(
  site: string, 
  rewardText: string, 
  category: string | null,
  expiresAt: Date
): Promise<RewardAnalysis> {
  try {
    const expiryTimeframe = getTimeframeDescription(expiresAt);
    const defaultCategory = category || 'unknown';

    // Construct the prompt for OpenAI
    const prompt = `
    As a gambling rewards expert, analyze this reward offer and provide an objective assessment:

    REWARD DETAILS:
    - Website: ${site}
    - Reward description: "${rewardText}"
    - Category: ${defaultCategory}
    - Expires: ${expiryTimeframe}

    Provide a detailed analysis in JSON format with the following structure:
    1. estimatedValue: The approximate monetary value in GBP (£)
    2. expectedROI: Percentage return on investment accounting for wagering requirements (0-100)
    3. difficulty: How difficult it is to claim the full value on a scale of 1-10
    4. timeRequired: Estimated minutes required to claim and use this reward effectively
    5. recommendedAction: Short, specific recommendation on how to maximize value
    6. tags: 3-5 keywords that describe this reward (e.g., "low-risk", "time-intensive")
    7. confidence: Your confidence in this analysis on a scale of 0 to 1

    Consider wagering requirements, time constraints, and practical limitations. Be objective and realistic.
    `;

    // Call the OpenAI API
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.2  // Lower temperature for more factual responses
    });

    // Parse the response
    const analysisText = response.choices[0].message.content;
    if (!analysisText) {
      throw new Error("Empty response from OpenAI");
    }

    const analysis = JSON.parse(analysisText) as RewardAnalysis;

    // Ensure all fields exist and have reasonable values
    return {
      estimatedValue: Math.max(0, Number(analysis.estimatedValue) || 0),
      expectedROI: Math.min(100, Math.max(0, Number(analysis.expectedROI) || 0)),
      difficulty: Math.min(10, Math.max(1, Number(analysis.difficulty) || 5)),
      timeRequired: Math.max(1, Number(analysis.timeRequired) || 10),
      recommendedAction: analysis.recommendedAction || "Consider claiming this reward if it matches your play style",
      tags: Array.isArray(analysis.tags) ? analysis.tags.slice(0, 5) : ["general", "reward"],
      confidence: Math.min(1, Math.max(0.1, Number(analysis.confidence) || 0.7))
    };
  } catch (error) {
    console.error("Error analyzing reward value:", error);
    
    // Return a fallback analysis if the API call fails
    return {
      estimatedValue: 0,
      expectedROI: 0, 
      difficulty: 5,
      timeRequired: 10,
      recommendedAction: "Unable to analyze this reward",
      tags: ["unanalyzed"],
      confidence: 0.1
    };
  }
}

/**
 * Generate a human-readable description of the timeframe until expiry
 */
function getTimeframeDescription(expiryDate: Date): string {
  const now = new Date();
  const diffMs = expiryDate.getTime() - now.getTime();
  
  // If the reward has already expired
  if (diffMs <= 0) {
    return "already expired";
  }

  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  
  if (diffDays > 30) {
    const diffMonths = Math.floor(diffDays / 30);
    return `in about ${diffMonths} month${diffMonths > 1 ? 's' : ''}`;
  } else if (diffDays > 0) {
    return `in ${diffDays} day${diffDays > 1 ? 's' : ''}`;
  } else {
    return `in ${diffHours} hour${diffHours > 1 ? 's' : ''}`;
  }
}

/**
 * Generate reward claiming tips based on the category
 */
export function getClaimingTips(category: string | null): string[] {
  const generalTips = [
    "Read the terms and conditions carefully before claiming",
    "Check for any wagering requirements before withdrawing winnings",
    "Some rewards require a specific deposit method to qualify"
  ];

  if (!category) return generalTips;

  switch (category) {
    case RewardCategory.FREE_SPINS:
      return [
        "Free spins often apply to specific games only",
        "Check if there's a cap on potential winnings",
        "Some sites require you to use free spins within 24 hours of claiming"
      ];
    case RewardCategory.BONUS_CASH:
      return [
        "Bonus cash typically comes with wagering requirements",
        "Some games may contribute less toward wagering requirements",
        "Check if there's a maximum withdrawal limit for bonus winnings"
      ];
    case RewardCategory.DEPOSIT_MATCH:
      return [
        "Calculate the minimum deposit needed to maximize the match",
        "Some deposit matches are split across multiple deposits",
        "Check for any payment method restrictions"
      ];
    case RewardCategory.FREE_BET:
      return [
        "Free bets often don't return the stake in winnings",
        "Check minimum odds requirements for qualifying bets",
        "Some free bets expire quickly after being credited"
      ];
    case RewardCategory.BINGO_TICKETS:
      return [
        "Check which bingo rooms the tickets can be used in",
        "Some tickets are only valid for specific game sessions",
        "Look for restrictions on the number of tickets per game"
      ];
    default:
      return generalTips;
  }
}

/**
 * Get a value range description based on the estimated value
 */
export function getValueRangeDescription(value: number): string {
  if (value <= 0) return "Unknown value";
  if (value < 5) return "Low value";
  if (value < 20) return "Moderate value";
  if (value < 50) return "Good value";
  if (value < 100) return "High value";
  return "Exceptional value";
}

/**
 * Generate personalized recommendation based on analysis
 */
export function generateRecommendation(analysis: RewardAnalysis): string {
  if (analysis.confidence < 0.4) {
    return "Insufficient data to provide a confident recommendation";
  }

  if (analysis.estimatedValue > 50 && analysis.expectedROI > 70) {
    return "High-value opportunity! Prioritize claiming this reward.";
  }

  if (analysis.difficulty > 8 && analysis.timeRequired > 30) {
    return "Complex reward with significant time investment required.";
  }

  if (analysis.expectedROI < 30) {
    return "Low expected return on investment. Consider other rewards first.";
  }

  if (analysis.timeRequired < 10 && analysis.estimatedValue > 10) {
    return "Quick to claim with decent value. Good for busy players.";
  }

  return "Average reward - claim if it aligns with your gambling preferences.";
}