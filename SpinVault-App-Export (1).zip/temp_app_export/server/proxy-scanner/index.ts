/**
 * Proxy Scanner for SpinVault
 * 
 * This module handles server-side scanning of gambling websites to detect rewards.
 * It uses a headless browser to access sites and extract promotions.
 */
import fetch from 'node-fetch';
import { storage } from '../storage';
import { RewardCategory } from '@shared/schema';
import * as cheerio from 'cheerio';
import * as cron from 'node-cron';

// Types for detected rewards
export interface DetectedReward {
  site: string;
  reward: string;
  category: RewardCategory;
  expiresAt: Date;
  url: string;
  description?: string;
  isNewMemberOffer: boolean;
}

// Site configuration for scanning
interface SiteConfig {
  name: string;
  url: string;
  promoSelectors: string[];
  promoUrlPatterns: string[];
  offerKeywords: string[];
}

// Gambling site configurations
const GAMBLING_SITES: SiteConfig[] = [
  {
    name: 'Bet365',
    url: 'https://www.bet365.com/#/AS/B1/',
    promoSelectors: ['.promotion-item', '.promo-pod', '[class*="OfferContainer"]'],
    promoUrlPatterns: ['/promotions', '/offers', '/bonus'],
    offerKeywords: ['free bet', 'bonus', 'offer', 'promotion', 'cash out']
  },
  {
    name: 'Paddy Power',
    url: 'https://www.paddypower.com/promotions',
    promoSelectors: ['.promotion-card', '.promo-card', '.offers-card'],
    promoUrlPatterns: ['/promotions', '/offers', '/free-bets'],
    offerKeywords: ['free bet', 'bonus', 'offer', 'power price', 'odds boost']
  },
  {
    name: 'Sky Bet',
    url: 'https://www.skybet.com/promotions',
    promoSelectors: ['.promo', '.promotion', '[data-testid*="promo"]'],
    promoUrlPatterns: ['/promotions', '/offers', '/free-bets'],
    offerKeywords: ['free bet', 'price boost', 'enhanced odds', 'money back']
  },
  {
    name: 'William Hill',
    url: 'https://www.williamhill.com/en-gb/offers',
    promoSelectors: ['[data-testid*="promotion"]', '[class*="promotion"]', '[class*="offer"]'],
    promoUrlPatterns: ['/offers', '/promotions', '/bonus'],
    offerKeywords: ['free bet', 'acca boost', 'enhanced odds', 'money back']
  },
  {
    name: 'Ladbrokes',
    url: 'https://www.ladbrokes.com/en/sports/promotions',
    promoSelectors: ['.promo-card', '.promotion', '[data-test-id*="promo"]'],
    promoUrlPatterns: ['/promotions', '/offers', '/free-bets'],
    offerKeywords: ['free bet', 'money back', 'odds boost', 'extra places']
  }
];

/**
 * Get a random user agent to avoid detection
 */
function getRandomUserAgent(): string {
  const userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1'
  ];
  
  return userAgents[Math.floor(Math.random() * userAgents.length)];
}

/**
 * Scan a specific gambling site for promotions
 */
async function scanSite(site: SiteConfig): Promise<DetectedReward[]> {
  try {
    console.log(`[scanner] Scanning ${site.name} for promotions...`);
    
    // Make a request to the site
    const response = await fetch(site.url, {
      headers: {
        'User-Agent': getRandomUserAgent(),
        'Accept': 'text/html,application/xhtml+xml,application/xml',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': 'https://www.google.com/'
      },
      timeout: 10000 // 10 second timeout
    });
    
    // Check if request was successful
    if (!response.ok) {
      console.log(`[scanner] Error scanning ${site.name}: Status ${response.status}`);
      return [];
    }
    
    // Get the HTML content
    const html = await response.text();
    
    // Check if we hit a geo-restriction page
    if (html.includes('geo-restrictions') || 
        html.includes('location is not supported') || 
        html.includes('not available in your region')) {
      console.log(`[scanner] Geo-restriction detected for ${site.name}`);
      return [];
    }
    
    console.log(`[scanner] Successfully accessed ${site.name}`);
    
    // Parse the HTML
    const $ = cheerio.load(html);
    const rewards: DetectedReward[] = [];
    
    // Extract promotions using selectors
    site.promoSelectors.forEach(selector => {
      $(selector).each((_, element) => {
        try {
          // Extract title
          let title = '';
          const titleElement = $(element).find('h1, h2, h3, h4, [class*="title"], [class*="header"]');
          
          if (titleElement.length) {
            title = titleElement.first().text().trim();
          } else {
            title = $(element).text().trim().substring(0, 100);
          }
          
          // Extract description
          let description = '';
          const descElement = $(element).find('p, [class*="description"], [class*="content"]');
          
          if (descElement.length) {
            description = descElement.first().text().trim();
          }
          
          // Check if it's a new member offer
          const isNewMemberOffer = 
            title.toLowerCase().includes('new') && 
            (title.toLowerCase().includes('customer') || title.toLowerCase().includes('member')) ||
            description.toLowerCase().includes('new customer');
          
          // Create a reward if we have a meaningful title
          if (title && title.length > 5) {
            rewards.push({
              site: site.name,
              reward: title,
              description: description,
              category: isNewMemberOffer ? 'OTHER' : RewardCategory.FREE_BET,
              expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
              url: site.url,
              isNewMemberOffer
            });
          }
        } catch (err) {
          console.error(`[scanner] Error processing ${site.name} promo:`, err);
        }
      });
    });
    
    console.log(`[scanner] Found ${rewards.length} promotions on ${site.name}`);
    return rewards;
    
  } catch (error) {
    console.error(`[scanner] Error scanning ${site.name}:`, error.message || 'No response received - network issue');
    return [];
  }
}

/**
 * Scan all configured gambling sites for promotions
 * This should be called on a schedule
 */
export async function scanAllSites(): Promise<DetectedReward[]> {
  console.log('[scanner] Starting daily scan of gambling sites for promotions...');
  
  const allRewards: DetectedReward[] = [];
  
  // Scan each site
  for (const site of GAMBLING_SITES) {
    const rewards = await scanSite(site);
    allRewards.push(...rewards);
  }
  
  console.log(`[scanner] Completed daily scan of gambling sites. ${allRewards.length} new offers detected.`);
  return allRewards;
}

/**
 * Save detected promotions to database as offerings
 */
export async function savePromoOfferings(rewards: DetectedReward[]): Promise<void> {
  try {
    console.log(`[scanner] Saving ${rewards.length} promotions to database...`);
    
    for (const reward of rewards) {
      // Check if a similar offering already exists
      const existingOfferings = await storage.getOfferings({ 
        site: reward.site 
      });
      
      const similarOffering = existingOfferings.find(offering => 
        offering.title.toLowerCase().includes(reward.reward.toLowerCase()) ||
        reward.reward.toLowerCase().includes(offering.title.toLowerCase())
      );
      
      if (!similarOffering) {
        // Create a new offering
        await storage.createOffering({
          site: reward.site,
          title: reward.reward,
          description: reward.description || '',
          category: reward.category,
          expiresAt: reward.expiresAt,
          url: reward.url,
          isNewMemberOffer: reward.isNewMemberOffer,
          value: 'Unknown', // Required field for offerings
          updatedAt: new Date(),
          detectedAt: new Date()
        });
      }
    }
    
    console.log('[scanner] Promotions saved successfully');
  } catch (error) {
    console.error('[scanner] Error saving promotions:', error);
  }
}

/**
 * Initialize the scanner service and schedule periodic scans
 */
export function initScanner(): void {
  try {
    console.log('[scanner] Initializing daily reward scanning service...');
    
    // Schedule daily scan at midnight
    cron.schedule('0 0 * * *', async () => {
      try {
        const rewards = await scanAllSites();
        await savePromoOfferings(rewards);
      } catch (error) {
        console.error('[scanner] Error in scheduled scan:', error);
      }
    });
    
    console.log('[scanner] Daily reward scanning service initialized successfully');
    
    // Also run an initial scan
    setTimeout(async () => {
      try {
        const rewards = await scanAllSites();
        await savePromoOfferings(rewards);
      } catch (error) {
        console.error('[scanner] Error in initial scan:', error);
      }
    }, 5000); // Wait 5 seconds before starting initial scan
    
  } catch (error) {
    console.error('[scanner] Error initializing scanner:', error);
  }
}