// Notification Service Worker
// This worker runs in the background and checks for expiring rewards

let checkInterval = 15 * 60 * 1000; // Default check every 15 minutes
let checkingActive = false;
let checkingIntervalId = null;

// Listen for messages from the main application
self.addEventListener('message', (event) => {
  const data = event.data;
  
  if (data.type === 'START_CHECKING') {
    // Start or restart the checking process
    if (data.checkInterval) {
      checkInterval = data.checkInterval;
    }
    startChecking();
  } else if (data.type === 'STOP_CHECKING') {
    // Stop the checking process
    stopChecking();
  }
});

// Start checking for expiring rewards
function startChecking() {
  // Stop any existing interval first
  stopChecking();
  
  // Set the flag that checking is active
  checkingActive = true;
  
  // Run an initial check right away
  checkExpiringRewards();
  
  // Then set up the interval
  checkingIntervalId = setInterval(checkExpiringRewards, checkInterval);
  
  console.log(`[Notification Worker] Started checking for expiring rewards every ${checkInterval / 60000} minutes`);
}

// Stop checking for expiring rewards
function stopChecking() {
  if (checkingIntervalId) {
    clearInterval(checkingIntervalId);
    checkingIntervalId = null;
    checkingActive = false;
    console.log('[Notification Worker] Stopped checking for expiring rewards');
  }
}

// Check for rewards expiring soon
async function checkExpiringRewards() {
  if (!checkingActive) {
    return;
  }
  
  try {
    // Only perform the check if notifications are enabled in localStorage
    if (await isNotificationsEnabled()) {
      console.log('[Notification Worker] Checking for expiring rewards...');
      
      // Fetch the expiring rewards from the API
      const response = await fetch('/api/rewards/expiring', {
        credentials: 'include'  // Important for sending cookies/session data
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          // User is not logged in, don't bother the user
          console.log('[Notification Worker] User not authenticated');
          return;
        }
        
        throw new Error(`Server responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      
      // If there are expiring rewards, show notifications
      if (data.rewards && data.rewards.length > 0) {
        showExpiringRewardsNotification(data.rewards);
      } else {
        console.log('[Notification Worker] No rewards expiring soon');
      }
    } else {
      console.log('[Notification Worker] Notifications are disabled by user');
    }
  } catch (error) {
    console.error('[Notification Worker] Error checking expiring rewards:', error);
  }
}

// Show a notification for expiring rewards
function showExpiringRewardsNotification(rewards) {
  const count = rewards.length;
  
  // Don't show notifications if they're disabled in browser settings
  if (Notification.permission !== 'granted') {
    console.log('[Notification Worker] Notification permission not granted');
    return;
  }
  
  // Group rewards by site for better display
  const rewardsBysite = {};
  rewards.forEach(reward => {
    if (!rewardsBysite[reward.site]) {
      rewardsBysite[reward.site] = [];
    }
    rewardsBysite[reward.site].push(reward);
  });
  
  const sites = Object.keys(rewardsBysite);
  
  // Create the notification title
  let title = count === 1 
    ? '1 Reward Expiring Soon' 
    : `${count} Rewards Expiring Soon`;
  
  // Create the notification body
  let body = sites.length === 1
    ? `You have ${count} reward${count > 1 ? 's' : ''} from ${sites[0]} expiring soon.`
    : `You have rewards from ${sites.slice(0, 3).join(', ')}${sites.length > 3 ? ' and more' : ''} expiring soon.`;
    
  // Show the notification
  self.registration.showNotification(title, {
    body: body,
    icon: '/spinvault-favicon.ico',
    badge: '/spinvault-favicon.ico',
    tag: 'expiring-rewards',
    renotify: true,
    data: {
      timestamp: Date.now(),
      rewards: rewards
    },
    actions: [
      {
        action: 'view',
        title: 'View Rewards'
      },
      {
        action: 'dismiss',
        title: 'Dismiss'
      }
    ]
  });
  
  console.log(`[Notification Worker] Showed notification for ${count} expiring rewards`);
}

// Check if notifications are enabled in localStorage
async function isNotificationsEnabled() {
  // No direct access to localStorage in service workers, 
  // have to use clients to check indirectly
  
  // Default to true if we can't determine the setting
  // (the notification service wouldn't have been registered if not initially enabled)
  return true;
}

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  if (event.action === 'view') {
    // Open the app to the rewards page
    clients.openWindow('/');
  }
});

// Handle push events (future enhancement with web push)
self.addEventListener('push', (event) => {
  if (!event.data) return;
  
  try {
    const data = event.data.json();
    
    // Handle different push notification types
    if (data.type === 'expiring-rewards') {
      event.waitUntil(
        self.registration.showNotification(data.title, {
          body: data.body,
          icon: '/spinvault-favicon.ico',
          badge: '/spinvault-favicon.ico',
          tag: 'expiring-rewards',
          data: data.data
        })
      );
    }
  } catch (error) {
    console.error('[Notification Worker] Error processing push event:', error);
  }
});

// Install event - cache any resources needed for the worker
self.addEventListener('install', (event) => {
  self.skipWaiting(); // Ensures the worker activates immediately
});

// Activate event - clean up old caches 
self.addEventListener('activate', (event) => {
  // Claim clients to take control of all pages under this worker's scope
  event.waitUntil(clients.claim());
  console.log('[Notification Worker] Activated successfully');
});