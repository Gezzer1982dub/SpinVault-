// SpinVault Reward Detection Worker
// This background service worker automatically detects rewards from gambling sites

// Cache for storing detected rewards before syncing
let detectedRewards = [];
let isScanning = false;
let isActive = false;
let userLoggedIn = false;
let scanInterval = null;
const SCAN_INTERVAL_MS = 5000; // Scan every 5 seconds

// Initialize when the service worker activates
self.addEventListener('activate', event => {
  console.log('SpinVault Detection Worker activated');
  isActive = true;
});

// Listen for messages from the main app
self.addEventListener('message', event => {
  const data = event.data;
  
  if (data.action === 'initialize') {
    userLoggedIn = data.userLoggedIn;
    if (userLoggedIn && !scanInterval) {
      startAutoDetection();
    } else if (!userLoggedIn && scanInterval) {
      stopAutoDetection();
    }
  }
  
  if (data.action === 'startDetection') {
    startAutoDetection();
  }
  
  if (data.action === 'stopDetection') {
    stopAutoDetection();
  }
  
  // Handle user login/logout
  if (data.action === 'userLogin') {
    userLoggedIn = true;
    startAutoDetection();
  }
  
  if (data.action === 'userLogout') {
    userLoggedIn = false;
    stopAutoDetection();
  }
  
  // Respond to pings to ensure the worker is running
  if (data.action === 'ping') {
    event.ports[0].postMessage({ status: 'active', isScanning });
  }
});

// Start automatic detection process
function startAutoDetection() {
  if (scanInterval) return; // Already running
  
  console.log('Starting automatic reward detection');
  isScanning = true;
  
  // Scan immediately
  scanAllTabs();
  
  // Then set up interval
  scanInterval = setInterval(scanAllTabs, SCAN_INTERVAL_MS);
  
  // Notify the main app that detection has started
  self.clients.matchAll().then(clients => {
    clients.forEach(client => {
      client.postMessage({ 
        action: 'detectionStatus', 
        isScanning: true,
        message: 'Automatic detection started'
      });
    });
  });
}

// Stop automatic detection
function stopAutoDetection() {
  if (!scanInterval) return; // Not running
  
  console.log('Stopping automatic reward detection');
  clearInterval(scanInterval);
  scanInterval = null;
  isScanning = false;
  
  // Notify the main app that detection has stopped
  self.clients.matchAll().then(clients => {
    clients.forEach(client => {
      client.postMessage({ 
        action: 'detectionStatus', 
        isScanning: false,
        message: 'Automatic detection stopped'
      });
    });
  });
}

// Scan all open tabs for rewards
async function scanAllTabs() {
  if (!userLoggedIn) return;
  
  try {
    // The service worker can't directly access tabs, so we broadcast a message
    // asking any active SpinVault tabs to scan their connected gambling sites
    self.clients.matchAll().then(clients => {
      clients.forEach(client => {
        client.postMessage({ action: 'scanNow' });
      });
    });
    
    // Check if we have rewards waiting to be synced
    if (detectedRewards.length > 0) {
      await syncDetectedRewards();
    }
  } catch (error) {
    console.error('Error scanning tabs:', error);
  }
}

// Send detected rewards to the API
async function syncDetectedRewards() {
  if (detectedRewards.length === 0) return;
  
  try {
    const rewardsToSync = [...detectedRewards];
    detectedRewards = []; // Clear the cache to avoid duplicates
    
    const response = await fetch('/api/sync-rewards', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ rewards: rewardsToSync }),
      credentials: 'include'
    });
    
    const result = await response.json();
    
    if (result.success) {
      // Notify the main app about new rewards
      self.clients.matchAll().then(clients => {
        clients.forEach(client => {
          client.postMessage({ 
            action: 'rewardsDetected', 
            count: result.savedCount,
            rewards: result.rewards
          });
        });
      });
    } else {
      // If sync failed, put the rewards back in the queue
      detectedRewards = [...detectedRewards, ...rewardsToSync];
    }
  } catch (error) {
    console.error('Error syncing rewards:', error);
    // If sync failed, put the rewards back in the queue
    detectedRewards = [...detectedRewards, ...rewardsToSync];
  }
}

// Add a new reward to the queue
function addDetectedReward(reward) {
  // Check for duplicates
  const isDuplicate = detectedRewards.some(r => 
    r.site === reward.site && r.reward === reward.reward
  );
  
  if (!isDuplicate) {
    detectedRewards.push(reward);
    
    // Notify the main app about the new reward
    self.clients.matchAll().then(clients => {
      clients.forEach(client => {
        client.postMessage({ 
          action: 'rewardDetected', 
          reward
        });
      });
    });
  }
}

// Console log the worker is ready
console.log('SpinVault Detection Worker loaded and ready');