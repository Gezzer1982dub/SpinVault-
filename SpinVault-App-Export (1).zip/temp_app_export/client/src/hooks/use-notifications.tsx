import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";

// Types for notifications
interface Notification {
  id: number;
  userId: number;
  type: string;
  channel: string;
  title: string;
  message: string;
  status: string;
  metadata: Record<string, any>;
  relatedId?: number;
  scheduledFor?: string;
  sentAt?: string;
  readAt?: string;
  createdAt: string;
}

interface NotificationSettings {
  notificationsEnabled: boolean;
  emailNotificationsEnabled: boolean;
  pushNotificationsEnabled: boolean;
  expiringRewardsNotificationsEnabled: boolean;
  emailAddress?: string;
}

interface NotificationsContextType {
  notifications: Notification[];
  unreadCount: number;
  isLoading: boolean;
  error: Error | null;
  settings: NotificationSettings | null;
  settingsLoading: boolean;
  markAsRead: (id: number) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: number) => void;
  updateSettings: (settings: Partial<NotificationSettings>) => void;
  setupEmailNotifications: (email: string) => void;
}

const defaultNotificationSettings: NotificationSettings = {
  notificationsEnabled: true,
  emailNotificationsEnabled: false,
  pushNotificationsEnabled: false,
  expiringRewardsNotificationsEnabled: true,
};

const NotificationsContext = createContext<NotificationsContextType | null>(null);

export function NotificationsProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [unreadCount, setUnreadCount] = useState(0);

  // Fetch notifications
  const {
    data: notifications = [],
    error,
    isLoading,
  } = useQuery({
    queryKey: ["/api/notifications"],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest("GET", "/api/notifications");
      const data = await res.json();
      return data.notifications || [];
    },
    enabled: !!user,
  });

  // Fetch notification settings
  const {
    data: settingsData,
    isLoading: settingsLoading,
  } = useQuery({
    queryKey: ["/api/notification-settings"],
    queryFn: async () => {
      if (!user) return null;
      const res = await apiRequest("GET", "/api/notification-settings");
      const data = await res.json();
      return data.settings || defaultNotificationSettings;
    },
    enabled: !!user,
  });

  // Get unread count
  const { data: unreadCountData } = useQuery({
    queryKey: ["/api/notifications/unread-count"],
    queryFn: async () => {
      if (!user) return { count: 0 };
      const res = await apiRequest("GET", "/api/notifications/unread-count");
      const data = await res.json();
      return data;
    },
    enabled: !!user,
    refetchInterval: 60000, // Refetch every minute
  });

  // Update unread count when data changes
  useEffect(() => {
    if (unreadCountData?.count !== undefined) {
      setUnreadCount(unreadCountData.count);
    }
  }, [unreadCountData]);

  // Mark notification as read
  const markAsReadMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PATCH", `/api/notifications/${id}/read`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to mark notification as read",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mark all notifications as read
  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/notifications/mark-all-read");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      setUnreadCount(0);
      
      toast({
        title: "Notifications cleared",
        description: "All notifications have been marked as read",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to mark all notifications as read",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete notification
  const deleteNotificationMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/notifications/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      
      toast({
        title: "Notification deleted",
        description: "The notification has been removed",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete notification",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update notification settings
  const updateSettingsMutation = useMutation({
    mutationFn: async (settings: Partial<NotificationSettings>) => {
      const res = await apiRequest("PATCH", "/api/notification-settings", settings);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/notification-settings"] });
      
      toast({
        title: "Settings updated",
        description: "Your notification preferences have been saved",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update settings",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Setup email notifications
  const setupEmailMutation = useMutation({
    mutationFn: async (email: string) => {
      const res = await apiRequest("POST", "/api/notifications/setup-email", { email });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notification-settings"] });
      
      toast({
        title: "Email notifications enabled",
        description: "You'll now receive email notifications for important updates",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to setup email notifications",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <NotificationsContext.Provider
      value={{
        notifications,
        unreadCount,
        isLoading,
        error,
        settings: settingsData || null,
        settingsLoading,
        markAsRead: (id) => markAsReadMutation.mutate(id),
        markAllAsRead: () => markAllAsReadMutation.mutate(),
        deleteNotification: (id) => deleteNotificationMutation.mutate(id),
        updateSettings: (settings) => updateSettingsMutation.mutate(settings),
        setupEmailNotifications: (email) => setupEmailMutation.mutate(email),
      }}
    >
      {children}
    </NotificationsContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationsContext);
  if (!context) {
    throw new Error("useNotifications must be used within a NotificationsProvider");
  }
  return context;
}