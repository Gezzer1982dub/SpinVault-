import { Bell, ExternalLink, Mail } from "lucide-react";
import { useNotifications } from "@/hooks/use-notifications";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useState } from "react";
import { useLocation } from "wouter";

// Individual notification item
const NotificationItem = ({ notification, onRead }: { 
  notification: any;
  onRead: (id: number) => void; 
}) => {
  const [, setLocation] = useLocation();
  const date = new Date(notification.createdAt);
  const isNew = notification.status === "SENT";
  
  // Handle click on notification
  const handleClick = () => {
    onRead(notification.id);
    
    // Navigate based on notification type
    if (notification.type === "REWARD_EXPIRING") {
      setLocation("/rewards");
    } else if (notification.type === "PROMOTION_ADDED") {
      setLocation("/promotions");
    } else if (notification.type === "ACCOUNT_UPDATE") {
      setLocation("/settings");
    }
  };
  
  // Handle checking email
  const handleEmailCheck = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent dropdown from closing
    
    // Get user's email provider from metadata if available
    const metadata = typeof notification.metadata === 'string'
      ? JSON.parse(notification.metadata)
      : (notification.metadata || {});
    
    const userEmail = metadata.recipientEmail || '';
    
    // Determine which email provider to open based on the user's email
    if (userEmail.endsWith('@gmail.com')) {
      window.open("https://mail.google.com", "_blank");
    } else if (userEmail.endsWith('@yahoo.com')) {
      window.open("https://mail.yahoo.com", "_blank");
    } else if (userEmail.endsWith('@outlook.com') || userEmail.endsWith('@hotmail.com')) {
      window.open("https://outlook.live.com/mail/inbox", "_blank");
    } else {
      // Default to webmail list if we can't determine the provider
      window.open("https://webmail.mozmail.com/", "_blank");
    }
  };

  return (
    <DropdownMenuItem
      className={cn(
        "flex flex-col items-start p-3 cursor-pointer",
        isNew && "bg-muted/80"
      )}
      onClick={handleClick}
    >
      <div className="flex items-start justify-between w-full">
        <p className="font-medium text-sm">{notification.title}</p>
        <div className="flex items-center">
          {notification.channel === "EMAIL" && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs px-2 py-0.5 ml-1 flex items-center gap-1 text-primary hover:bg-primary/10" 
              onClick={handleEmailCheck}
              title="Open your email provider"
            >
              <Mail className="h-3 w-3" />
              <span>Check Email</span>
            </Button>
          )}
          {isNew && (
            <Badge variant="default" className="ml-1 h-1.5 w-1.5 rounded-full p-0" />
          )}
        </div>
      </div>
      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{notification.message}</p>
      <p className="text-xs text-muted-foreground mt-1.5">
        {format(date, "MMM d, h:mm a")}
      </p>
    </DropdownMenuItem>
  );
};

export function NotificationBell() {
  const { 
    notifications, 
    unreadCount, 
    markAsRead, 
    markAllAsRead,
    isLoading 
  } = useNotifications();
  const [open, setOpen] = useState(false);

  const hasNotifications = notifications.length > 0;
  const sortedNotifications = [...notifications].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  ).slice(0, 5); // Only show the 5 most recent

  const handleMarkAsRead = (id: number) => {
    markAsRead(id);
    // Don't close the dropdown
  };

  const handleClearAll = () => {
    markAllAsRead();
    setOpen(false);
  };

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative p-2 h-9 w-9">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge
              variant="destructive"
              className="absolute top-0 right-0 -mt-1 -mr-1 flex h-4 w-4 items-center justify-center rounded-full p-0 text-[0.625rem]"
            >
              {unreadCount > 9 ? "9+" : unreadCount}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80" align="end">
        <div className="flex items-center justify-between p-3">
          <h3 className="font-medium">Notifications</h3>
          {hasNotifications && (
            <Button variant="ghost" className="text-xs h-8" onClick={handleClearAll}>
              Clear all
            </Button>
          )}
        </div>
        <DropdownMenuSeparator />
        <div className="max-h-[300px] overflow-y-auto">
          {isLoading ? (
            <div className="flex justify-center p-4">
              <div className="animate-spin w-5 h-5 border-2 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : hasNotifications ? (
            sortedNotifications.map((notification) => (
              <NotificationItem
                key={notification.id}
                notification={notification}
                onRead={handleMarkAsRead}
              />
            ))
          ) : (
            <div className="p-4 text-center text-muted-foreground text-sm">
              No notifications yet
            </div>
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}