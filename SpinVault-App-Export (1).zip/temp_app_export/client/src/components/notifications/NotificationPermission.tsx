import { useState, useEffect } from 'react';
import { Bell, BellOff, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { useNotifications } from '@/hooks/use-notifications';

export function NotificationPermission() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();
  const { 
    permissionState, 
    requestPermission, 
    isSupported,
    notificationsEnabled,
    toggleNotifications
  } = useNotifications();

  // Show dialog when permissions are denied or haven't been requested yet
  const showPermissionDialog = permissionState === 'denied' || (!notificationsEnabled && permissionState === 'default');

  const handleButtonClick = async () => {
    if (!isSupported) {
      toast({
        title: "Not Supported",
        description: "Notifications are not supported in your browser.",
        variant: "destructive",
      });
      return;
    }

    if (permissionState === 'granted') {
      // Toggle notifications on/off if permission is already granted
      toggleNotifications();
      toast({
        title: notificationsEnabled ? "Notifications Disabled" : "Notifications Enabled",
        description: notificationsEnabled 
          ? "You will no longer receive notifications about expiring rewards." 
          : "You will now receive notifications about expiring rewards.",
      });
    } else {
      // Open dialog to request permission
      setDialogOpen(true);
    }
  };

  const handleRequestPermission = async () => {
    try {
      const result = await requestPermission();
      if (result === 'granted') {
        toast({
          title: "Notifications Enabled",
          description: "You'll be notified about expiring rewards!",
        });
        toggleNotifications(true); // Ensure notifications are enabled
      } else {
        toast({
          title: "Permission Denied",
          description: "Please enable notifications in your browser settings to receive alerts.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error requesting notification permission:", error);
      toast({
        title: "Error",
        description: "Unable to request notification permission.",
        variant: "destructive",
      });
    } finally {
      setDialogOpen(false);
    }
  };

  return (
    <>
      <Button
        variant="outline"
        size="icon"
        onClick={handleButtonClick}
        className="h-9 w-9"
        aria-label={notificationsEnabled ? "Disable notifications" : "Enable notifications"}
      >
        {notificationsEnabled ? (
          <Bell className="h-4 w-4" />
        ) : (
          <BellOff className="h-4 w-4" />
        )}
      </Button>

      <AlertDialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center">
              <AlertCircle className="mr-2 h-5 w-5 text-amber-500" />
              Enable Notifications
            </AlertDialogTitle>
            <AlertDialogDescription>
              Receive alerts when your rewards are about to expire. 
              This helps you never miss out on valuable offers and free spins!
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Not Now</AlertDialogCancel>
            <AlertDialogAction onClick={handleRequestPermission}>
              Enable Notifications
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}