import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export interface ProgressTrackerProps {
  value: number;
  max: number;
  label?: string;
  showValue?: boolean;
  size?: 'sm' | 'md' | 'lg';
  color?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger';
  className?: string;
  animate?: boolean;
  showPercentage?: boolean;
  interactive?: boolean;
  onChange?: (newValue: number) => void;
}

const colorVariants = {
  primary: 'bg-gradient-to-r from-indigo-500 to-indigo-600',
  secondary: 'bg-gradient-to-r from-purple-500 to-purple-600',
  success: 'bg-gradient-to-r from-emerald-500 to-emerald-600',
  warning: 'bg-gradient-to-r from-amber-500 to-amber-600',
  danger: 'bg-gradient-to-r from-rose-500 to-rose-600',
};

const sizeVariants = {
  sm: 'h-2 text-xs',
  md: 'h-3 text-sm',
  lg: 'h-4 text-base',
};

export function ProgressTracker({
  value,
  max,
  label,
  showValue = false,
  size = 'md',
  color = 'primary',
  className,
  animate = true,
  showPercentage = false,
  interactive = false,
  onChange,
}: ProgressTrackerProps) {
  const [animatedValue, setAnimatedValue] = useState(0);
  const percentage = Math.min(100, Math.round((value / max) * 100));
  
  // Handle interactive clicks
  const handleTrackClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!interactive || !onChange) return;
    
    const track = e.currentTarget;
    const rect = track.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const trackWidth = rect.width;
    const newPercentage = (clickX / trackWidth) * 100;
    const newValue = Math.min(max, Math.max(0, Math.round((newPercentage / 100) * max)));
    
    onChange(newValue);
  };
  
  // Animation effect
  useEffect(() => {
    if (!animate) {
      setAnimatedValue(value);
      return;
    }
    
    // Animate from current value to new value
    const startValue = animatedValue;
    const endValue = value;
    const duration = 500; // ms
    const startTime = performance.now();
    
    const animateProgress = (timestamp: number) => {
      const elapsed = timestamp - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easedProgress = easeOutQuad(progress);
      
      const currentValue = startValue + (endValue - startValue) * easedProgress;
      setAnimatedValue(currentValue);
      
      if (progress < 1) {
        requestAnimationFrame(animateProgress);
      }
    };
    
    requestAnimationFrame(animateProgress);
  }, [value, animate]);
  
  // Easing function for smoother animation
  const easeOutQuad = (x: number): number => {
    return 1 - (1 - x) * (1 - x);
  };
  
  return (
    <div className={cn('w-full space-y-1.5', className)}>
      {(label || showValue) && (
        <div className="flex items-center justify-between">
          {label && <p className="text-sm font-medium text-foreground">{label}</p>}
          {showValue && (
            <p className="text-sm text-muted-foreground">
              {showPercentage ? `${percentage}%` : `${value}/${max}`}
            </p>
          )}
        </div>
      )}
      
      <div 
        className={cn(
          'w-full bg-secondary/20 rounded-full overflow-hidden cursor-default',
          interactive && 'cursor-pointer',
          sizeVariants[size]
        )}
        onClick={handleTrackClick}
      >
        <motion.div
          className={cn(
            'h-full rounded-full transition-all',
            colorVariants[color]
          )}
          initial={{ width: 0 }}
          animate={{ width: `${animate ? (animatedValue / max) * 100 : percentage}%` }}
          transition={{ duration: animate ? 0.5 : 0 }}
        />
      </div>
    </div>
  );
}

// A specialized version for showing wagering requirement progress
export function WageringProgress({
  currentWager,
  requiredWager,
  className
}: {
  currentWager: number;
  requiredWager: number;
  className?: string;
}) {
  const percentage = Math.min(100, Math.round((currentWager / requiredWager) * 100));
  const isComplete = currentWager >= requiredWager;
  
  return (
    <div className={cn('w-full space-y-2', className)}>
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium">Wagering Progress</span>
        <span className="text-sm font-medium">
          {isComplete ? (
            <span className="text-emerald-500">Complete!</span>
          ) : (
            `£${currentWager} / £${requiredWager}`
          )}
        </span>
      </div>
      
      <ProgressTracker
        value={currentWager}
        max={requiredWager}
        color={isComplete ? 'success' : 'primary'}
        size="md"
        animate={true}
      />
      
      <div className="text-xs text-muted-foreground">
        {isComplete 
          ? "Congratulations! You've met the wagering requirement."
          : `${percentage}% complete. Wager £${requiredWager - currentWager} more to unlock.`}
      </div>
    </div>
  );
}

// A specialized version for showing bonus spins progress
export function SpinsProgress({
  usedSpins,
  totalSpins,
  className
}: {
  usedSpins: number;
  totalSpins: number;
  className?: string;
}) {
  const spinsLeft = totalSpins - usedSpins;
  const percentage = Math.min(100, Math.round((usedSpins / totalSpins) * 100));
  
  return (
    <div className={cn('w-full space-y-2', className)}>
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium">Free Spins Progress</span>
        <span className="text-sm font-medium">
          {spinsLeft} spins remaining
        </span>
      </div>
      
      <ProgressTracker
        value={usedSpins}
        max={totalSpins}
        color={spinsLeft === 0 ? 'secondary' : 'warning'}
        size="md"
        animate={true}
      />
      
      <div className="text-xs text-muted-foreground">
        {spinsLeft === 0 
          ? "All spins used. Check your balance for winnings!"
          : `${percentage}% used. ${spinsLeft} spins remaining.`}
      </div>
    </div>
  );
}

// A time-based expiry progress bar
export function ExpiryProgress({
  expiresAt,
  createdAt,
  className
}: {
  expiresAt: Date;
  createdAt: Date;
  className?: string;
}) {
  const now = new Date();
  const totalDuration = expiresAt.getTime() - createdAt.getTime();
  const timeElapsed = now.getTime() - createdAt.getTime();
  const timeRemaining = expiresAt.getTime() - now.getTime();
  
  // Calculate percentage of time elapsed
  const percentageElapsed = Math.min(100, Math.max(0, Math.round((timeElapsed / totalDuration) * 100)));
  
  // Calculate remaining time in days and hours
  const daysRemaining = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
  const hoursRemaining = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  
  // Determine color based on time remaining
  let color: 'primary' | 'warning' | 'danger' = 'primary';
  if (daysRemaining <= 1) color = 'danger';
  else if (daysRemaining <= 3) color = 'warning';
  
  return (
    <div className={cn('w-full space-y-2', className)}>
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium">Time Remaining</span>
        <span className="text-sm font-medium">
          {daysRemaining > 0 
            ? `${daysRemaining}d ${hoursRemaining}h` 
            : `${hoursRemaining}h`}
        </span>
      </div>
      
      <ProgressTracker
        value={percentageElapsed}
        max={100}
        color={color}
        size="md"
        animate={false}
      />
      
      <div className="text-xs text-muted-foreground">
        {daysRemaining <= 0 && hoursRemaining <= 5
          ? "Expiring soon! Take action now."
          : `Expires in ${daysRemaining} days and ${hoursRemaining} hours.`}
      </div>
    </div>
  );
}