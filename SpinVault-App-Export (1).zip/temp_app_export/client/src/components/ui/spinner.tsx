import { cn } from "@/lib/utils";

interface SpinnerProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function Spinner({ className, size = "md" }: SpinnerProps) {
  const sizeClasses = {
    sm: "h-6 w-6 border-2",
    md: "h-10 w-10 border-3",
    lg: "h-16 w-16 border-4",
  };

  return (
    <div className="flex justify-center items-center">
      <div
        className={cn(
          "rounded-full border-t-transparent border-primary animate-spin",
          sizeClasses[size],
          className
        )}
      />
    </div>
  );
}
