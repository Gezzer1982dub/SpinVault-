import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { CustomCategory } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";

interface CategoryFormProps {
  onSuccess: () => void;
  editCategory: CustomCategory | null;
}

// Create a simplified schema without userId for the form
const categoryFormSchema = z.object({
  name: z.string().min(1, "Name is required").max(50, "Name must be less than 50 characters"),
  description: z.string().max(200, "Description must be less than 200 characters").optional(),
  color: z.string().regex(/^#[0-9A-Fa-f]{6}$/, {
    message: "Color must be a valid hex color code (e.g., #FF5733)",
  }),
});

type CategoryFormData = z.infer<typeof categoryFormSchema>;

export function CategoryForm({ onSuccess, editCategory }: CategoryFormProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [colorPickerValue, setColorPickerValue] = useState(editCategory?.color || "#6366f1");

  const defaultValues: Partial<CategoryFormData> = {
    name: editCategory?.name || "",
    description: editCategory?.description || "",
    color: editCategory?.color || "#6366f1",
  };

  const form = useForm<CategoryFormData>({
    resolver: zodResolver(categoryFormSchema),
    defaultValues,
  });

  // Create category mutation
  const createCategoryMutation = useMutation({
    mutationFn: async (formData: CategoryFormData) => {
      // Add userId to the data being sent to the server
      const dataWithUserId = {
        ...formData,
        userId: user?.id
      };
      
      const res = await apiRequest("POST", "/api/custom-categories", dataWithUserId);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/custom-categories"] });
      toast({
        title: "Category created",
        description: "Your custom category has been created successfully.",
        variant: "default",
      });
      onSuccess();
      form.reset();
    },
    onError: (error) => {
      console.error("Error creating category:", error);
      toast({
        title: "Error",
        description: (error as Error).message || "Failed to create category",
        variant: "destructive",
      });
    },
  });

  // Update category mutation
  const updateCategoryMutation = useMutation({
    mutationFn: async (data: { id: number; formData: CategoryFormData }) => {
      const res = await apiRequest(
        "PUT", 
        `/api/custom-categories/${data.id}`, 
        data.formData
      );
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/custom-categories"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rewards"] });
      toast({
        title: "Category updated",
        description: "Your custom category has been updated successfully.",
        variant: "default",
      });
      onSuccess();
      form.reset();
    },
    onError: (error) => {
      console.error("Error updating category:", error);
      toast({
        title: "Error",
        description: (error as Error).message || "Failed to update category",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (formData: CategoryFormData) => {
    if (editCategory) {
      updateCategoryMutation.mutate({
        id: editCategory.id,
        formData,
      });
    } else {
      createCategoryMutation.mutate(formData);
    }
  };

  const isPending = createCategoryMutation.isPending || updateCategoryMutation.isPending;

  // Handle color input change
  const handleColorChange = (value: string) => {
    setColorPickerValue(value);
    form.setValue("color", value, { shouldValidate: true });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-2">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter category name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description (optional)</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Enter category description" 
                  className="resize-none" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="color"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Color</FormLabel>
              <div className="flex items-center gap-3">
                <FormControl>
                  <Input 
                    type="color" 
                    value={colorPickerValue}
                    onChange={(e) => handleColorChange(e.target.value)}
                    className="w-12 h-10 p-1 cursor-pointer"
                  />
                </FormControl>
                <Input 
                  type="text"
                  value={field.value}
                  onChange={(e) => {
                    field.onChange(e.target.value);
                    setColorPickerValue(e.target.value);
                  }}
                  placeholder="#RRGGBB"
                  className="font-mono"
                />
              </div>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="pt-3 flex justify-end space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              form.reset();
              onSuccess();
            }}
            disabled={isPending}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={isPending}>
            {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {editCategory ? "Update" : "Create"} Category
          </Button>
        </div>
      </form>
    </Form>
  );
}