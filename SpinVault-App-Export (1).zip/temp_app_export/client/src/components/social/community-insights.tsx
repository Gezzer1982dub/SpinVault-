import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  BarChart3, 
  Users, 
  TrendingUp, 
  Filter, 
  ChevronDown,
  RefreshCw
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

import ShareCard from "./share-card";

// Types for community insight cards
type InsightCard = {
  id: string;
  title: string;
  description: string;
  type: "insight" | "leaderboard" | "trending";
  stats: Record<string, string | number>;
  imageUrl?: string;
  createdAt: string;
};

// Dummy data for community insights
const dummyInsights: InsightCard[] = [
  {
    id: "1",
    title: "Most Popular Reward Sites",
    description: "Sites with the highest number of rewards detected this month",
    type: "insight",
    stats: {
      "Top Site": "Paddy Power",
      "Reward Count": 143,
      "Avg. Claim Rate": "78%",
      "Best Day": "Monday"
    },
    createdAt: new Date().toISOString()
  },
  {
    id: "2",
    title: "Trending Reward Categories",
    description: "Reward types gaining popularity in the last week",
    type: "trending",
    stats: {
      "Top Category": "Free Spins",
      "Growth": "+32%",
      "Avg. Value": "£15.40",
      "Typical Expiry": "48 hours"
    },
    createdAt: new Date().toISOString()
  },
  {
    id: "3",
    title: "Community Leaderboard",
    description: "Top reward hunters in the SpinVault community",
    type: "leaderboard",
    stats: {
      "Top Hunter": "User42",
      "Rewards Found": 87,
      "Value Score": 623,
      "Success Rate": "91%"
    },
    createdAt: new Date().toISOString()
  },
  {
    id: "4",
    title: "Expiry Insights",
    description: "How quickly rewards expire across different sites",
    type: "insight",
    stats: {
      "Avg. Validity": "7.2 days",
      "Quickest Expiry": "Bet365 (24h)",
      "Longest Offers": "William Hill",
      "Weekend Boost": "+31%"
    },
    createdAt: new Date().toISOString()
  }
];

export default function CommunityInsights() {
  const [activeTab, setActiveTab] = useState("all");
  const [insights, setInsights] = useState<InsightCard[]>(dummyInsights);
  const [sortBy, setSortBy] = useState<"newest" | "popular">("newest");
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Filter insights based on active tab
  const filteredInsights = insights.filter(insight => {
    if (activeTab === "all") return true;
    return insight.type === activeTab;
  });
  
  // Function to refresh insights
  const refreshInsights = () => {
    setIsRefreshing(true);
    
    // Simulate a refresh delay
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1000);
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Community Insights
            </CardTitle>
            <CardDescription>
              Discover and share anonymized reward insights from the SpinVault community
            </CardDescription>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={refreshInsights}
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full max-w-md">
            <TabsList className="grid grid-cols-3">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="insight">
                <BarChart3 className="h-4 w-4 mr-2" />
                Insights
              </TabsTrigger>
              <TabsTrigger value="trending">
                <TrendingUp className="h-4 w-4 mr-2" />
                Trending
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="ml-2 gap-1">
                <Filter className="h-4 w-4" />
                <span className="hidden sm:inline">Sort By</span>
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setSortBy("newest")}>
                Newest First
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy("popular")}>
                Most Popular
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {filteredInsights.map((insight) => (
            <ShareCard
              key={insight.id}
              title={insight.title}
              description={insight.description}
              imageUrl={insight.imageUrl}
              stats={insight.stats}
              type={insight.type}
            />
          ))}
        </div>
        
        {filteredInsights.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No insights available for this filter.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}