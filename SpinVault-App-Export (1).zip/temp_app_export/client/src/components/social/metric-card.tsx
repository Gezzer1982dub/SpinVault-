import { 
  Card, 
  CardContent, 
  CardDescription,
  CardFooter,
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { cva, type VariantProps } from "class-variance-authority";
import { TrendingUp, TrendingDown, Minus, AlertCircle, HelpCircle } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const metricVariants = cva("", {
  variants: {
    variant: {
      default: "",
      success: "text-green-500",
      warning: "text-amber-500",
      danger: "text-red-500",
      info: "text-blue-500",
    },
    size: {
      default: "text-3xl font-bold",
      sm: "text-xl font-semibold",
      lg: "text-4xl font-extrabold",
    },
  },
  defaultVariants: {
    variant: "default",
    size: "default",
  },
});

export interface MetricCardProps extends VariantProps<typeof metricVariants> {
  title: string;
  value: string | number;
  description?: string;
  trend?: number;
  icon?: React.ReactNode;
  className?: string;
  tooltipText?: string;
  footer?: React.ReactNode;
}

export function MetricCard({
  title,
  value,
  description,
  trend,
  icon,
  variant,
  size,
  className,
  tooltipText,
  footer,
}: MetricCardProps) {
  // Function to render trend indicator
  const renderTrend = () => {
    if (trend === undefined) return null;
    
    const trendAbs = Math.abs(trend);
    const formattedTrend = trendAbs.toFixed(1);
    
    if (trend > 5) {
      return (
        <div className="flex items-center gap-1 text-green-500 text-sm font-medium">
          <TrendingUp className="h-4 w-4" />
          <span>+{formattedTrend}%</span>
        </div>
      );
    } else if (trend < -5) {
      return (
        <div className="flex items-center gap-1 text-red-500 text-sm font-medium">
          <TrendingDown className="h-4 w-4" />
          <span>-{formattedTrend}%</span>
        </div>
      );
    } else {
      return (
        <div className="flex items-center gap-1 text-gray-400 text-sm font-medium">
          <Minus className="h-4 w-4" />
          <span>No change</span>
        </div>
      );
    }
  };
  
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex flex-col space-y-1">
          <CardTitle className="text-sm font-medium">
            {title}
            {tooltipText && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <HelpCircle className="h-3 w-3 ml-1 inline text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="w-[200px] text-xs">{tooltipText}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </CardTitle>
          {description && (
            <CardDescription className="text-xs">
              {description}
            </CardDescription>
          )}
        </div>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold">
          <span className={cn(metricVariants({ variant, size }))}>
            {value}
          </span>
        </div>
        {trend !== undefined && (
          <div className="mt-2">
            {renderTrend()}
          </div>
        )}
      </CardContent>
      {footer && (
        <CardFooter className="pt-0 pb-3 px-6">
          {footer}
        </CardFooter>
      )}
    </Card>
  );
}