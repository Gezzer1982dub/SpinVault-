import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Share2, 
  Twitter, 
  Facebook, 
  Copy, 
  Check, 
  Smartphone,
  Award,
  TrendingUp
} from "lucide-react";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type ShareCardProps = {
  title: string;
  description: string;
  imageUrl?: string;
  stats: {
    [key: string]: string | number;
  };
  type: "insight" | "leaderboard" | "trending";
  className?: string;
};

export default function ShareCard({
  title,
  description,
  imageUrl,
  stats,
  type,
  className
}: ShareCardProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  
  const getTypeIcon = () => {
    switch (type) {
      case "insight":
        return <Award className="h-5 w-5 text-amber-500" />;
      case "trending":
        return <TrendingUp className="h-5 w-5 text-green-500" />;
      case "leaderboard":
        return <Award className="h-5 w-5 text-amber-500" />;
      default:
        return <Award className="h-5 w-5 text-amber-500" />;
    }
  };
  
  const getShareableText = () => {
    let statsText = Object.entries(stats)
      .map(([key, value]) => `${key}: ${value}`)
      .join(", ");
    
    return `${title} - ${description} - ${statsText} | Check out SpinVault for more gambling reward insights!`;
  };
  
  const getShareUrl = () => {
    return window.location.href;
  };
  
  const handleShareTwitter = () => {
    const text = encodeURIComponent(getShareableText());
    const url = encodeURIComponent(getShareUrl());
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, "_blank");
  };
  
  const handleShareFacebook = () => {
    const url = encodeURIComponent(getShareUrl());
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, "_blank");
  };
  
  const handleCopyLink = () => {
    const textToCopy = `${getShareableText()} ${getShareUrl()}`;
    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      toast({
        title: "Link copied to clipboard",
        description: "You can now share it with others!",
      });
      setTimeout(() => setCopied(false), 2000);
    });
  };
  
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getTypeIcon()}
            <CardTitle>{title}</CardTitle>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon">
                <Share2 className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Share this insight</DialogTitle>
                <DialogDescription>
                  Share this anonymized reward insight with friends or on social media
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-3 gap-4 py-4">
                <Button 
                  variant="outline" 
                  className="flex flex-col items-center justify-center gap-2 h-auto py-4"
                  onClick={handleShareTwitter}
                >
                  <Twitter className="h-6 w-6 text-blue-400" />
                  <span className="text-xs">Twitter</span>
                </Button>
                <Button 
                  variant="outline" 
                  className="flex flex-col items-center justify-center gap-2 h-auto py-4"
                  onClick={handleShareFacebook}
                >
                  <Facebook className="h-6 w-6 text-blue-600" />
                  <span className="text-xs">Facebook</span>
                </Button>
                <Button 
                  variant="outline" 
                  className="flex flex-col items-center justify-center gap-2 h-auto py-4"
                  onClick={handleCopyLink}
                >
                  {copied ? (
                    <Check className="h-6 w-6 text-green-500" />
                  ) : (
                    <Copy className="h-6 w-6" />
                  )}
                  <span className="text-xs">Copy Link</span>
                </Button>
              </div>
              
              <div className="bg-muted rounded-md p-3 text-sm">
                <p className="text-muted-foreground">{getShareableText()}</p>
              </div>
              
              <Button variant="outline" className="w-full mt-4" onClick={handleCopyLink}>
                {copied ? "Copied!" : "Copy to clipboard"}
              </Button>
            </DialogContent>
          </Dialog>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {imageUrl && (
          <div className="aspect-video overflow-hidden rounded-md mb-4">
            <img 
              src={imageUrl} 
              alt={title} 
              className="object-cover w-full h-full"
            />
          </div>
        )}
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(stats).map(([key, value]) => (
            <div key={key} className="bg-muted rounded p-2">
              <div className="text-xs text-muted-foreground">{key}</div>
              <div className="font-semibold">{value}</div>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter className="border-t pt-3 flex justify-between">
        <div className="text-xs text-muted-foreground">
          Data is anonymized & updated hourly
        </div>
        <Button variant="ghost" size="sm" className="gap-1">
          <Smartphone className="h-3 w-3" />
          <span className="text-xs">Get the App</span>
        </Button>
      </CardFooter>
    </Card>
  );
}