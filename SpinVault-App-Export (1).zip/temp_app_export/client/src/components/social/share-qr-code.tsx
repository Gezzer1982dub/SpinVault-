import { useState, useEffect } from "react";
import QRCode from "qrcode";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Share2, Download, QrCode } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ShareQRCodeProps {
  url: string;
  title: string;
  description?: string;
  children?: React.ReactNode;
  variant?: "default" | "outline" | "ghost";
  size?: "default" | "sm" | "lg" | "icon";
}

export function ShareQRCode({ 
  url, 
  title, 
  description, 
  children, 
  variant = "outline",
  size = "default"
}: ShareQRCodeProps) {
  const [qrCode, setQrCode] = useState<string>("");
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && !qrCode) {
      generateQRCode();
    }
  }, [isOpen, qrCode]);

  const generateQRCode = async () => {
    try {
      const fullUrl = url.startsWith("http") ? url : window.location.origin + url;
      const qrDataUrl = await QRCode.toDataURL(fullUrl, {
        width: 300,
        margin: 2,
        color: {
          dark: "#000000",
          light: "#ffffff"
        }
      });
      setQrCode(qrDataUrl);
    } catch (error) {
      console.error("Error generating QR code:", error);
      toast({
        title: "Error generating QR code",
        variant: "destructive",
      });
    }
  };

  const downloadQRCode = () => {
    if (!qrCode) return;
    
    const link = document.createElement("a");
    link.href = qrCode;
    link.download = `spinvault-${title.toLowerCase().replace(/\s+/g, "-")}-qr.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "QR code downloaded",
      description: "You can now share it with others!",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children || (
          <Button variant={variant} size={size}>
            {size === "icon" ? (
              <QrCode className="h-4 w-4" />
            ) : (
              <>
                <QrCode className="h-4 w-4 mr-2" />
                Share QR Code
              </>
            )}
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Share "{title}"</DialogTitle>
          <DialogDescription>
            {description || "Scan this QR code to share this reward insight"}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col items-center justify-center p-6">
          {qrCode ? (
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <img 
                src={qrCode} 
                alt="QR Code" 
                className="w-[250px] h-[250px]"
              />
            </div>
          ) : (
            <div className="w-[250px] h-[250px] bg-muted rounded-lg flex items-center justify-center">
              <div className="animate-pulse">Generating QR Code...</div>
            </div>
          )}
          
          <p className="text-center text-sm text-muted-foreground mt-4 mb-6">
            Scan this code with your mobile device to view or share this insight
          </p>
          
          <Button onClick={downloadQRCode} disabled={!qrCode}>
            <Download className="h-4 w-4 mr-2" />
            Download QR Code
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}