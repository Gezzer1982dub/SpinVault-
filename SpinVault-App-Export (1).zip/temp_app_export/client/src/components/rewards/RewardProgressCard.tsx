import { useState } from "react";
import { Reward } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  WageringProgress, 
  SpinsProgress, 
  ExpiryProgress 
} from "@/components/ui/progress-tracker";
import { 
  Trash2, 
  CheckCircle, 
  Clock, 
  Zap, 
  ChevronUp, 
  ChevronDown,
  Gift,
  Coins,
  Settings,
  Save,
  ExternalLink
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

export function RewardProgressCard({ 
  reward, 
  onUpdate 
}: { 
  reward: Reward; 
  onUpdate?: () => void 
}) {
  const { toast } = useToast();
  const [expanded, setExpanded] = useState(false);
  const [editing, setEditing] = useState(false);
  
  // Progress tracking state
  const [progressType, setProgressType] = useState<string>(
    reward.progressType || ""
  );
  const [progressCurrent, setProgressCurrent] = useState<number>(
    reward.progressCurrent || 0
  );
  const [progressTarget, setProgressTarget] = useState<number>(
    reward.progressTarget || 0
  );
  const [progressUnit, setProgressUnit] = useState<string>(
    reward.progressUnit || "£"
  );

  // PATCH mutation to update progress values
  const updateProgressMutation = useMutation({
    mutationFn: async (progressData: {
      progressType?: string;
      progressCurrent?: number;
      progressTarget?: number;
      progressUnit?: string;
      progressLastUpdated?: Date;
    }) => {
      const res = await apiRequest("PATCH", `/api/rewards/${reward.id}`, progressData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Progress updated",
        description: "Your progress has been saved successfully.",
        variant: "success",
      });
      
      // Call the callback to refresh data
      if (onUpdate) onUpdate();
      
      // Exit edit mode
      setEditing(false);
    },
    onError: (error) => {
      toast({
        title: "Error updating progress",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mark reward as claimed mutation
  const claimRewardMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", `/api/rewards/${reward.id}`, {
        claimed: true,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Reward claimed!",
        description: "Congratulations on claiming your reward!",
        variant: "success",
      });
      
      if (onUpdate) onUpdate();
    },
    onError: (error) => {
      toast({
        title: "Error claiming reward",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete reward mutation
  const deleteRewardMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", `/api/rewards/${reward.id}`);
      return res;
    },
    onSuccess: () => {
      toast({
        title: "Reward deleted",
        description: "The reward has been removed from your account.",
        variant: "default",
      });
      
      if (onUpdate) onUpdate();
    },
    onError: (error) => {
      toast({
        title: "Error deleting reward",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Get time until expiry
  const timeUntilExpiry = formatDistanceToNow(new Date(reward.expiresAt), { addSuffix: true });
  
  // Format date for display
  const expiryDate = new Date(reward.expiresAt).toLocaleDateString();
  
  // Handle progress update submit
  const handleProgressUpdate = () => {
    updateProgressMutation.mutate({
      progressType,
      progressCurrent,
      progressTarget, 
      progressUnit,
      progressLastUpdated: new Date(),
    });
  };
  
  // Handle incrementing progress
  const handleIncrementProgress = (amount: number = 1) => {
    const newValue = progressCurrent + amount;
    setProgressCurrent(newValue);
    
    // Auto-save the incremented progress
    updateProgressMutation.mutate({
      progressCurrent: newValue,
      progressLastUpdated: new Date(),
    });
  };
  
  // Handle quick increment through UI buttons
  const quickIncrement = (amount: number) => {
    handleIncrementProgress(amount);
  };
  
  // Determine whether the progress configuration is complete
  const isProgressConfigured = 
    Boolean(progressType) && 
    progressTarget > 0;

  return (
    <Card className={cn(
      "overflow-hidden transition-all duration-200",
      reward.claimed && "opacity-75"
    )}>
      <CardContent className="p-4">
        {/* Top section with reward name, site, and expiry */}
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="font-semibold text-lg flex items-center">
              <Gift className="mr-2 h-5 w-5 text-primary" />
              {reward.reward}
            </h3>
            <p className="text-sm text-muted-foreground">{reward.site}</p>
          </div>
          
          <div className="flex flex-col items-end">
            <Badge 
              variant={reward.claimed ? "outline" : "secondary"} 
              className={reward.claimed ? "line-through opacity-70" : ""}
            >
              {reward.claimed ? "Claimed" : "Active"}
            </Badge>
            <p className="text-xs text-muted-foreground mt-1 flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              Expires {timeUntilExpiry}
            </p>
          </div>
        </div>
        
        {/* Progress section */}
        <div className="my-3">
          {!isProgressConfigured ? (
            <div className="bg-muted/50 rounded-md p-2 text-center">
              {editing ? (
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-xs font-medium">Type</label>
                      <Select
                        value={progressType}
                        onValueChange={setProgressType}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="wagering">Wagering</SelectItem>
                          <SelectItem value="spins">Spins</SelectItem>
                          <SelectItem value="deposit">Deposit</SelectItem>
                          <SelectItem value="visits">Visits</SelectItem>
                          <SelectItem value="playtime">Playtime</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-1">
                      <label className="text-xs font-medium">Target</label>
                      <div className="flex">
                        <Input
                          type="number"
                          value={progressTarget}
                          onChange={(e) => setProgressTarget(parseInt(e.target.value) || 0)}
                          className="w-full"
                        />
                        
                        <Select
                          value={progressUnit}
                          onValueChange={setProgressUnit}
                        >
                          <SelectTrigger className="w-16 ml-1">
                            <SelectValue placeholder="£" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="£">£</SelectItem>
                            <SelectItem value="€">€</SelectItem>
                            <SelectItem value="$">$</SelectItem>
                            <SelectItem value="spins">Spins</SelectItem>
                            <SelectItem value="mins">Mins</SelectItem>
                            <SelectItem value="times">Times</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-2 mt-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setEditing(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      size="sm"
                      onClick={handleProgressUpdate}
                      disabled={updateProgressMutation.isPending}
                    >
                      <Save className="h-4 w-4 mr-1" />
                      Save
                    </Button>
                  </div>
                </div>
              ) : (
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setEditing(true)}
                >
                  <Settings className="h-4 w-4 mr-1" />
                  Configure progress tracking
                </Button>
              )}
            </div>
          ) : (
            <div>
              {progressType === 'wagering' && (
                <WageringProgress
                  currentWager={progressCurrent}
                  requiredWager={progressTarget}
                />
              )}
              
              {progressType === 'spins' && (
                <SpinsProgress
                  usedSpins={progressCurrent}
                  totalSpins={progressTarget}
                />
              )}
              
              {!['wagering', 'spins'].includes(progressType) && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium capitalize">
                      {progressType} Progress
                    </span>
                    <span className="text-sm font-medium">
                      {progressCurrent} / {progressTarget} {progressUnit}
                    </span>
                  </div>
                  
                  <Progress 
                    value={(progressCurrent / progressTarget) * 100} 
                    className="h-2"
                  />
                  
                  <div className="text-xs text-muted-foreground text-right">
                    {(progressCurrent / progressTarget) * 100}% complete
                  </div>
                </div>
              )}
              
              {/* Quick action buttons */}
              <div className="mt-3 flex justify-between gap-2">
                <div className="flex gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => quickIncrement(1)}
                    className="h-8 px-2"
                  >
                    +1
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => quickIncrement(5)}
                    className="h-8 px-2"
                  >
                    +5
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => quickIncrement(10)}
                    className="h-8 px-2"
                  >
                    +10
                  </Button>
                </div>
                
                <Button 
                  variant="outline" 
                  size="sm"
                  className="h-8"
                  onClick={() => setEditing(true)}
                >
                  <Settings className="h-3 w-3 mr-1" />
                  Edit
                </Button>
              </div>
            </div>
          )}
        </div>
        
        {/* Time until expiration progress bar */}
        <div className="mt-4">
          <ExpiryProgress 
            expiresAt={new Date(reward.expiresAt)} 
            createdAt={new Date(reward.createdAt || Date.now() - 86400000)} 
          />
        </div>
        
        {/* Expand/collapse section */}
        <div className="mt-4 flex justify-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? (
              <>
                <ChevronUp className="h-4 w-4 mr-1" />
                Less
              </>
            ) : (
              <>
                <ChevronDown className="h-4 w-4 mr-1" />
                More
              </>
            )}
          </Button>
        </div>
        
        {/* Expanded section with additional details and actions */}
        {expanded && (
          <div className="mt-2 pt-2 border-t border-border animate-in fade-in-50 duration-200">
            <div className="grid grid-cols-2 gap-4">
              <Button
                variant={reward.claimed ? "outline" : "secondary"}
                disabled={reward.claimed || claimRewardMutation.isPending}
                onClick={() => claimRewardMutation.mutate()}
                className="w-full"
              >
                <CheckCircle className="h-4 w-4 mr-1" />
                {reward.claimed ? "Claimed" : "Mark as Claimed"}
              </Button>
              
              <Button
                variant="outline"
                className="w-full text-destructive hover:text-destructive"
                onClick={() => deleteRewardMutation.mutate()}
                disabled={deleteRewardMutation.isPending}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            </div>
            
            {/* Direct link to offer when available */}
            {reward.offerLink && (
              <div className="mt-3">
                <a 
                  href={reward.offerLink} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center w-full px-4 py-2 text-sm font-medium bg-primary/10 text-primary hover:bg-primary/20 rounded-md transition-colors"
                >
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Go to Offer
                </a>
              </div>
            )}
            
            {/* Offer link editor */}
            {editing && (
              <div className="mt-3 space-y-2">
                <label className="text-xs font-medium">Offer Link (Optional)</label>
                <div className="flex">
                  <Input
                    type="url"
                    value={reward.offerLink || ""}
                    onChange={(e) => {
                      updateProgressMutation.mutate({
                        offerLink: e.target.value
                      });
                    }}
                    placeholder="https://example.com/offer"
                    className="w-full"
                  />
                </div>
              </div>
            )}
            
            <div className="mt-3 text-xs text-muted-foreground">
              <p>Category: {reward.category}</p>
              <p>Expires on: {expiryDate}</p>
              {reward.progressLastUpdated && (
                <p>Last updated: {formatDistanceToNow(new Date(reward.progressLastUpdated), { addSuffix: true })}</p>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}