import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Loader2 } from "lucide-react";

interface AddRewardFormData {
  site: string;
  reward: string;
  expiresIn: string;
}

export function AddRewardForm() {
  const [formData, setFormData] = useState<AddRewardFormData>({
    site: "",
    reward: "",
    expiresIn: "",
  });
  const { toast } = useToast();
  const { user } = useAuth();

  const addRewardMutation = useMutation({
    mutationFn: async (data: AddRewardFormData) => {
      // Convert expiresIn from format like "2h" to seconds
      let expiresInSeconds = 3600; // Default 1 hour
      const match = data.expiresIn.match(/^(\d+)(h|m)?$/);
      if (match) {
        const number = parseInt(match[1]);
        const unit = match[2] || "h"; // Default to hours
        expiresInSeconds = unit === "h" ? number * 3600 : number * 60;
      }

      // Calculate expiry date
      const expiresAt = new Date();
      expiresAt.setSeconds(expiresAt.getSeconds() + expiresInSeconds);

      // Create reward data in the format expected by the server
      const rewardData = {
        site: data.site,
        reward: data.reward,
        expiresAt: expiresAt.toISOString(),
        userId: user?.id,
        category: "OTHER",
        claimed: false,
      };

      console.log("Sending reward data:", rewardData);
      const res = await apiRequest("POST", "/api/rewards", rewardData);
      return res.json();
    },
    onSuccess: () => {
      setFormData({ site: "", reward: "", expiresIn: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/rewards"] });
      toast({
        title: "Reward added",
        description: "The reward has been added successfully",
      });
    },
    onError: (error) => {
      console.error("Error adding reward:", error);
      toast({
        title: "Add failed",
        description: (error as Error).message || "Failed to add reward",
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addRewardMutation.mutate(formData);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-bold">Add New Reward</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="site" className="text-sm font-medium">
              Site Name
            </Label>
            <Input
              id="site"
              name="site"
              value={formData.site}
              onChange={handleInputChange}
              placeholder="e.g. Bet365"
              className="mt-1"
              required
            />
          </div>
          <div>
            <Label htmlFor="reward" className="text-sm font-medium">
              Reward
            </Label>
            <Input
              id="reward"
              name="reward"
              value={formData.reward}
              onChange={handleInputChange}
              placeholder="e.g. £10 Free Bet"
              className="mt-1"
              required
            />
          </div>
          <div>
            <Label htmlFor="expiresIn" className="text-sm font-medium">
              Expires In
            </Label>
            <Input
              id="expiresIn"
              name="expiresIn"
              value={formData.expiresIn}
              onChange={handleInputChange}
              placeholder="e.g. 24h"
              className="mt-1"
              required
            />
          </div>
          <Button
            type="submit"
            className="w-full"
            disabled={addRewardMutation.isPending}
          >
            {addRewardMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Plus className="mr-2 h-4 w-4" />
            )}
            Add Reward
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
