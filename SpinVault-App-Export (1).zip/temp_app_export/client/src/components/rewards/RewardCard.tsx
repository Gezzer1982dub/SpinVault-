import { useState } from "react";
import { Reward, UpdateReward } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { useCountdown } from "@/lib/countdownTimer";
import { Edit, CheckCircle2, X, Loader2, ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { ShareReward } from "./ShareReward";
import { RewardAnalysisComponent } from "./RewardAnalysis";

interface RewardCardProps {
  reward: Reward;
}

export function RewardCard({ reward }: RewardCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<UpdateReward>({
    site: reward.site,
    reward: reward.reward,
    expiresIn: reward.expiresIn,
    offerLink: reward.offerLink,
  });
  const { toast } = useToast();

  // Calculate the expiration time
  const { hours, minutes, seconds, isExpired } = useCountdown(
    new Date(reward.detectedAt).getTime() + reward.expiresIn * 1000
  );

  // Update reward mutation
  const updateMutation = useMutation({
    mutationFn: async (data: UpdateReward) => {
      await apiRequest("PUT", `/api/rewards/${reward.id}`, data);
    },
    onSuccess: () => {
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ["/api/rewards"] });
      toast({
        title: "Reward updated",
        description: "The reward has been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    if (name === "expiresIn") {
      // Convert input like "2h" to seconds
      const match = value.match(/^(\d+)(h|m)?$/);
      if (match) {
        const number = parseInt(match[1]);
        const unit = match[2] || "h"; // Default to hours
        const seconds = unit === "h" ? number * 3600 : number * 60;
        setFormData({ ...formData, [name]: seconds });
      } else {
        setFormData({ ...formData, [name]: value });
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  // Choose a color for the left border based on the type of reward
  let borderColor = "bg-gray-300";
  if (reward.reward.toLowerCase().includes("free bet")) {
    borderColor = "bg-red-500";
  } else if (reward.reward.toLowerCase().includes("free spin")) {
    borderColor = "bg-cyan-500";
  } else if (reward.reward.toLowerCase().includes("bingo")) {
    borderColor = "bg-blue-500";
  } else if (reward.reward.toLowerCase().includes("cashback")) {
    borderColor = "bg-green-500";
  } else if (reward.reward.toLowerCase().includes("bonus")) {
    borderColor = "bg-yellow-500";
  }

  return (
    <Card className="relative overflow-hidden transition-shadow duration-200 hover:shadow-md animate-in fade-in">
      <div className={`absolute left-0 top-0 bottom-0 w-1 ${borderColor}`}></div>
      <CardContent className="p-4">
        {!isEditing ? (
          <div>
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-lg">{reward.site}</h3>
                <p className="text-primary font-medium">{reward.reward}</p>
                <div className="text-xs text-muted-foreground mt-1">
                  Expires in:{" "}
                  <span
                    className={cn(
                      "font-medium",
                      isExpired
                        ? "text-red-500 font-semibold"
                        : hours === 0 && minutes < 30
                        ? "text-red-500"
                        : hours === 0
                        ? "text-yellow-500"
                        : "text-gray-700"
                    )}
                  >
                    {isExpired
                      ? "Expired"
                      : `${hours}h ${minutes}m ${seconds}s`}
                  </span>
                </div>
              </div>
              <div className="flex items-center">
                <ShareReward reward={reward} />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsEditing(true)}
                  className="text-gray-400 hover:text-gray-600 h-8 w-8 p-0"
                >
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            {/* Offer Link Button */}
            {reward.offerLink && (
              <div className="mt-3">
                <a 
                  href={reward.offerLink} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center w-full px-4 py-2 text-sm font-medium bg-primary/10 text-primary hover:bg-primary/20 rounded-md transition-colors"
                >
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Go to Offer
                </a>
              </div>
            )}
            
            {/* AI-powered reward analysis component */}
            <div className="mt-3 pt-3 border-t border-gray-100">
              <RewardAnalysisComponent reward={reward} />
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-4 space-y-3">
            <div>
              <Label htmlFor={`site-${reward.id}`} className="text-xs mb-1">
                Site
              </Label>
              <Input
                id={`site-${reward.id}`}
                name="site"
                value={formData.site}
                onChange={handleInputChange}
                className="text-sm"
                required
              />
            </div>
            <div>
              <Label htmlFor={`reward-${reward.id}`} className="text-xs mb-1">
                Reward
              </Label>
              <Input
                id={`reward-${reward.id}`}
                name="reward"
                value={formData.reward}
                onChange={handleInputChange}
                className="text-sm"
                required
              />
            </div>
            <div>
              <Label htmlFor={`expires-${reward.id}`} className="text-xs mb-1">
                Expires In (e.g. 4h)
              </Label>
              <Input
                id={`expires-${reward.id}`}
                name="expiresIn"
                value={
                  typeof formData.expiresIn === "number"
                    ? `${Math.floor(formData.expiresIn / 3600)}h`
                    : formData.expiresIn
                }
                onChange={handleInputChange}
                className="text-sm"
                required
              />
            </div>
            <div>
              <Label htmlFor={`offerlink-${reward.id}`} className="text-xs mb-1">
                Offer Link (URL to the specific promotion)
              </Label>
              <Input
                id={`offerlink-${reward.id}`}
                name="offerLink"
                type="url"
                value={formData.offerLink || ""}
                onChange={handleInputChange}
                placeholder="https://example.com/your-offer"
                className="text-sm"
              />
            </div>
            <div className="flex space-x-2">
              <Button 
                type="submit" 
                disabled={updateMutation.isPending}
                className="flex-1 h-9"
              >
                {updateMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="h-4 w-4 mr-1" />
                )}
                <span>Save</span>
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsEditing(false)}
                className="flex-1 h-9"
              >
                <X className="h-4 w-4 mr-1" />
                <span>Cancel</span>
              </Button>
            </div>
          </form>
        )}
      </CardContent>
    </Card>
  );
}


