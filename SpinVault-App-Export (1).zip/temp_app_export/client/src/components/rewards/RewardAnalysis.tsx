import { useState } from 'react';
import { Reward } from '@shared/schema';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Clock, BarChart2, PieChart, Trophy, Percent, DollarSign } from 'lucide-react';
import { HoverCard, HoverCardTrigger, HoverCardContent } from '@/components/ui/hover-card';
import { useToast } from '@/hooks/use-toast';

// Define the analysis type
interface RewardAnalysis {
  estimatedValue: number;
  expectedROI: number;
  difficulty: number;
  timeRequired: number;
  recommendedAction: string;
  tags: string[];
  confidence: number;
}

interface RewardAnalysisComponentProps {
  reward: Reward;
}

export function RewardAnalysisComponent({ reward }: RewardAnalysisComponentProps) {
  const [analysis, setAnalysis] = useState<RewardAnalysis | null>(null);
  const [expanded, setExpanded] = useState(false);
  const { toast } = useToast();

  const analysisMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', `/api/rewards/${reward.id}/analyze`, {});
      return res.json();
    },
    onSuccess: (data) => {
      setAnalysis(data.analysis);
      setExpanded(true);
    },
    onError: (error) => {
      toast({
        title: 'Analysis Failed',
        description: 'Unable to analyze this reward. Please try again later.',
        variant: 'destructive',
      });
    }
  });

  const getValueColor = (value: number) => {
    if (value <= 10) return 'text-red-500';
    if (value <= 30) return 'text-orange-500';
    if (value <= 60) return 'text-yellow-500';
    if (value <= 80) return 'text-green-500';
    return 'text-emerald-500';
  };

  const getDifficultyColor = (difficulty: number) => {
    if (difficulty >= 8) return 'text-red-500';
    if (difficulty >= 6) return 'text-orange-500';
    if (difficulty >= 4) return 'text-yellow-500';
    if (difficulty >= 2) return 'text-green-500';
    return 'text-emerald-500';
  };

  const formatMinutes = (minutes: number) => {
    if (minutes < 60) {
      return `${minutes} min`;
    } else {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return `${hours}h ${mins > 0 ? `${mins}m` : ''}`;
    }
  };

  if (!analysis && analysisMutation.isPending) {
    return (
      <Card className="mt-4 overflow-hidden border-dashed animate-pulse">
        <CardContent className="p-6 flex flex-col items-center justify-center text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mt-2 mb-2" />
          <p className="text-muted-foreground text-sm">Analyzing reward value...</p>
          <p className="text-xs text-muted-foreground mt-1">This may take a few seconds</p>
        </CardContent>
      </Card>
    );
  }

  if (!analysis) {
    return (
      <Card className="mt-4 overflow-hidden border-dashed hover:border-primary/50 transition-all">
        <CardContent className="p-6">
          <Button 
            variant="outline" 
            className="w-full" 
            onClick={() => analysisMutation.mutate()}
          >
            <BarChart2 className="h-4 w-4 mr-2" />
            Analyze Reward Value
          </Button>
          <p className="text-xs text-center text-muted-foreground mt-2">
            Get insights on the true value and optimal strategies
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mt-4 overflow-hidden">
      <CardHeader className="p-4 pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-base font-medium flex items-center">
            <BarChart2 className="h-4 w-4 mr-2 text-primary" />
            AI-Powered Reward Analysis
          </CardTitle>
          <Badge 
            variant={analysis.confidence > 0.7 ? "default" : (analysis.confidence > 0.4 ? "outline" : "destructive")}
            className="text-xs"
          >
            {Math.round(analysis.confidence * 100)}% confidence
          </Badge>
        </div>
        <CardDescription className="text-xs">
          Advanced value estimation based on reward terms
        </CardDescription>
      </CardHeader>

      <CardContent className="p-4 pt-0 space-y-4">
        {/* Main metrics summary */}
        <div className="grid grid-cols-2 gap-2 mt-2">
          <div className="space-y-1">
            <p className="text-xs font-medium text-muted-foreground">Estimated Value</p>
            <p className={`text-xl font-semibold flex items-center ${getValueColor(analysis.estimatedValue)}`}>
              <DollarSign className="h-4 w-4 mr-1 opacity-70" />
              £{analysis.estimatedValue.toFixed(2)}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium text-muted-foreground">Expected ROI</p>
            <p className={`text-xl font-semibold flex items-center ${getValueColor(analysis.expectedROI)}`}>
              <Percent className="h-4 w-4 mr-1 opacity-70" />
              {Math.round(analysis.expectedROI)}%
            </p>
          </div>
        </div>

        {expanded && (
          <>
            {/* Secondary metrics */}
            <div className="space-y-3 pt-2">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-xs font-medium flex items-center">
                    <Clock className="h-3 w-3 mr-1 opacity-70" /> Time Required
                  </span>
                  <span className="text-xs">{formatMinutes(analysis.timeRequired)}</span>
                </div>
                <Progress value={Math.min(100, (analysis.timeRequired / 60) * 100)} className="h-2" />
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-xs font-medium flex items-center">
                    <PieChart className="h-3 w-3 mr-1 opacity-70" /> Claim Difficulty
                  </span>
                  <span className={`text-xs ${getDifficultyColor(analysis.difficulty)}`}>
                    {analysis.difficulty}/10
                  </span>
                </div>
                <Progress value={analysis.difficulty * 10} className="h-2" />
              </div>
            </div>

            {/* Recommended action */}
            <div className="bg-primary/5 rounded-md p-3 text-sm">
              <div className="flex items-start">
                <Trophy className="h-4 w-4 mr-2 mt-0.5 text-primary" />
                <div>
                  <p className="font-medium text-sm mb-1">Recommended Action</p>
                  <p className="text-sm text-muted-foreground">
                    {analysis.recommendedAction}
                  </p>
                </div>
              </div>
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-1 pt-1">
              {analysis.tags.map((tag, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
          </>
        )}
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => setExpanded(!expanded)} 
          className="w-full text-xs"
        >
          {expanded ? "Show Less" : "Show More Details"}
        </Button>
      </CardFooter>
    </Card>
  );
}

// Tooltip component explaining the analysis
export function AnalysisInfoTooltip() {
  return (
    <HoverCard>
      <HoverCardTrigger asChild>
        <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full">
          <span className="sr-only">Analysis Info</span>
          <span className="text-xs font-semibold">i</span>
        </Button>
      </HoverCardTrigger>
      <HoverCardContent className="w-80 text-sm">
        <div className="space-y-2">
          <h4 className="font-medium">About AI Analysis</h4>
          <p className="text-sm text-muted-foreground">
            Our AI analyzes gambling rewards to estimate their true value and optimal usage strategy.
            The analysis considers factors like wagering requirements, time constraints, and practical limitations.
          </p>
          <div className="pt-2">
            <p className="text-xs text-muted-foreground">
              • <span className="font-medium">Estimated Value:</span> Approximate monetary worth in GBP
            </p>
            <p className="text-xs text-muted-foreground">
              • <span className="font-medium">Expected ROI:</span> Return on investment after meeting requirements
            </p>
            <p className="text-xs text-muted-foreground">
              • <span className="font-medium">Difficulty:</span> Complexity of claiming full value
            </p>
            <p className="text-xs text-muted-foreground">
              • <span className="font-medium">Time Required:</span> Minutes needed to claim and use
            </p>
          </div>
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}