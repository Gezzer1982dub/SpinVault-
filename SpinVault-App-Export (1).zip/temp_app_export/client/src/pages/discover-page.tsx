import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
// Import types from schema (we can't directly import the exact type, 
// as it's not exported from the shared folder to client)
type Offering = {
  id: number;
  site: string;
  title: string; // This is used instead of reward
  value: string;
  category: string;
  description: string;
  detectedAt: Date;
  isNewMemberOffer: boolean;
  requirements: string | null;
  expiresAt: Date | null;
  url: string | null;
  isLimitedTime: boolean | null;
};
import { Calendar, Gift, Star } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function DiscoverPage() {
  const { user } = useAuth();
  const [category, setCategory] = useState<string>("all");
  const [site, setSite] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<string>("new-member");

  const { data: offerings, isLoading, refetch } = useQuery<Offering[]>({
    queryKey: ["/api/offerings", { 
      isNewMemberOffer: activeTab === "new-member" ? true : undefined,
      category: category !== "all" ? category : undefined,
      site: site !== "all" ? site : undefined
    }],
    queryFn: async ({ queryKey }) => {
      const [, filters] = queryKey as [string, { 
        isNewMemberOffer?: boolean;
        category?: string;
        site?: string;
      }];
      const params = new URLSearchParams();
      
      if (filters.isNewMemberOffer !== undefined) {
        params.append('isNewMemberOffer', String(filters.isNewMemberOffer));
      }
      
      if (filters.category) {
        params.append('category', filters.category);
      }
      
      if (filters.site) {
        params.append('site', filters.site);
      }
      
      const queryString = params.toString();
      const endpoint = `/api/offerings${queryString ? '?' + queryString : ''}`;
      
      const response = await fetch(endpoint);
      if (!response.ok) {
        throw new Error('Failed to fetch offerings');
      }
      
      return response.json();
    },
  });

  // Filter offerings by category and site (for UI display)
  const filteredOfferings = offerings || [];

  // Extract unique categories and sites for filters
  const categoriesSet = new Set<string>();
  const sitesSet = new Set<string>();
  
  if (offerings) {
    offerings.forEach(offering => {
      if (offering.category) categoriesSet.add(offering.category);
      if (offering.site) sitesSet.add(offering.site);
    });
  }
  
  const categories = Array.from(categoriesSet);
  const sites = Array.from(sitesSet);

  // Handle claiming an offering
  const handleClaimOffering = async (offeringId: number) => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to claim this offer",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await apiRequest("POST", `/api/offerings/${offeringId}/claim`);
      const result = await response.json();

      if (result.success) {
        // Add to rewards
        toast({
          title: "Offer Claimed",
          description: "The offer has been added to your rewards",
        });
        
        // If there's a redirect URL, open it in a new tab
        if (result.redirectUrl) {
          window.open(result.redirectUrl, '_blank');
        }
      } else {
        throw new Error(result.message || "Failed to claim offer");
      }
    } catch (error) {
      console.error("Error claiming offering:", error);
      toast({
        title: "Error",
        description: "Failed to claim the offer. Please try again.",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    refetch();
  }, [activeTab, category, site, refetch]);

  const getExpiryColor = (daysLeft: number) => {
    if (daysLeft < 3) return "text-red-500";
    if (daysLeft < 7) return "text-amber-500";
    return "text-emerald-500";
  };

  return (
    <div className="container py-8">
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold">Discover New Rewards</h1>
          <p className="text-muted-foreground mt-2">
            Find the latest gambling site offers and rewards before you even sign up
          </p>
        </div>

        <Tabs defaultValue="new-member" onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full md:w-[400px] grid-cols-2">
            <TabsTrigger value="new-member">New Member Offers</TabsTrigger>
            <TabsTrigger value="special">Special Promotions</TabsTrigger>
          </TabsList>
          
          <div className="flex flex-col md:flex-row gap-4 my-4">
            <div className="w-full md:w-[200px]">
              <Select 
                value={category} 
                onValueChange={setCategory}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat.replace("_", " ")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full md:w-[200px]">
              <Select 
                value={site} 
                onValueChange={setSite}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Site" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sites</SelectItem>
                  {sites.map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <TabsContent value="new-member" className="mt-4">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array(6).fill(null).map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader>
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-6 w-full mt-2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-20 w-full" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <>
                {filteredOfferings.length === 0 ? (
                  <div className="text-center py-12">
                    <h3 className="text-xl font-semibold">No offers found</h3>
                    <p className="text-muted-foreground mt-2">
                      Try adjusting your filters or check back later for new offers
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredOfferings.map((offering) => (
                      <Card key={offering.id} className="overflow-hidden">
                        <CardHeader className="pb-3">
                          <div className="flex justify-between items-start">
                            <Badge variant="outline">{offering.site}</Badge>
                            <Badge variant="secondary">{offering.category.replace("_", " ")}</Badge>
                          </div>
                          <CardTitle className="text-lg mt-2">
                            {offering.title}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div className="flex items-center gap-2">
                              <Gift className="text-primary h-4 w-4" />
                              <span className="text-sm">
                                {offering.description || "Get this special offer when you sign up"}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Calendar className="text-primary h-4 w-4" />
                              <span className="text-sm">
                                Detected: {new Date(offering.detectedAt).toLocaleDateString()}
                              </span>
                            </div>
                            {offering.value && (
                              <div className="flex items-center gap-2">
                                <Star className="text-yellow-500 h-4 w-4" />
                                <span className="text-sm">
                                  Value: {offering.value}
                                </span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button 
                            onClick={() => handleClaimOffering(offering.id)} 
                            className="w-full"
                          >
                            Claim Offer
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                )}
              </>
            )}
          </TabsContent>
          
          <TabsContent value="special" className="mt-4">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array(6).fill(null).map((_, i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader>
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-6 w-full mt-2" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-20 w-full" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <>
                {filteredOfferings.length === 0 ? (
                  <div className="text-center py-12">
                    <h3 className="text-xl font-semibold">No special promotions found</h3>
                    <p className="text-muted-foreground mt-2">
                      Try adjusting your filters or check back later for new promotions
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredOfferings.map((offering) => (
                      <Card key={offering.id} className="overflow-hidden">
                        <CardHeader className="pb-3">
                          <div className="flex justify-between items-start">
                            <Badge variant="outline">{offering.site}</Badge>
                            <Badge variant="secondary">{offering.category.replace("_", " ")}</Badge>
                          </div>
                          <CardTitle className="text-lg mt-2">
                            {offering.title}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div className="flex items-center gap-2">
                              <Gift className="text-primary h-4 w-4" />
                              <span className="text-sm">
                                {offering.description || "Limited time special promotion"}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Calendar className="text-primary h-4 w-4" />
                              <span className="text-sm">
                                Detected: {new Date(offering.detectedAt).toLocaleDateString()}
                              </span>
                            </div>
                            {offering.value && (
                              <div className="flex items-center gap-2">
                                <Star className="text-yellow-500 h-4 w-4" />
                                <span className="text-sm">
                                  Value: {offering.value}
                                </span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button 
                            onClick={() => handleClaimOffering(offering.id)} 
                            className="w-full"
                          >
                            Claim Offer
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                )}
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}