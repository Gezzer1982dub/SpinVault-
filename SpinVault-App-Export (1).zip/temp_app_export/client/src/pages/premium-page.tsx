import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";

// Make sure to call `loadStripe` outside of a component's render
// to avoid recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

// Price IDs from Stripe product catalog
// NOTE: Since we don't have actual Stripe product IDs yet, we'll use these placeholder values
// In a production environment, these would be actual price IDs from your Stripe dashboard
const PRICE_IDS = {
  monthly: "price_1MqAGQEJKQLiVVKY70UX8v5U", // Example test price ID
  quarterly: "price_1MqAGQEJKQLiVVKY70UX8v5U", // Example test price ID 
  annual: "price_1MqAGQEJKQLiVVKY70UX8v5U", // Example test price ID
};

// CheckoutForm component to handle Stripe payment
const CheckoutForm = ({ 
  onSuccess, 
  onCancel 
}: { 
  onSuccess: () => void; 
  onCancel: () => void; 
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // In development environment, we'll simulate a successful payment
    // without actually calling Stripe since we're using mock price IDs
    const isDevelopment = import.meta.env.DEV;
    
    setIsLoading(true);

    if (isDevelopment) {
      // Simulate a brief delay for realism
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simulate success
      toast({
        title: "Payment Successful",
        description: "Your subscription has been activated (Development Mode)",
      });
      onSuccess();
      setIsLoading(false);
      return;
    }

    // Production code path using real Stripe
    if (!stripe || !elements) {
      // Stripe.js hasn't yet loaded.
      setIsLoading(false);
      return;
    }

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin + "/premium-success",
        },
        redirect: "if_required",
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message || "An error occurred during payment",
          variant: "destructive",
        });
      } else {
        // Payment succeeded
        toast({
          title: "Payment Successful",
          description: "Your subscription has been activated",
        });
        onSuccess();
      }
    } catch (e) {
      console.error("Payment error:", e);
      toast({
        title: "Payment Failed",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    }

    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PaymentElement />
      <div className="flex justify-between mt-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onCancel}
          disabled={isLoading}
        >
          Cancel
        </Button>
        <Button type="submit" disabled={!stripe || isLoading}>
          {isLoading ? "Processing..." : "Subscribe Now"}
        </Button>
      </div>
    </form>
  );
};

export default function PremiumPage() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isPremium, setIsPremium] = useState(false);
  const [expiryDate, setExpiryDate] = useState<string | null>(null);
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [checkoutDialogOpen, setCheckoutDialogOpen] = useState(false);
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<{
    id: string;
    name: string;
    price: string;
    interval: string;
  } | null>(null);
  const [email, setEmail] = useState("");
  
  useEffect(() => {
    // Redirect to auth if not logged in
    if (!isLoading && !user) {
      setLocation("/auth");
      return;
    }

    // Check premium status if logged in
    if (user) {
      checkPremiumStatus();
      // Set email from user data if available
      if (user.email) {
        setEmail(user.email);
      }
    }
  }, [user, isLoading, setLocation]);

  const checkPremiumStatus = async () => {
    try {
      const response = await apiRequest("GET", "/api/premium/status");
      const data = await response.json();
      
      setIsPremium(data.isPremium);
      if (data.expiresAt) {
        setExpiryDate(new Date(data.expiresAt).toLocaleDateString());
      }
    } catch (error) {
      console.error("Error checking premium status:", error);
      toast({
        title: "Error",
        description: "Could not check premium status. Please try again later.",
        variant: "destructive",
      });
    }
  };

  const handlePlanSelect = async (plan: string, price: string, interval: string) => {
    if (!user) return;
    
    let priceId;
    switch (interval) {
      case "month":
        priceId = PRICE_IDS.monthly;
        break;
      case "quarter":
        priceId = PRICE_IDS.quarterly;
        break;
      case "year":
        priceId = PRICE_IDS.annual;
        break;
      default:
        priceId = PRICE_IDS.monthly;
    }
    
    setSelectedPlan({
      id: priceId,
      name: plan,
      price,
      interval
    });
    
    setCheckoutDialogOpen(true);
  };
  
  const createSubscription = async () => {
    if (!user || !selectedPlan) return;
    
    setIsUpgrading(true);
    try {
      // Create a subscription intent on the server
      console.log("Creating subscription for plan:", selectedPlan.name);
      const response = await apiRequest("POST", "/api/get-or-create-subscription", { 
        priceId: selectedPlan.id,
        email: email || user.email || "test@example.com" // In development, use placeholder if needed
      });
      
      const data = await response.json();
      console.log("Subscription response:", data);
      
      if (data.success === false) {
        throw new Error(data.error?.message || "Failed to create subscription");
      }
      
      if (data.clientSecret) {
        setClientSecret(data.clientSecret);
        console.log("Client secret received successfully");
      } else {
        throw new Error("No client secret returned from the server");
      }
    } catch (error) {
      console.error("Error creating subscription:", error);
      toast({
        title: "Subscription Error",
        description: error instanceof Error ? error.message : "Could not create subscription. Please try again.",
        variant: "destructive",
      });
      setCheckoutDialogOpen(false);
    } finally {
      setIsUpgrading(false);
    }
  };
  
  // Effect to trigger subscription creation when the dialog opens
  useEffect(() => {
    if (checkoutDialogOpen && selectedPlan && !clientSecret) {
      createSubscription();
    }
  }, [checkoutDialogOpen, selectedPlan, clientSecret]);
  
  const handleCheckoutSuccess = async () => {
    setCheckoutDialogOpen(false);
    setClientSecret(null);
    setSelectedPlan(null);
    
    // Refresh premium status
    await checkPremiumStatus();
    
    toast({
      title: "Premium Activated",
      description: "Your premium subscription has been successfully activated!",
    });
  };
  
  const handleCheckoutCancel = () => {
    setCheckoutDialogOpen(false);
    setClientSecret(null);
    setSelectedPlan(null);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading" />
      </div>
    );
  }

  return (
    <div className="container py-10 mx-auto max-w-5xl">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-extrabold mb-2 bg-gradient-to-r from-primary to-indigo-600 text-transparent bg-clip-text">
          SpinVault Premium
        </h1>
        <p className="text-xl text-muted-foreground">
          Unlock advanced reward detection and management
        </p>
      </header>

      {isPremium ? (
        <div className="bg-gradient-to-r from-indigo-600/10 to-primary/10 p-8 rounded-lg text-center mb-10">
          <h2 className="text-2xl font-bold mb-2">You're a Premium Member! 🎉</h2>
          <p className="text-lg mb-4">
            All premium features are unlocked and ready to use.
            {expiryDate && (
              <span className="block mt-2 text-muted-foreground">
                Your subscription is active until {expiryDate}
              </span>
            )}
          </p>
          <Button onClick={() => setLocation("/")} className="mt-2">
            Return to Dashboard
          </Button>
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-6 mb-10">
          <Card className="border-2 hover:border-primary/50 transition-all duration-300">
            <CardHeader>
              <CardTitle>Monthly</CardTitle>
              <div className="text-3xl font-bold">£4.99<span className="text-sm font-normal text-muted-foreground">/month</span></div>
              <CardDescription>Perfect for casual betters</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  Unlimited reward detections
                </li>
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  Cross-device synchronization
                </li>
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  All betting sites supported
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={() => handlePlanSelect("Monthly", "£4.99", "month")} 
                className="w-full" 
                disabled={isUpgrading}
              >
                {isUpgrading ? 'Processing...' : 'Get Monthly'}
              </Button>
            </CardFooter>
          </Card>

          <Card className="border-2 border-primary md:scale-105 shadow-lg">
            <CardHeader>
              <div className="bg-primary text-white px-3 py-1 rounded-full text-xs font-bold w-fit">MOST POPULAR</div>
              <CardTitle>Annual</CardTitle>
              <div className="text-3xl font-bold">£39.99<span className="text-sm font-normal text-muted-foreground">/year</span></div>
              <CardDescription>Save over 30%</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  Unlimited reward detections
                </li>
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  Cross-device synchronization
                </li>
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  Hourly scans for new offers
                </li>
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  All betting sites supported
                </li>
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  Priority support
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={() => handlePlanSelect("Annual", "£39.99", "year")} 
                className="w-full" 
                disabled={isUpgrading}
              >
                {isUpgrading ? 'Processing...' : 'Get Annual (Best Value)'}
              </Button>
            </CardFooter>
          </Card>

          <Card className="border-2 hover:border-primary/50 transition-all duration-300">
            <CardHeader>
              <CardTitle>Quarterly</CardTitle>
              <div className="text-3xl font-bold">£12.99<span className="text-sm font-normal text-muted-foreground">/quarter</span></div>
              <CardDescription>Every 3 months</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  Unlimited reward detections
                </li>
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  Cross-device synchronization
                </li>
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  Hourly scans for new offers
                </li>
                <li className="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                  All betting sites supported
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={() => handlePlanSelect("Quarterly", "£12.99", "quarter")} 
                className="w-full" 
                disabled={isUpgrading}
              >
                {isUpgrading ? 'Processing...' : 'Get Quarterly'}
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}
      
      {/* Email collection dialog when user has no email */}
      {!user?.email && checkoutDialogOpen && !clientSecret && (
        <Dialog open={checkoutDialogOpen} onOpenChange={setCheckoutDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Complete your subscription</DialogTitle>
              <DialogDescription>
                Please provide your email to continue with your subscription.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@example.com"
                />
              </div>
            </div>
            <div className="flex justify-between">
              <Button variant="outline" onClick={handleCheckoutCancel}>
                Cancel
              </Button>
              <Button 
                type="button" 
                onClick={createSubscription}
                disabled={!email || !email.includes('@')}
              >
                Continue
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Stripe payment dialog */}
      {clientSecret && (
        <Dialog open={checkoutDialogOpen} onOpenChange={setCheckoutDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Complete your {selectedPlan?.name} subscription</DialogTitle>
              <DialogDescription>
                You're subscribing to SpinVault Premium for {selectedPlan?.price}/{selectedPlan?.interval}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <Elements stripe={stripePromise} options={{ clientSecret }}>
                <CheckoutForm 
                  onSuccess={handleCheckoutSuccess} 
                  onCancel={handleCheckoutCancel} 
                />
              </Elements>
            </div>
          </DialogContent>
        </Dialog>
      )}

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-secondary p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Unlimited Rewards</h3>
          <p className="text-muted-foreground">Detect and track an unlimited number of rewards from all your gambling sites.</p>
        </div>
        <div className="bg-secondary p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Cross-Device Sync</h3>
          <p className="text-muted-foreground">Seamlessly sync your rewards and settings across all your devices.</p>
        </div>
        <div className="bg-secondary p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">All Sites Supported</h3>
          <p className="text-muted-foreground">Premium users get support for all major gambling and betting websites.</p>
        </div>
      </div>
    </div>
  );
}