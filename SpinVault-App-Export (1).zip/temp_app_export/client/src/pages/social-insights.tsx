import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  Loader2, 
  TrendingUp, 
  Users, 
  Award, 
  BarChart3, 
  Trophy, 
  Share2,
  ChevronDown
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { getQueryFn } from "@/lib/queryClient";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend,
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell
} from "recharts";

// Import our social sharing components
import { ShareQRCode } from "@/components/social/share-qr-code";
import { MetricCard } from "@/components/social/metric-card";
import CommunityInsights from "@/components/social/community-insights";

// Color palette
const COLORS = ['#FF6B6B', '#4ECDC4', '#FFD166', '#06D6A0', '#118AB2', '#073B4C', '#847AF6'];

type CategoryStat = {
  category: string;
  count: number;
  latest: string;
  claim_rate: number;
};

type SiteStat = {
  site: string;
  count: number;
};

type MonthlyStat = {
  month: string;
  count: number;
};

type ExpiryData = {
  avg_days_valid: number;
  expired_unclaimed: number;
  active: number;
};

type RewardInsights = {
  categories: CategoryStat[];
  sites: SiteStat[];
  monthly: MonthlyStat[];
  expiry: ExpiryData;
};

type LeaderboardEntry = {
  rank: number;
  username: string;
  rewardCount: number;
  totalValue: number;
};

type TrendingItem = {
  name: string;
  count: number;
  trend: number;
};

type TrendingData = {
  sites: TrendingItem[];
  categories: TrendingItem[];
};

export default function SocialInsights() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("insights");
  
  // Get anonymized reward insights
  const { 
    data: insightsData, 
    isLoading: isLoadingInsights 
  } = useQuery<{ success: boolean, stats: RewardInsights }>({
    queryKey: ["/api/social/insights"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user,
    staleTime: 60 * 1000, // 1 minute
  });
  
  // Get leaderboard data
  const { 
    data: leaderboardData, 
    isLoading: isLoadingLeaderboard 
  } = useQuery<{ success: boolean, leaderboard: LeaderboardEntry[] }>({
    queryKey: ["/api/social/leaderboard"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user && activeTab === "leaderboard",
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
  
  // Get trending data
  const { 
    data: trendingData, 
    isLoading: isLoadingTrending 
  } = useQuery<{ success: boolean, trending: TrendingData }>({
    queryKey: ["/api/social/trending"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user && activeTab === "trending",
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
  
  // Format monthly data for chart
  const formattedMonthlyData = insightsData?.stats?.monthly?.map(item => {
    const date = new Date(item.month);
    return {
      month: date.toLocaleDateString('en-GB', { month: 'short', year: 'numeric' }),
      count: item.count
    };
  }) || [];
  
  // Prepare category data for pie chart
  const categoryPieData = insightsData?.stats?.categories?.map(cat => ({
    name: cat.category,
    value: cat.count
  })) || [];
  
  // Format expiry data for visualization
  const expiryData = insightsData?.stats?.expiry;
  
  return (
    <div className="container py-10 max-w-7xl mx-auto">
      <div className="flex flex-col space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">
            Social Insights Dashboard
          </h1>
          <p className="text-muted-foreground">
            Discover trends and insights from the SpinVault community.
            All data is anonymized to protect user privacy.
          </p>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="insights">
              <BarChart3 className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Global</span> Insights
            </TabsTrigger>
            <TabsTrigger value="leaderboard">
              <Award className="h-4 w-4 mr-2" />
              Leaderboard
            </TabsTrigger>
            <TabsTrigger value="trending">
              <TrendingUp className="h-4 w-4 mr-2" />
              Trending
            </TabsTrigger>
            <TabsTrigger value="community">
              <Users className="h-4 w-4 mr-2" />
              Community
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="insights" className="mt-6">
            {isLoadingInsights ? (
              <div className="flex justify-center items-center h-96">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : !insightsData?.success ? (
              <div className="text-center py-10">
                <p className="text-muted-foreground">Failed to load insights data.</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => window.location.reload()}
                >
                  Try Again
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Monthly Trend Chart */}
                <Card className="col-span-1 md:col-span-2">
                  <CardHeader>
                    <CardTitle>Reward Discoveries Over Time</CardTitle>
                    <CardDescription>
                      Monthly trend of rewards found by the community
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={formattedMonthlyData}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <RechartsTooltip />
                          <Legend />
                          <Line 
                            type="monotone" 
                            dataKey="count" 
                            name="Rewards Found"
                            stroke="#8884d8" 
                            activeDot={{ r: 8 }} 
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Top Categories Pie Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Reward Categories</CardTitle>
                    <CardDescription>
                      Distribution of reward types across all users
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={categoryPieData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            nameKey="name"
                            label={({ name, percent }) => 
                              `${name}: ${(percent * 100).toFixed(0)}%`
                            }
                          >
                            {categoryPieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <RechartsTooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Top Sites */}
                <Card>
                  <CardHeader>
                    <CardTitle>Top Reward Sites</CardTitle>
                    <CardDescription>
                      Gambling sites with the most rewards
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {insightsData?.stats?.sites?.slice(0, 5).map((site, i) => (
                        <div key={site.site} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="w-6 text-muted-foreground">{i + 1}.</div>
                            <div>{site.site}</div>
                          </div>
                          <div className="font-semibold">{site.count}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                {/* Expiry Stats */}
                <Card className="col-span-1 md:col-span-2">
                  <CardHeader>
                    <CardTitle>Reward Lifecycle Insights</CardTitle>
                    <CardDescription>
                      Stats about reward expiration and usage across the platform
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-muted rounded-lg p-4 text-center">
                        <h3 className="text-5xl font-bold text-primary">
                          {expiryData?.avg_days_valid || 0}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                          Average Days Before Expiry
                        </p>
                      </div>
                      <div className="bg-muted rounded-lg p-4 text-center">
                        <h3 className="text-5xl font-bold text-amber-500">
                          {expiryData?.active || 0}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                          Active Rewards
                        </p>
                      </div>
                      <div className="bg-muted rounded-lg p-4 text-center">
                        <h3 className="text-5xl font-bold text-destructive">
                          {expiryData?.expired_unclaimed || 0}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                          Expired Unclaimed
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="leaderboard" className="mt-6">
            {isLoadingLeaderboard ? (
              <div className="flex justify-center items-center h-96">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : !leaderboardData?.success ? (
              <div className="text-center py-10">
                <p className="text-muted-foreground">Failed to load leaderboard data.</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => window.location.reload()}
                >
                  Try Again
                </Button>
              </div>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="h-5 w-5 text-amber-500" />
                    Top Reward Hunters
                  </CardTitle>
                  <CardDescription>
                    Users who have found the most rewards (usernames anonymized)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left font-medium p-2 pl-0">Rank</th>
                          <th className="text-left font-medium p-2">User</th>
                          <th className="text-right font-medium p-2">Rewards</th>
                          <th className="text-right font-medium p-2 pr-0">Value Score</th>
                        </tr>
                      </thead>
                      <tbody>
                        {leaderboardData?.leaderboard.map((entry) => (
                          <tr key={entry.username} className="border-b">
                            <td className="p-2 pl-0">
                              {entry.rank === 1 ? (
                                <div className="flex justify-center items-center h-6 w-6 rounded-full bg-amber-500 text-white">
                                  1
                                </div>
                              ) : entry.rank === 2 ? (
                                <div className="flex justify-center items-center h-6 w-6 rounded-full bg-gray-400 text-white">
                                  2
                                </div>
                              ) : entry.rank === 3 ? (
                                <div className="flex justify-center items-center h-6 w-6 rounded-full bg-amber-700 text-white">
                                  3
                                </div>
                              ) : (
                                <div className="text-muted-foreground pl-1">{entry.rank}</div>
                              )}
                            </td>
                            <td className="p-2">{entry.username}</td>
                            <td className="p-2 text-right font-medium">{entry.rewardCount}</td>
                            <td className="p-2 pr-0 text-right font-medium">{entry.totalValue}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="community" className="mt-6">
            <CommunityInsights />
          </TabsContent>
          
          <TabsContent value="trending" className="mt-6">
            {isLoadingTrending ? (
              <div className="flex justify-center items-center h-96">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : !trendingData?.success ? (
              <div className="text-center py-10">
                <p className="text-muted-foreground">Failed to load trending data.</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => window.location.reload()}
                >
                  Try Again
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Trending Sites */}
                <Card>
                  <CardHeader>
                    <CardTitle>Trending Sites</CardTitle>
                    <CardDescription>
                      Gambling sites with increasing reward activity
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {trendingData?.trending?.sites?.map((site) => (
                        <div key={site.name} className="flex items-center justify-between">
                          <div className="flex-1 mr-4">
                            <div className="text-sm font-medium mb-1">{site.name}</div>
                            <div className="bg-muted h-2 rounded-full overflow-hidden">
                              <div 
                                className="bg-primary h-full" 
                                style={{width: `${Math.min(100, site.count * 5)}%`}} 
                              />
                            </div>
                          </div>
                          <div className="flex flex-col items-end">
                            <div className="font-semibold">{site.count}</div>
                            <div className={`text-xs flex items-center ${
                              site.trend > 0 ? 'text-green-500' : 
                              site.trend < 0 ? 'text-red-500' : 'text-muted-foreground'
                            }`}>
                              {site.trend > 0 ? (
                                <TrendingUp className="h-3 w-3 mr-1" />
                              ) : site.trend < 0 ? (
                                <TrendingDown className="h-3 w-3 mr-1" />
                              ) : null}
                              {site.trend > 0 ? '+' : ''}{site.trend}%
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                {/* Trending Categories */}
                <Card>
                  <CardHeader>
                    <CardTitle>Trending Categories</CardTitle>
                    <CardDescription>
                      Reward categories with increasing activity
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {trendingData?.trending?.categories?.map((category) => (
                        <div key={category.name} className="flex items-center justify-between">
                          <div className="flex-1 mr-4">
                            <div className="text-sm font-medium mb-1">{category.name}</div>
                            <div className="bg-muted h-2 rounded-full overflow-hidden">
                              <div 
                                className="bg-primary h-full" 
                                style={{width: `${Math.min(100, category.count * 5)}%`}} 
                              />
                            </div>
                          </div>
                          <div className="flex flex-col items-end">
                            <div className="font-semibold">{category.count}</div>
                            <div className={`text-xs flex items-center ${
                              category.trend > 0 ? 'text-green-500' : 
                              category.trend < 0 ? 'text-red-500' : 'text-muted-foreground'
                            }`}>
                              {category.trend > 0 ? (
                                <TrendingUp className="h-3 w-3 mr-1" />
                              ) : category.trend < 0 ? (
                                <TrendingDown className="h-3 w-3 mr-1" />
                              ) : null}
                              {category.trend > 0 ? '+' : ''}{category.trend}%
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                {/* Community Information */}
                <Card className="col-span-1 md:col-span-2">
                  <CardHeader>
                    <CardTitle>Community Insights</CardTitle>
                    <CardDescription>
                      How the SpinVault community is saving money together
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center space-y-6 py-4">
                      <div className="text-4xl font-bold">
                        <span className="bg-clip-text text-transparent bg-gradient-to-r from-pink-500 to-violet-500">
                          We've found {calculateTotalRewards(insightsData)} rewards together!
                        </span>
                      </div>
                      <p className="max-w-2xl mx-auto text-muted-foreground">
                        The SpinVault community is helping everyone get the most out of their 
                        gambling rewards. Together, we're tracking rewards, avoiding expirations, 
                        and maximizing value.
                      </p>
                      <Button
                        size="lg"
                        onClick={() => {
                          // Copy share link
                          navigator.clipboard.writeText(window.location.href);
                          toast({
                            title: "Link copied!",
                            description: "Share these insights with others",
                          });
                        }}
                      >
                        <Share2 className="h-4 w-4 mr-2" />
                        Share These Insights
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Helper components
import { TrendingDown } from "lucide-react";

// Helper function to calculate total rewards
function calculateTotalRewards(data: any): string {
  if (!data?.stats?.sites) return "thousands of";
  
  const total = data.stats.sites.reduce((sum: number, site: SiteStat) => sum + site.count, 0);
  return total.toLocaleString();
}