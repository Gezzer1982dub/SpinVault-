import { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow, isPast, format } from 'date-fns';
import { useAuth } from '@/hooks/use-auth';
import { Gift, Clock, Check, ExternalLink, ArrowLeft } from 'lucide-react';

type SharedReward = {
  id: number;
  site: string;
  reward: string;
  expiresAt: Date;
  category?: string;
  claimed?: boolean;
};

export default function SharedRewardPage() {
  const [, setLocation] = useLocation();
  const { id } = useParams<{ id: string }>();
  const [loading, setLoading] = useState(true);
  const [reward, setReward] = useState<SharedReward | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    const fetchSharedReward = async () => {
      setLoading(true);
      
      try {
        const res = await apiRequest('GET', `/api/share/reward/${id}`);
        const data = await res.json();
        
        if (data.success && data.reward) {
          // Format dates from string to Date objects
          const formattedReward = {
            ...data.reward,
            expiresAt: new Date(data.reward.expiresAt)
          };
          setReward(formattedReward);
        } else {
          setError(data.error || 'Failed to load reward');
          toast({
            title: 'Error',
            description: data.error || 'Failed to load reward',
            variant: 'destructive',
          });
        }
      } catch (err) {
        console.error('Error fetching shared reward:', err);
        setError('Could not load the shared reward');
        toast({
          title: 'Error',
          description: 'Could not load the shared reward',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (id) {
      fetchSharedReward();
    }
  }, [id, toast]);

  // Check if the reward is expired
  const isExpired = reward ? isPast(new Date(reward.expiresAt)) : false;

  const handleBackClick = () => {
    if (user) {
      setLocation('/'); // Take authenticated users back to the homepage
    } else {
      setLocation('/auth'); // Take unauthenticated users to the auth page
    }
  };

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <Button 
        variant="ghost" 
        className="mb-4" 
        onClick={handleBackClick}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        {user ? 'Back to Dashboard' : 'Sign In'}
      </Button>
      
      {loading ? (
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-6 w-1/3" />
              <Skeleton className="h-6 w-1/4" />
            </div>
          </CardContent>
          <CardFooter>
            <Skeleton className="h-10 w-full" />
          </CardFooter>
        </Card>
      ) : error ? (
        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="text-destructive">Error</CardTitle>
            <CardDescription>
              There was an error loading this reward
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-destructive">{error}</p>
          </CardContent>
          <CardFooter>
            <Button variant="outline" onClick={handleBackClick}>
              Go Back
            </Button>
          </CardFooter>
        </Card>
      ) : reward ? (
        <Card className="overflow-hidden">
          <div 
            className="h-2 w-full"
            style={{ 
              background: isExpired ? 
                'rgba(239, 68, 68, 1)' : // Red if expired 
                'rgba(34, 197, 94, 1)' // Green if still active
            }}
          />
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl flex items-center">
                <Gift className="mr-2 h-5 w-5" />
                Shared Reward
              </CardTitle>
              <Badge 
                variant={isExpired ? "destructive" : "default"}
                className="ml-2"
              >
                {isExpired ? 'Expired' : 'Active'}
              </Badge>
            </div>
            <CardDescription>
              From {reward.site}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="p-6 bg-muted/50 rounded-md mb-6">
              <p className="text-2xl font-bold text-center">{reward.reward}</p>
            </div>
            
            <div className="grid gap-4">
              <div className="flex items-center">
                <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">
                    {isExpired ? (
                      <span className="text-destructive">Expired {formatDistanceToNow(reward.expiresAt, { addSuffix: true })}</span>
                    ) : (
                      <span>Expires {formatDistanceToNow(reward.expiresAt, { addSuffix: true })}</span>
                    )}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {format(reward.expiresAt, 'PPP')}
                  </p>
                </div>
              </div>
              
              {reward.category && (
                <div className="flex items-center">
                  <Badge variant="outline" className="mr-2">
                    {reward.category}
                  </Badge>
                </div>
              )}
              
              {reward.claimed && (
                <div className="flex items-center text-muted-foreground">
                  <Check className="mr-2 h-4 w-4" />
                  <span className="text-sm">This reward has been claimed</span>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row gap-4">
            <Button 
              className="w-full sm:w-auto"
              disabled={isExpired} 
              onClick={() => window.open(`https://${reward.site}`, '_blank')}
            >
              <ExternalLink className="mr-2 h-4 w-4" />
              Visit {reward.site}
            </Button>
            
            {!user && (
              <Button 
                variant="outline" 
                className="w-full sm:w-auto"
                onClick={() => setLocation('/auth')}
              >
                Sign up to track rewards
              </Button>
            )}
          </CardFooter>
        </Card>
      ) : null}
      
      <div className="mt-8 text-center">
        <h3 className="text-xl font-semibold mb-2">SpinVault</h3>
        <p className="text-muted-foreground">
          Never miss out on your gambling rewards again. SpinVault helps you track and manage all your free spins, bonuses, and more in one place.
        </p>
        {!user && (
          <Button 
            className="mt-4"
            onClick={() => setLocation('/auth')}
          >
            Sign Up Now
          </Button>
        )}
      </div>
    </div>
  );
}