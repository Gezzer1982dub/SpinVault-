import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Loader2, CalendarDays, PieChart, BarChart3, LineChart as LineChartIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { getQueryFn } from "@/lib/queryClient";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer, 
  PieChart as RechartsPieChart, 
  Pie, 
  Cell,
  BarChart,
  Bar
} from "recharts";
import { format } from "date-fns";

// Color palette
const COLORS = ['#FF6B6B', '#4ECDC4', '#FFD166', '#06D6A0', '#118AB2', '#073B4C', '#847AF6'];

type DailyReward = {
  day: string;
  count: number;
  rewards: Array<{
    id: number;
    site: string;
    reward: string;
    category: string;
    claimed: boolean;
  }>;
};

type CategorySummary = {
  category: string;
  count: number;
  claimed_count: number;
  latest: string;
};

type SiteSummary = {
  site: string;
  count: number;
  latest_reward: string;
};

type ExpiryInfo = {
  expired: number;
  expiring_soon: number;
  active: number;
};

type ValueMetrics = {
  total_value: number;
  avg_value: number;
  value_per_day: number;
};

type RewardSummary = {
  daily: DailyReward[];
  categories: CategorySummary[];
  sites: SiteSummary[];
  expiry: ExpiryInfo;
  value: ValueMetrics;
};

export default function UserRewardsSummary() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("daily");
  
  // Get user's daily reward summary
  const { 
    data: summaryData, 
    isLoading: isLoadingSummary,
    error
  } = useQuery<{ success: boolean, summary: RewardSummary }>({
    queryKey: ["/api/stats/rewards/daily-summary"],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!user,
    staleTime: 60 * 1000, // 1 minute
  });
  
  if (error) {
    console.error("Error loading daily summary:", error);
  }

  // Format daily data for chart
  const formattedDailyData = summaryData?.summary?.daily?.map(item => {
    const date = new Date(item.day);
    return {
      day: format(date, 'MMM dd'),
      count: item.count
    };
  }) || [];
  
  // Prepare category data for pie chart
  const categoryPieData = summaryData?.summary?.categories?.map(cat => ({
    name: cat.category,
    value: cat.count
  })) || [];
  
  // Prepare claimed vs unclaimed for bar chart
  const claimedData = summaryData?.summary?.categories?.map(cat => ({
    name: cat.category,
    claimed: cat.claimed_count,
    unclaimed: cat.count - cat.claimed_count
  })) || [];
  
  return (
    <div className="container py-10 max-w-7xl mx-auto">
      <div className="flex flex-col space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">
            Your Rewards Summary
          </h1>
          <p className="text-muted-foreground">
            Track your daily accumulated rewards and see your progress over time.
          </p>
        </div>
        
        {!user ? (
          <Card>
            <CardContent className="flex items-center justify-center h-40">
              <p className="text-muted-foreground">Please log in to view your rewards summary</p>
            </CardContent>
          </Card>
        ) : isLoadingSummary ? (
          <div className="flex justify-center items-center h-96">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : !summaryData?.success ? (
          <div className="text-center py-10">
            <p className="text-muted-foreground">Failed to load rewards summary data.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => window.location.reload()}
            >
              Try Again
            </Button>
          </div>
        ) : summaryData.summary.daily.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center h-40 text-center">
              <p className="text-lg text-muted-foreground mb-4">No rewards found yet</p>
              <p className="text-sm text-muted-foreground">
                Start collecting rewards by browsing betting sites or using the Chrome extension
              </p>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Value Metrics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card className="bg-gradient-to-br from-indigo-50 to-indigo-100 dark:from-indigo-950 dark:to-indigo-900">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Rewards Value</p>
                      <h3 className="text-3xl font-bold mt-1">£{summaryData.summary.value?.total_value?.toFixed(2) || "0.00"}</h3>
                    </div>
                    <div className="h-12 w-12 bg-indigo-100 dark:bg-indigo-800 rounded-full flex items-center justify-center">
                      <PieChart className="h-6 w-6 text-indigo-600 dark:text-indigo-300" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-950 dark:to-amber-900">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Daily Average</p>
                      <h3 className="text-3xl font-bold mt-1">£{summaryData.summary.value?.value_per_day?.toFixed(2) || "0.00"}</h3>
                    </div>
                    <div className="h-12 w-12 bg-amber-100 dark:bg-amber-800 rounded-full flex items-center justify-center">
                      <CalendarDays className="h-6 w-6 text-amber-600 dark:text-amber-300" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950 dark:to-emerald-900">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Active Rewards</p>
                      <h3 className="text-3xl font-bold mt-1">{summaryData.summary.expiry?.active || 0}</h3>
                    </div>
                    <div className="h-12 w-12 bg-emerald-100 dark:bg-emerald-800 rounded-full flex items-center justify-center">
                      <BarChart3 className="h-6 w-6 text-emerald-600 dark:text-emerald-300" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="daily">
                  <CalendarDays className="h-4 w-4 mr-2" />
                  Daily Activity
                </TabsTrigger>
                <TabsTrigger value="categories">
                  <PieChart className="h-4 w-4 mr-2" />
                  Categories
                </TabsTrigger>
                <TabsTrigger value="sites">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Sites
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="daily" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Daily Rewards Activity</CardTitle>
                    <CardDescription>
                      Your rewards found over the past 30 days
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={formattedDailyData}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="day" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line 
                            type="monotone" 
                            dataKey="count" 
                            name="Rewards Found"
                            stroke="#8884d8" 
                            activeDot={{ r: 8 }} 
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Recent daily activity list */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription>
                      Your latest reward discoveries
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {summaryData.summary.daily.slice(0, 5).map((day) => (
                        <div key={day.day} className="border-b pb-3">
                          <h4 className="font-medium mb-2">
                            {format(new Date(day.day), 'EEEE, MMMM d')}
                            <span className="ml-2 text-sm text-muted-foreground">
                              ({day.count} rewards)
                            </span>
                          </h4>
                          <div className="space-y-2">
                            {day.rewards.slice(0, 3).map(reward => (
                              <div key={reward.id} className="flex justify-between items-center text-sm">
                                <div className="flex items-center">
                                  <div className={`w-2 h-2 rounded-full mr-2 ${reward.claimed ? 'bg-green-500' : 'bg-blue-500'}`}></div>
                                  <span className="font-medium">{reward.site}</span>
                                  <span className="mx-2">-</span>
                                  <span className="text-muted-foreground">{reward.reward}</span>
                                </div>
                                <div>
                                  <span className={`px-2 py-1 rounded-full text-xs ${getCategoryColor(reward.category)}`}>
                                    {reward.category}
                                  </span>
                                </div>
                              </div>
                            ))}
                            {day.rewards.length > 3 && (
                              <p className="text-sm text-muted-foreground italic">
                                + {day.rewards.length - 3} more rewards...
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="categories" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Categories Pie Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Reward Categories</CardTitle>
                      <CardDescription>
                        Distribution of your reward types
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <RechartsPieChart>
                            <Pie
                              data={categoryPieData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              nameKey="name"
                              label={({ name, percent }) => 
                                `${name}: ${(percent * 100).toFixed(0)}%`
                              }
                            >
                              {categoryPieData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </RechartsPieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Claimed vs Unclaimed Bar Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Claimed vs Unclaimed</CardTitle>
                      <CardDescription>
                        How many rewards you've claimed by category
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={claimedData}
                            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="claimed" stackId="a" fill="#4ECDC4" name="Claimed" />
                            <Bar dataKey="unclaimed" stackId="a" fill="#FF6B6B" name="Unclaimed" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Expiry Information */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Reward Status Summary</CardTitle>
                    <CardDescription>
                      Current status of all your rewards
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-muted rounded-lg p-4 text-center">
                        <h3 className="text-5xl font-bold text-primary">
                          {summaryData.summary.expiry?.active || 0}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                          Active Rewards
                        </p>
                      </div>
                      <div className="bg-muted rounded-lg p-4 text-center">
                        <h3 className="text-5xl font-bold text-amber-500">
                          {summaryData.summary.expiry?.expiring_soon || 0}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                          Expiring Soon (7 days)
                        </p>
                      </div>
                      <div className="bg-muted rounded-lg p-4 text-center">
                        <h3 className="text-5xl font-bold text-destructive">
                          {summaryData.summary.expiry?.expired || 0}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                          Expired
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="sites" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Top Gambling Sites</CardTitle>
                    <CardDescription>
                      Sites where you've found the most rewards
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        {summaryData.summary.sites?.slice(0, 5).map((site, index) => (
                          <div key={site.site} className="flex items-center space-x-2">
                            <div className="font-bold text-lg text-muted-foreground w-8">
                              #{index + 1}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <h4 className="font-medium">{site.site}</h4>
                                <span className="font-bold">{site.count}</span>
                              </div>
                              <div className="w-full bg-muted rounded-full h-2 mt-1">
                                <div 
                                  className="bg-primary rounded-full h-2" 
                                  style={{ 
                                    width: `${Math.min(100, (site.count / (summaryData.summary.sites[0]?.count || 1)) * 100)}%` 
                                  }}
                                ></div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      <div className="space-y-4">
                        {summaryData.summary.sites?.slice(5, 10).map((site, index) => (
                          <div key={site.site} className="flex items-center space-x-2">
                            <div className="font-bold text-lg text-muted-foreground w-8">
                              #{index + 6}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <h4 className="font-medium">{site.site}</h4>
                                <span className="font-bold">{site.count}</span>
                              </div>
                              <div className="w-full bg-muted rounded-full h-2 mt-1">
                                <div 
                                  className="bg-primary rounded-full h-2" 
                                  style={{ 
                                    width: `${Math.min(100, (site.count / (summaryData.summary.sites[0]?.count || 1)) * 100)}%` 
                                  }}
                                ></div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Latest Rewards by Site */}
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Latest Reward By Site</CardTitle>
                    <CardDescription>
                      When you last found a reward from each site
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {summaryData.summary.sites?.slice(0, 8).map((site) => (
                        <div key={site.site} className="flex justify-between items-center border-b pb-2">
                          <span className="font-medium">{site.site}</span>
                          <span className="text-sm text-muted-foreground">
                            {format(new Date(site.latest_reward), 'MMM d, yyyy')}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </div>
  );
}

// Helper function to get category colors for badges
function getCategoryColor(category: string): string {
  switch (category) {
    case 'FREE_SPINS':
      return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
    case 'BONUS_CASH':
      return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
    case 'DEPOSIT_MATCH':
      return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
    case 'FREE_BET':
      return 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300';
    case 'BINGO_TICKETS':
      return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300';
    case 'LOYALTY_POINTS':
      return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-300';
    case 'CUSTOM':
      return 'bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-300';
    default:
      return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
  }
}