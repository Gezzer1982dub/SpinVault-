import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Reward } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useNotifications } from "@/hooks/use-notifications";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { RewardCard } from "@/components/rewards/RewardCard";
import { RewardProgressCard } from "@/components/rewards/RewardProgressCard";
import { AddRewardForm } from "@/components/rewards/AddRewardForm";
import { CustomCategoriesManager } from "@/components/categories/CustomCategoriesManager";
import { NotificationPermission } from "@/components/notifications/NotificationPermission";
import { NotificationBell } from "@/components/notifications/notification-bell";
import { ToastNotification } from "@/components/ui/toast-notification";
import { Spinner } from "@/components/ui/spinner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { LogOut, Search, Loader2, BarChart3, PieChart, Compass, ListTodo, BarChart, Trash2, CheckSquare, Square } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { ThemeToggle } from "@/components/ui/theme-toggle";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [toast, setToast] = useState<{ visible: boolean; message: string; variant: "success" | "error" | "info" }>({ 
    visible: false, 
    message: "", 
    variant: "success" 
  });
  
  // Toggle between basic and progress view
  const [viewMode, setViewMode] = useState<'basic' | 'progress'>('progress');
  
  // State for bulk selection
  const [selectedRewards, setSelectedRewards] = useState<number[]>([]);
  const [selectMode, setSelectMode] = useState(false);
  
  // Fetch rewards data
  const { 
    data: rewards = [], 
    isLoading, 
    error 
  } = useQuery<Reward[]>({
    queryKey: ["/api/rewards"],
  });

  // Detect reward mutation
  const detectRewardMutation = useMutation({
    mutationFn: async () => {
      try {
        // Only works if you've visited a gambling site in the current browser session
        const targetSites = [
          'bet365.com', 'williamhill.com', 'paddypower.com', 'skybet.com',
          'coral.co.uk', 'ladbrokes.com', 'betfred.com'
        ];
        
        // Check if any gambling site cookies/localStorage exist from current session
        const hasVisitedGamblingSite = targetSites.some(site => {
          // Check if localStorage has any keys from these sites
          // This is a simple check, the more robust version would need to access browser history API
          return document.cookie.includes(site) || 
                 [...Array(localStorage.length)].some((_, i) => 
                   localStorage.key(i)?.includes(site));
        });
        
        // Get all open tabs via localStorage synchronization
        // (direct tab access not allowed for security reasons)
        localStorage.setItem('spinvault_ping', Date.now().toString());
        
        // Extract just the important parts of the page for detection
        // This function extracts only the main content, reducing payload size
        const extractImportantContent = () => {
          // Select important elements that might contain offers
          const mainContent = document.querySelector('main')?.innerText || '';
          const offerSections = [...document.querySelectorAll('.offer, .promotion, .bonus, .reward, .free-bet, .free-spin')].map(el => el.innerText).join(' ');
          
          // Get visible text from the body as a fallback
          const visibleText = document.body.innerText.slice(0, 100000); // Limit to 100k chars
          
          return offerSections || mainContent || visibleText;
        };
        
        const content = extractImportantContent();
        const url = window.location.href;
        
        // Send the content and URL to the detection API
        const res = await apiRequest("POST", "/api/detect-reward", { content, url });
        return res.json();
      } catch (err) {
        console.error("Error in detectRewardMutation:", err);
        throw new Error("Failed to detect rewards. Please make sure you've visited a gambling website in this browser session.");
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/rewards"] });
      if (data.success && data.rewards.length > 0) {
        showToast(`Detected ${data.rewards.length} new reward(s)!`, "success");
      } else {
        showToast("No new rewards detected. Make sure you've visited and logged into a gambling site first.", "info");
      }
    },
    onError: (error) => {
      showToast(`Error: ${error.message}`, "error");
    },
  });

  // Bulk delete mutation
  const bulkDeleteMutation = useMutation({
    mutationFn: async (ids: number[]) => {
      const res = await apiRequest("POST", "/api/rewards/delete-multiple", { ids });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/rewards"] });
      showToast(`Successfully deleted ${data.deletedCount} rewards!`, "success");
      setSelectedRewards([]);
      setSelectMode(false);
    },
    onError: (error) => {
      showToast(`Error: ${error.message}`, "error");
    },
  });

  // Toggle select mode
  const toggleSelectMode = () => {
    setSelectMode(!selectMode);
    setSelectedRewards([]);
  };

  // Toggle selection of a reward
  const toggleRewardSelection = (id: number) => {
    if (selectedRewards.includes(id)) {
      setSelectedRewards(selectedRewards.filter(rewardId => rewardId !== id));
    } else {
      setSelectedRewards([...selectedRewards, id]);
    }
  };

  // Select or deselect all rewards
  const toggleSelectAll = () => {
    if (selectedRewards.length === rewards.length) {
      setSelectedRewards([]);
    } else {
      setSelectedRewards(rewards.map(reward => reward.id));
    }
  };

  // Delete selected rewards
  const deleteSelectedRewards = () => {
    if (selectedRewards.length === 0) {
      showToast("No rewards selected for deletion", "info");
      return;
    }
    
    bulkDeleteMutation.mutate(selectedRewards);
  };

  const showToast = (message: string, variant: "success" | "error" | "info" = "success") => {
    setToast({ visible: true, message, variant });
  };

  const closeToast = () => {
    setToast({ ...toast, visible: false });
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (error) {
    return (
      <div className="container max-w-lg mx-auto py-6 px-4">
        <Card className="bg-red-50 border-red-200">
          <CardContent className="p-6 text-center">
            <h3 className="text-lg font-semibold text-red-700">Error Loading Rewards</h3>
            <p className="text-red-600">{(error as Error).message}</p>
            <Button 
              onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/rewards"] })}
              variant="outline"
              className="mt-4"
            >
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container max-w-lg mx-auto py-6 px-4 animate-in fade-in-50">
      <Card className="mb-6">
        <CardContent className="p-6">
          {/* Header with Username & Theme Toggle */}
          <div className="mb-6">
            {/* Title - Center Aligned on Mobile */}
            <div className="text-center mb-3 sm:mb-0 sm:text-left">
              <h1 className="text-2xl font-bold">{user?.username}'s Dashboard</h1>
              <p className="text-muted-foreground text-sm">
                Track, manage and claim your rewards
              </p>
            </div>
            
            {/* Buttons - Center Aligned on Mobile */}
            <div className="flex justify-center sm:justify-end gap-2 mt-3">
              <NotificationPermission />
              <NotificationBell />
              <ThemeToggle />
              <Link href="/premium">
                <Button
                  variant="default"
                  size="sm"
                  className="h-9 bg-gradient-to-r from-[hsl(var(--premium-gradient-start))] to-[hsl(var(--premium-gradient-end))]"
                >
                  <span className="mr-1">⭐</span> 
                  Upgrade
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Navigation Links & Logout */}
          <div className="flex flex-col mb-4 gap-3">
            {/* Navigation Buttons - Grid Layout for better mobile spacing */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <Link href="/discover" className="flex">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 w-full text-xs sm:text-sm"
                >
                  <Compass className="h-4 w-4 mr-1" />
                  Discover
                </Button>
              </Link>
              <Link href="/social" className="flex">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 w-full text-xs sm:text-sm"
                >
                  <BarChart3 className="h-4 w-4 mr-1" />
                  Social Insights
                </Button>
              </Link>
              <Link href="/stats" className="flex">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 w-full text-xs sm:text-sm"
                >
                  <PieChart className="h-4 w-4 mr-1" />
                  My Stats
                </Button>
              </Link>
              <div className="col-span-2 sm:hidden"></div>
            </div>
            
            {/* Logout Button - Full Width on Mobile, Right-Aligned on Desktop */}
            <div className="flex sm:justify-end mt-1">
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
                className="h-9 w-full sm:w-auto"
              >
                {logoutMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <LogOut className="h-4 w-4 mr-1" />
                )}
                Logout
              </Button>
            </div>
          </div>

          {/* Main Content */}
          <Tabs defaultValue="rewards" className="mb-6">
            <TabsList className="grid w-full grid-cols-2 rounded-md overflow-hidden">
              <TabsTrigger value="rewards" className="text-sm sm:text-base py-2 font-medium">
                <ListTodo className="h-4 w-4 mr-2 hidden sm:inline-block" />
                My Rewards
              </TabsTrigger>
              <TabsTrigger value="categories" className="text-sm sm:text-base py-2 font-medium">
                <BarChart className="h-4 w-4 mr-2 hidden sm:inline-block" />
                Custom Categories
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="rewards" className="mt-4">
              {detectRewardMutation.isPending && (
                <div className="my-8">
                  <Spinner />
                </div>
              )}

              {/* Info about when to use Detect New Reward */}
              <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-md text-sm text-yellow-800">
                <p className="flex items-start">
                  <span className="mr-2 mt-0.5">ℹ️</span>
                  <span>
                    To detect rewards, visit a gambling website (like Bet365, William Hill, etc.) 
                    in another tab, log in to see your personalized offers, then come back here and click the "Detect New Reward" button.
                  </span>
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <a 
                    href="https://www.bet365.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-xs bg-white px-2 py-1 rounded border border-yellow-200 text-yellow-700 hover:bg-yellow-100 transition-colors"
                  >
                    Bet365
                  </a>
                  <a 
                    href="https://www.williamhill.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-xs bg-white px-2 py-1 rounded border border-yellow-200 text-yellow-700 hover:bg-yellow-100 transition-colors"
                  >
                    William Hill
                  </a>
                  <a 
                    href="https://www.skybet.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-xs bg-white px-2 py-1 rounded border border-yellow-200 text-yellow-700 hover:bg-yellow-100 transition-colors"
                  >
                    Sky Bet
                  </a>
                  <a 
                    href="https://www.paddypower.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-xs bg-white px-2 py-1 rounded border border-yellow-200 text-yellow-700 hover:bg-yellow-100 transition-colors"
                  >
                    Paddy Power
                  </a>
                </div>
              </div>
              
              <Button
                onClick={() => detectRewardMutation.mutate()}
                disabled={detectRewardMutation.isPending}
                className="w-full"
              >
                <Search className="mr-2 h-5 w-5" />
                Detect New Reward
              </Button>
              
              {/* View Mode Toggle */}
              <div className="mt-4 flex justify-center">
                <ToggleGroup 
                  type="single" 
                  value={viewMode}
                  onValueChange={(value) => {
                    if (value) setViewMode(value as 'basic' | 'progress');
                  }}
                  className="justify-center"
                >
                  <ToggleGroupItem value="basic" aria-label="Basic view">
                    <ListTodo className="h-4 w-4 mr-2" />
                    Basic
                  </ToggleGroupItem>
                  <ToggleGroupItem value="progress" aria-label="Progress tracking view">
                    <BarChart className="h-4 w-4 mr-2" />
                    Progress Tracking
                  </ToggleGroupItem>
                </ToggleGroup>
              </div>

              {/* Selection Controls */}
              {rewards.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2 justify-between items-center">
                  <Button
                    variant={selectMode ? "default" : "outline"}
                    size="sm"
                    onClick={toggleSelectMode}
                    className="flex items-center gap-1"
                  >
                    {selectMode ? <CheckSquare className="h-4 w-4" /> : <Square className="h-4 w-4" />}
                    {selectMode ? "Cancel Selection" : "Select Rewards"}
                  </Button>
                  
                  {selectMode && (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={toggleSelectAll}
                        className="flex items-center gap-1"
                      >
                        {selectedRewards.length === rewards.length ? "Deselect All" : "Select All"}
                      </Button>
                      
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={deleteSelectedRewards}
                        disabled={selectedRewards.length === 0 || bulkDeleteMutation.isPending}
                        className="flex items-center gap-1"
                      >
                        {bulkDeleteMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Trash2 className="h-4 w-4" />
                        )}
                        Delete Selected ({selectedRewards.length})
                      </Button>
                    </div>
                  )}
                </div>
              )}

              {isLoading ? (
                <div className="mt-8 flex justify-center">
                  <Spinner />
                </div>
              ) : rewards.length === 0 ? (
                <div className="mt-8 text-center p-8 border border-dashed rounded-lg bg-muted/20">
                  <p className="text-muted-foreground">
                    No rewards found. Click "Detect New Reward" to find some!
                  </p>
                </div>
              ) : (
                <div className="mt-6 space-y-4">
                  {rewards.map((reward) => (
                    <div key={reward.id} className="relative">
                      {selectMode && (
                        <div className="absolute left-2 top-1/2 transform -translate-y-1/2 z-10">
                          <Checkbox 
                            checked={selectedRewards.includes(reward.id)}
                            onCheckedChange={() => toggleRewardSelection(reward.id)}
                          />
                        </div>
                      )}
                      <div className={selectMode ? "pl-8" : ""}>
                        {viewMode === 'basic' ? (
                          <RewardCard key={reward.id} reward={reward} />
                        ) : (
                          <RewardProgressCard 
                            key={reward.id} 
                            reward={reward}
                            onUpdate={() => queryClient.invalidateQueries({ queryKey: ["/api/rewards"] })}
                          />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              <div className="mt-6">
                <AddRewardForm />
              </div>
            </TabsContent>
            
            <TabsContent value="categories" className="mt-4">
              <CustomCategoriesManager />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <ToastNotification
        visible={toast.visible}
        onClose={closeToast}
        variant={toast.variant}
      >
        {toast.message}
      </ToastNotification>
    </div>
  );
}