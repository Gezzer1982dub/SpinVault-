import { useState } from "react";
import { Redirect } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { SpinVaultLogo } from "@/lib/svg/SpinVaultLogo";
import { Loader2 } from "lucide-react";

type TabType = "login" | "signup";

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<TabType>("login");
  const [loginForm, setLoginForm] = useState({ username: "", password: "" });
  const [signupForm, setSignupForm] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [passwordError, setPasswordError] = useState("");
  const [emailError, setEmailError] = useState("");
  
  const { 
    user, 
    isLoading, 
    loginMutation, 
    registerMutation, 
    demoLoginMutation 
  } = useAuth();

  // Redirect if already logged in
  if (user) {
    return <Redirect to="/" />;
  }

  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
    setPasswordError("");
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate(loginForm);
  };

  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Clear previous errors
    setPasswordError("");
    setEmailError("");
    
    if (signupForm.password !== signupForm.confirmPassword) {
      setPasswordError("Passwords do not match");
      return;
    }
    
    // Basic email validation
    if (signupForm.email && !signupForm.email.includes('@')) {
      setEmailError("Please enter a valid email address");
      return;
    }
    
    registerMutation.mutate({
      username: signupForm.username,
      password: signupForm.password,
      email: signupForm.email // Include email in registration
    });
  };

  const handleDemoLogin = () => {
    demoLoginMutation.mutate();
  };

  const isSubmitting = loginMutation.isPending || registerMutation.isPending || demoLoginMutation.isPending;

  return (
    <div className="container max-w-lg mx-auto pt-12 px-4 animate-in fade-in-50">
      <Card className="overflow-hidden">
        <div className="flex">
          <Button
            onClick={() => handleTabChange("login")}
            className={`py-4 w-1/2 rounded-none text-center font-medium ${
              activeTab === "login"
                ? "border-b-2 border-primary text-primary"
                : "border-b-2 border-transparent text-muted-foreground hover:text-foreground"
            }`}
            variant="ghost"
          >
            Login
          </Button>
          <Button
            onClick={() => handleTabChange("signup")}
            className={`py-4 w-1/2 rounded-none text-center font-medium ${
              activeTab === "signup"
                ? "border-b-2 border-primary text-primary"
                : "border-b-2 border-transparent text-muted-foreground hover:text-foreground"
            }`}
            variant="ghost"
          >
            Sign Up
          </Button>
        </div>

        <CardContent className="p-6">
          <div className="flex justify-center mb-8">
            <div className="w-20 h-20 bg-primary/10 rounded-lg shadow-md flex items-center justify-center">
              <SpinVaultLogo className="w-12 h-12 text-primary" />
            </div>
            <div className="ml-4 flex flex-col justify-center">
              <h1 className="text-2xl font-bold">SpinVault</h1>
              <p className="text-muted-foreground text-sm">
                Track your betting rewards
              </p>
            </div>
          </div>

          {/* Login Form */}
          {activeTab === "login" && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <Label htmlFor="username" className="text-sm font-medium mb-1">
                  Username
                </Label>
                <Input
                  type="text"
                  id="username"
                  name="username"
                  value={loginForm.username}
                  onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                  className="w-full px-4 py-2"
                  placeholder="Enter your username"
                  disabled={isSubmitting}
                  required
                />
              </div>
              <div>
                <Label htmlFor="password" className="text-sm font-medium mb-1">
                  Password
                </Label>
                <Input
                  type="password"
                  id="password"
                  name="password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                  className="w-full px-4 py-2"
                  placeholder="Enter your password"
                  disabled={isSubmitting}
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full" 
                disabled={isSubmitting || isLoading}
              >
                {loginMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : null}
                Login
              </Button>
            </form>
          )}

          {/* Signup Form */}
          {activeTab === "signup" && (
            <form onSubmit={handleSignupSubmit} className="space-y-4">
              <div>
                <Label htmlFor="new-username" className="text-sm font-medium mb-1">
                  Username
                </Label>
                <Input
                  type="text"
                  id="new-username"
                  name="username"
                  value={signupForm.username}
                  onChange={(e) => setSignupForm({ ...signupForm, username: e.target.value })}
                  className="w-full px-4 py-2"
                  placeholder="Choose a username"
                  disabled={isSubmitting}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email" className="text-sm font-medium mb-1">
                  Email Address
                </Label>
                <Input
                  type="email"
                  id="email"
                  name="email"
                  value={signupForm.email}
                  onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
                  className="w-full px-4 py-2"
                  placeholder="your.email@example.com"
                  disabled={isSubmitting}
                />
                {emailError && (
                  <p className="text-sm text-destructive mt-1">{emailError}</p>
                )}
                <p className="text-xs text-muted-foreground mt-1">
                  Used for email notifications and account recovery
                </p>
              </div>
              <div>
                <Label htmlFor="new-password" className="text-sm font-medium mb-1">
                  Password
                </Label>
                <Input
                  type="password"
                  id="new-password"
                  name="password"
                  value={signupForm.password}
                  onChange={(e) => setSignupForm({ ...signupForm, password: e.target.value })}
                  className="w-full px-4 py-2"
                  placeholder="Create a password"
                  disabled={isSubmitting}
                  required
                />
              </div>
              <div>
                <Label htmlFor="confirm-password" className="text-sm font-medium mb-1">
                  Confirm Password
                </Label>
                <Input
                  type="password"
                  id="confirm-password"
                  name="confirm-password"
                  value={signupForm.confirmPassword}
                  onChange={(e) => setSignupForm({ ...signupForm, confirmPassword: e.target.value })}
                  className="w-full px-4 py-2"
                  placeholder="Confirm your password"
                  disabled={isSubmitting}
                  required
                />
                {passwordError && (
                  <p className="text-sm text-destructive mt-1">{passwordError}</p>
                )}
              </div>
              <Button 
                type="submit" 
                className="w-full"
                disabled={isSubmitting || isLoading}
              >
                {registerMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : null}
                Create Account
              </Button>
            </form>
          )}

          {/* Demo Button */}
          <div className="mt-6 text-center">
            <Button
              onClick={handleDemoLogin}
              variant="outline"
              disabled={isSubmitting || isLoading}
              className="inline-flex items-center justify-center"
            >
              {demoLoginMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Try Demo
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
