import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Reward } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, BarChart, PieChart, AreaChart, Calendar, BarChart2, PieChartIcon } from "lucide-react";
import { 
  BarChart as RechartBarChart,
  Bar,
  PieChart as RechartPieChart,
  Pie,
  Cell,
  AreaChart as RechartAreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

// Date formatting helper
function formatDate(date: Date): string {
  return new Date(date).toLocaleDateString('en-GB', { 
    day: 'numeric', 
    month: 'short'
  });
}

export default function RewardStatsPage() {
  const { user } = useAuth();
  const [timeframe, setTimeframe] = useState("30days");
  
  // Fetch all rewards for the current user
  const { data: rewards, isLoading } = useQuery<Reward[]>({
    queryKey: ["/api/rewards"],
    enabled: !!user,
  });

  // Fetch aggregated stats from the API
  const { data: aggregatedStats, isLoading: isLoadingStats, refetch: refetchStats } = useQuery({
    queryKey: [`/api/stats/rewards?timeframe=${timeframe}`],
    enabled: !!user
  });
  
  // Refetch stats when timeframe changes
  useEffect(() => {
    if (user) {
      refetchStats();
    }
  }, [timeframe, refetchStats, user]);

  if (isLoading || !rewards) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reward Statistics</h1>
          <p className="text-muted-foreground mt-1">
            Visual insights to help you maximize your reward value
          </p>
        </div>

        <div className="mt-4 md:mt-0">
          <Select 
            value={timeframe} 
            onValueChange={setTimeframe}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
              <SelectItem value="all">All time</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview" className="flex items-center">
            <BarChart2 className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center">
            <PieChartIcon className="h-4 w-4 mr-2" />
            Categories
          </TabsTrigger>
          <TabsTrigger value="timeline" className="flex items-center">
            <AreaChart className="h-4 w-4 mr-2" />
            Timeline
          </TabsTrigger>
          <TabsTrigger value="calendar" className="flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            Calendar
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Total Rewards Value Card */}
            <StatsOverviewCard 
              rewards={rewards} 
              isLoading={isLoadingStats}
              stats={aggregatedStats}
            />
            
            {/* Sites Distribution Chart */}
            <SitesDistributionCard rewards={rewards} />

            {/* Category Distribution Chart */}
            <CategoryDistributionCard rewards={rewards} />
          </div>

          {/* Value Over Time Chart */}
          <ValueOverTimeCard rewards={rewards} timeframe={timeframe} />
        </TabsContent>

        <TabsContent value="categories" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <CategoryDistributionCard rewards={rewards} fullSize />
            <CategoryValueCard rewards={rewards} />
          </div>
        </TabsContent>

        <TabsContent value="timeline" className="space-y-6">
          <div className="grid grid-cols-1 gap-6">
            <ValueOverTimeCard rewards={rewards} timeframe={timeframe} fullSize />
            <RewardFrequencyCard rewards={rewards} timeframe={timeframe} />
          </div>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-6">
          <div className="grid grid-cols-1 gap-6">
            <p className="text-muted-foreground text-center py-8">
              Calendar view coming soon!
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Stats Overview Card Component
function StatsOverviewCard({ rewards, isLoading, stats }: { 
  rewards: Reward[], 
  isLoading: boolean,
  stats: any
}) {
  // If we have aggregated stats from the API, use those
  // Otherwise, calculate from the rewards we have
  let totalRewards = rewards.length;
  let totalEstimatedValue = 0;
  let averageValue = 0;
  
  if (stats && !isLoading && stats.success) {
    totalRewards = stats.totalRewards || totalRewards;
    totalEstimatedValue = stats.totalValue || totalEstimatedValue;
    averageValue = stats.averageValue || averageValue;
  } else {
    // Calculate basic stats from rewards
    totalEstimatedValue = rewards.reduce((sum, reward) => {
      // If we had actual values in the reward objects, we would use them
      // This is just a placeholder calculation based on reward type
      let estimatedValue = 0;
      if (reward.reward.toLowerCase().includes("free bet")) {
        estimatedValue = Math.random() * 30 + 10; // £10-40 for free bets
      } else if (reward.reward.toLowerCase().includes("free spin")) {
        estimatedValue = Math.random() * 15 + 5; // £5-20 for free spins
      } else if (reward.reward.toLowerCase().includes("cashback")) {
        estimatedValue = Math.random() * 50 + 20; // £20-70 for cashback
      } else {
        estimatedValue = Math.random() * 20 + 5; // £5-25 for others
      }
      return sum + estimatedValue;
    }, 0);
    
    averageValue = totalRewards > 0 ? totalEstimatedValue / totalRewards : 0;
  }

  return (
    <Card className="col-span-1">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Rewards Overview</CardTitle>
        <CardDescription>Summary of your reward performance</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">Total Rewards</p>
            <p className="text-3xl font-bold">{totalRewards}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Estimated Total Value</p>
            <p className="text-3xl font-bold">£{totalEstimatedValue.toFixed(2)}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Average Value per Reward</p>
            <p className="text-3xl font-bold">£{averageValue.toFixed(2)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Sites Distribution Card Component
function SitesDistributionCard({ rewards, fullSize = false }: { rewards: Reward[], fullSize?: boolean }) {
  // Group rewards by site
  const siteData = rewards.reduce((acc: Record<string, number>, reward) => {
    acc[reward.site] = (acc[reward.site] || 0) + 1;
    return acc;
  }, {});

  // Convert to chart data format
  const chartData = Object.entries(siteData)
    .map(([site, count]) => ({
      name: site,
      value: count
    }))
    .sort((a, b) => b.value - a.value) // Sort by count descending
    .slice(0, 5); // Get top 5 sites

  // Add "Others" category if needed
  if (Object.keys(siteData).length > 5) {
    const othersCount = Object.values(siteData)
      .reduce((sum, count, index) => {
        if (index >= 5) return sum + count;
        return sum;
      }, 0);
    
    if (othersCount > 0) {
      chartData.push({ name: "Others", value: othersCount });
    }
  }

  // Colors for the pie chart
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#A569BD', '#D3D3D3'];

  return (
    <Card className={fullSize ? "col-span-2" : "col-span-1"}>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Sites Distribution</CardTitle>
        <CardDescription>Breakdown of rewards by gambling site</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="w-full h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <RechartPieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={true}
                label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} rewards`, 'Count']} />
              <Legend />
            </RechartPieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

// Category Distribution Card Component
function CategoryDistributionCard({ rewards, fullSize = false }: { rewards: Reward[], fullSize?: boolean }) {
  // Group rewards by category
  const categoryData = rewards.reduce((acc: Record<string, number>, reward) => {
    const category = reward.category || "Other";
    acc[category] = (acc[category] || 0) + 1;
    return acc;
  }, {});

  // Convert to chart data format
  const chartData = Object.entries(categoryData)
    .map(([category, count]) => ({
      name: category === "null" ? "Other" : category,
      value: count
    }))
    .sort((a, b) => b.value - a.value);

  // Colors for the pie chart
  const COLORS = ['#00C49F', '#0088FE', '#FFBB28', '#FF8042', '#A569BD', '#D3D3D3'];

  return (
    <Card className={fullSize ? "col-span-1 md:col-span-1" : "col-span-1"}>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Category Distribution</CardTitle>
        <CardDescription>Breakdown of rewards by category</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="w-full h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <RechartPieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={true}
                label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`${value} rewards`, 'Count']} />
              <Legend />
            </RechartPieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

// Category Value Card Component
function CategoryValueCard({ rewards }: { rewards: Reward[] }) {
  // Mock data for category values (would be replaced with real data)
  const categoryValues: Record<string, number> = {
    "FREE_BET": 25.50,
    "FREE_SPINS": 15.75,
    "BONUS_CASH": 30.00,
    "DEPOSIT_MATCH": 40.25,
    "BINGO_TICKETS": 10.50,
    "OTHER": 12.25
  };

  // Group rewards by category and count
  const categoryData = rewards.reduce((acc: Record<string, number>, reward) => {
    const category = reward.category || "OTHER";
    acc[category] = (acc[category] || 0) + 1;
    return acc;
  }, {});

  // Calculate average value per category
  const chartData = Object.entries(categoryData)
    .map(([category, count]) => {
      // Get the value from our mock data or use a default
      const totalValue = categoryValues[category] || 15;
      return {
        name: category === "null" ? "Other" : category,
        value: totalValue
      };
    })
    .sort((a, b) => b.value - a.value);

  return (
    <Card className="col-span-1 md:col-span-1">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Average Value by Category</CardTitle>
        <CardDescription>Estimated value by reward type</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="w-full h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <RechartBarChart
              data={chartData}
              layout="vertical"
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" domain={[0, 'dataMax']} />
              <YAxis dataKey="name" type="category" width={100} />
              <Tooltip formatter={(value) => [`£${value}`, 'Average Value']} />
              <Legend />
              <Bar dataKey="value" fill="#8884d8" name="Average Value (£)" />
            </RechartBarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

// Value Over Time Card Component
function ValueOverTimeCard({ rewards, timeframe, fullSize = false }: { 
  rewards: Reward[], 
  timeframe: string,
  fullSize?: boolean
}) {
  // Function to sort and process reward data for the area chart
  const processTimelineData = () => {
    // Mock estimated values based on reward type (would be replaced with actual data)
    const getEstimatedValue = (reward: Reward) => {
      if (reward.reward.toLowerCase().includes("free bet")) {
        return Math.random() * 30 + 10; // £10-40 for free bets
      } else if (reward.reward.toLowerCase().includes("free spin")) {
        return Math.random() * 15 + 5; // £5-20 for free spins
      } else if (reward.reward.toLowerCase().includes("cashback")) {
        return Math.random() * 50 + 20; // £20-70 for cashback
      } else {
        return Math.random() * 20 + 5; // £5-25 for others
      }
    };

    // Determine the number of data points based on timeframe
    let numDataPoints = 7;
    if (timeframe === "30days") numDataPoints = 10;
    if (timeframe === "90days") numDataPoints = 12;
    if (timeframe === "all") numDataPoints = Math.min(15, rewards.length);

    // Group rewards by date
    const dataByDate: Record<string, { value: number, count: number }> = {};
    
    // Sort rewards by date (newest first)
    const sortedRewards = [...rewards].sort((a, b) => 
      new Date(b.expiresAt).getTime() - new Date(a.expiresAt).getTime()
    );

    // Process rewards and group by date
    sortedRewards.forEach(reward => {
      const dateKey = formatDate(reward.expiresAt);
      if (!dataByDate[dateKey]) {
        dataByDate[dateKey] = { value: 0, count: 0 };
      }
      dataByDate[dateKey].value += getEstimatedValue(reward);
      dataByDate[dateKey].count += 1;
    });

    // Convert to chart data format
    const chartData = Object.entries(dataByDate)
      .map(([date, data]) => ({
        date,
        value: data.value,
        count: data.count
      }))
      .slice(0, numDataPoints) // Limit to our desired number of data points
      .reverse(); // Reverse to show oldest first

    return chartData;
  };

  const chartData = processTimelineData();

  return (
    <Card className={fullSize ? "col-span-1" : "col-span-1 md:col-span-3"}>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Reward Value Over Time</CardTitle>
        <CardDescription>Trend of estimated reward values</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="w-full h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <RechartAreaChart
              data={chartData}
              margin={{
                top: 10,
                right: 30,
                left: 0,
                bottom: 0,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip formatter={(value) => [`£${Number(value).toFixed(2)}`, 'Value']} />
              <Legend />
              <Area 
                type="monotone" 
                dataKey="value" 
                stroke="#8884d8" 
                fill="#8884d8" 
                fillOpacity={0.3}
                name="Total Value (£)"
              />
            </RechartAreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

// Reward Frequency Card Component
function RewardFrequencyCard({ rewards, timeframe }: { rewards: Reward[], timeframe: string }) {
  // Function to process reward data for the bar chart
  const processFrequencyData = () => {
    // Determine the number of data points based on timeframe
    let numDataPoints = 7;
    if (timeframe === "30days") numDataPoints = 10;
    if (timeframe === "90days") numDataPoints = 12;
    if (timeframe === "all") numDataPoints = Math.min(15, rewards.length);

    // Group rewards by date
    const dataByDate: Record<string, number> = {};
    
    // Sort rewards by date (newest first)
    const sortedRewards = [...rewards].sort((a, b) => 
      new Date(b.expiresAt).getTime() - new Date(a.expiresAt).getTime()
    );

    // Process rewards and count by date
    sortedRewards.forEach(reward => {
      const dateKey = formatDate(reward.expiresAt);
      dataByDate[dateKey] = (dataByDate[dateKey] || 0) + 1;
    });

    // Convert to chart data format
    const chartData = Object.entries(dataByDate)
      .map(([date, count]) => ({
        date,
        count
      }))
      .slice(0, numDataPoints) // Limit to our desired number of data points
      .reverse(); // Reverse to show oldest first

    return chartData;
  };

  const chartData = processFrequencyData();

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Reward Frequency</CardTitle>
        <CardDescription>Number of rewards received over time</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="w-full h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <RechartBarChart
              data={chartData}
              margin={{
                top: 10,
                right: 30,
                left: 0,
                bottom: 0,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip formatter={(value) => [`${value} rewards`, 'Count']} />
              <Legend />
              <Bar 
                dataKey="count" 
                fill="#82ca9d"
                name="Number of Rewards" 
              />
            </RechartBarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}