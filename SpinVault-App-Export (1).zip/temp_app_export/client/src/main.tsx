import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Debug logging
console.log("SpinVault: main.tsx is executing");

// Register service worker for notifications
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    console.log("SpinVault: Window load event triggered");
    navigator.serviceWorker.register('/notification-worker.js')
      .then(registration => {
        console.log('Notification service worker registered:', registration.scope);
        
        // Check for expiring rewards every 30 minutes
        setInterval(() => {
          if (registration.active) {
            registration.active.postMessage({
              type: 'CHECK_EXPIRING_REWARDS'
            });
          }
        }, 30 * 60 * 1000); // 30 minutes
      })
      .catch(error => {
        console.error('Service worker registration failed:', error);
      });
  });
}

// Check if root element exists
const rootElement = document.getElementById("root");
console.log("SpinVault: Root element found:", !!rootElement);

if (rootElement) {
  console.log("SpinVault: Attempting to render App");
  try {
    createRoot(rootElement).render(<App />);
    console.log("SpinVault: App rendering complete");
  } catch (error) {
    console.error("SpinVault: Error rendering App:", error);
  }
} else {
  console.error("SpinVault: Root element not found");
}
