// Automatic reward detection using service worker
import { showToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from './queryClient';

// Keep track of service worker registration
let detectionWorker: ServiceWorker | null = null;
let isWorkerRegistered = false;
let isDetecting = false;

// Initialize the detection worker when the app loads
export async function initializeDetectionWorker(userLoggedIn: boolean) {
  if (!('serviceWorker' in navigator)) {
    console.warn('Service Workers are not supported in this browser');
    return false;
  }

  try {
    const registration = await navigator.serviceWorker.register('/detection-worker.js');
    console.log('Detection worker registered:', registration.scope);
    
    // Wait for the worker to become active
    if (registration.installing) {
      registration.installing.addEventListener('statechange', (e) => {
        if ((e.target as ServiceWorker).state === 'activated') {
          setupWorkerCommunication(registration.active, userLoggedIn);
        }
      });
    } else if (registration.waiting) {
      registration.waiting.addEventListener('statechange', (e) => {
        if ((e.target as ServiceWorker).state === 'activated') {
          setupWorkerCommunication(registration.active, userLoggedIn);
        }
      });
    } else if (registration.active) {
      setupWorkerCommunication(registration.active, userLoggedIn);
    }
    
    isWorkerRegistered = true;
    return true;
  } catch (error) {
    console.error('Error registering detection worker:', error);
    return false;
  }
}

// Set up communication with the worker
function setupWorkerCommunication(worker: ServiceWorker, userLoggedIn: boolean) {
  detectionWorker = worker;
  
  // Set up a message listener for the worker
  navigator.serviceWorker.addEventListener('message', handleWorkerMessage);
  
  // Initialize the worker with user state
  worker.postMessage({
    action: 'initialize',
    userLoggedIn
  });
  
  // Set up communication with the tabs (sites to scan)
  window.addEventListener('storage', handleTabCommunication);
}

// Listen for tab communication
function handleTabCommunication(event: StorageEvent) {
  if (!event.key || !event.key.startsWith('spinvault_')) return;
  
  // If we get a ping from another tab, scan that tab if it's a gambling site
  if (event.key === 'spinvault_ping') {
    // Send message to that tab to scan itself
    localStorage.setItem('spinvault_scan_request', Date.now().toString());
  }
  
  // If we get scan results, process them
  if (event.key === 'spinvault_scan_result' && event.newValue) {
    try {
      const data = JSON.parse(event.newValue);
      if (data.rewards && data.rewards.length > 0) {
        processDetectedRewards(data.rewards);
      }
    } catch (error) {
      console.error('Error parsing scan results:', error);
    }
  }
}

// Process the scanner messages
function handleWorkerMessage(event: MessageEvent) {
  const data = event.data;
  
  if (!data || !data.action) return;
  
  // Handle various actions from the worker
  switch (data.action) {
    case 'scanNow':
      // Trigger a scan of the current page or communicate with other tabs
      performPageScan();
      break;
      
    case 'rewardDetected':
      // Handle a single detected reward
      if (data.reward) {
        processDetectedRewards([data.reward]);
      }
      break;
      
    case 'rewardsDetected':
      // Handle multiple detected rewards
      showToast({
        title: 'New Rewards Detected',
        description: `${data.count} new rewards have been added to your account.`,
        variant: 'default',
      });
      // Refresh the rewards list
      queryClient.invalidateQueries({ queryKey: ['/api/rewards'] });
      break;
      
    case 'detectionStatus':
      // Update the detection status UI
      isDetecting = data.isScanning;
      // Update any UI indicators here
      break;
  }
}

// Attempt to scan the current page for rewards
async function performPageScan() {
  // Only scan gambling sites
  const host = window.location.hostname.toLowerCase();
  const isGamblingSite = [
    'bet365', 'williamhill', 'paddypower', 'skybet', 'betfred',
    'coral', 'ladbrokes', 'heartbingo', 'meccabingo', '888casino'
  ].some(site => host.includes(site));
  
  if (!isGamblingSite) return;
  
  try {
    // Extract content from the page
    const extractContent = () => {
      // Select important elements that might contain offers
      const mainContent = document.querySelector('main')?.innerText || '';
      const offerSections = Array.from(
        document.querySelectorAll('.offer, .promotion, .bonus, .reward, .free-bet, .free-spin')
      ).map(el => el.innerText).join(' ');
      
      // Get visible text from the body as a fallback
      const visibleText = document.body.innerText.slice(0, 100000); // Limit to 100k chars
      
      return offerSections || mainContent || visibleText;
    };
    
    const content = extractContent();
    const url = window.location.href;
    
    // Send the data to the API directly
    const res = await apiRequest("POST", "/api/detect-reward", { content, url });
    const result = await res.json();
    
    if (result.success && result.rewards.length > 0) {
      // Communicate back to other tabs about the detected rewards
      localStorage.setItem('spinvault_scan_result', JSON.stringify({
        timestamp: Date.now(),
        rewards: result.rewards
      }));
      
      showToast({
        title: 'Rewards Detected!',
        description: `Found ${result.rewards.length} rewards on ${new URL(url).hostname}`,
        variant: 'default',
      });
      
      // Refresh the rewards list
      queryClient.invalidateQueries({ queryKey: ['/api/rewards'] });
    }
  } catch (error) {
    console.error('Error scanning page:', error);
  }
}

// Process detected rewards - send to the API or worker
async function processDetectedRewards(rewards: any[]) {
  if (!rewards.length) return;
  
  try {
    // Send directly to the API
    const res = await apiRequest("POST", "/api/sync-rewards", { rewards });
    const result = await res.json();
    
    if (result.success && result.savedCount > 0) {
      showToast({
        title: 'New Rewards Added',
        description: `${result.savedCount} new rewards have been added to your account.`,
        variant: 'default',
      });
      
      // Refresh the rewards list
      queryClient.invalidateQueries({ queryKey: ['/api/rewards'] });
    }
  } catch (error) {
    console.error('Error processing rewards:', error);
  }
}

// Start automatic detection
export function startAutoDetection() {
  if (!detectionWorker) {
    console.warn('Detection worker not available');
    return false;
  }
  
  // Send message to worker to start detection
  detectionWorker.postMessage({
    action: 'startDetection'
  });
  
  return true;
}

// Stop automatic detection
export function stopAutoDetection() {
  if (!detectionWorker) {
    return false;
  }
  
  // Send message to worker to stop detection
  detectionWorker.postMessage({
    action: 'stopDetection'
  });
  
  return true;
}

// Update detection worker when user logs in
export function notifyUserLogin() {
  if (!detectionWorker) return;
  
  detectionWorker.postMessage({
    action: 'userLogin'
  });
}

// Update detection worker when user logs out
export function notifyUserLogout() {
  if (!detectionWorker) return;
  
  detectionWorker.postMessage({
    action: 'userLogout'
  });
}