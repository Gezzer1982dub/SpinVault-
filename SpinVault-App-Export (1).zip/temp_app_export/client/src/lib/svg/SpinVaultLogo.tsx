import { cn } from "@/lib/utils";

interface SpinVaultLogoProps {
  className?: string;
}

export function SpinVaultLogo({ className }: SpinVaultLogoProps) {
  return (
    <svg 
      viewBox="0 0 100 100" 
      xmlns="http://www.w3.org/2000/svg"
      className={cn("text-primary", className)}
      fill="currentColor"
    >
      <path d="M50 5L5 30v40l45 25 45-25V30L50 5zm0 10l35 20v30L50 85 15 65V35l35-20z" />
      <path d="M40 35h20v10H40z" />
      <path d="M40 35v30h20V55H50V35H40z" />
      <path d="M30 45h15v10H30z" />
    </svg>
  );
}
