import { Suspense, lazy, useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

// Lazy load components to help with debugging
const AuthProvider = lazy(() => import("@/hooks/use-auth").then(module => ({ default: module.AuthProvider })));
const ThemeProvider = lazy(() => import("@/hooks/use-theme").then(module => ({ default: module.ThemeProvider })));
const NotificationsProvider = lazy(() => import("@/hooks/use-notifications").then(module => ({ default: module.NotificationsProvider })));
const ProtectedRoute = lazy(() => import("@/lib/protected-route").then(module => ({ default: module.ProtectedRoute })));
const Toaster = lazy(() => import("@/components/ui/toaster").then(module => ({ default: module.Toaster })));
const TooltipProvider = lazy(() => import("@/components/ui/tooltip").then(module => ({ default: module.TooltipProvider })));

// Lazy load all pages
const HomePage = lazy(() => import("@/pages/home-page"));
const AuthPage = lazy(() => import("@/pages/auth-page"));
const PremiumPage = lazy(() => import("@/pages/premium-page"));
const SocialInsights = lazy(() => import("@/pages/social-insights"));
const SharedReward = lazy(() => import("@/pages/shared-reward"));
const RewardStats = lazy(() => import("@/pages/reward-stats"));
const DiscoverPage = lazy(() => import("@/pages/discover-page"));
const UserRewardsSummary = lazy(() => import("@/pages/user-rewards-summary"));
const NotFound = lazy(() => import("@/pages/not-found"));

// Fallback loading component
const LoadingFallback = () => (
  <div className="flex items-center justify-center min-h-screen">
    <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
  </div>
);

// Error boundary component
function ErrorFallback() {
  const [showDetails, setShowDetails] = useState(false);
  
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <div className="bg-red-50 border border-red-200 p-6 rounded-lg max-w-md w-full">
        <h2 className="text-xl font-semibold text-red-800 mb-4">Something went wrong</h2>
        <p className="text-red-700 mb-4">
          An error occurred while loading the application.
        </p>
        <button 
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 mb-4"
        >
          Reload Application
        </button>
        
        <button 
          onClick={() => setShowDetails(!showDetails)}
          className="text-sm text-red-700 underline"
        >
          {showDetails ? "Hide technical details" : "Show technical details"}
        </button>
        
        {showDetails && (
          <div className="mt-4 p-3 bg-red-100 rounded text-sm overflow-auto max-h-64">
            <p>Check browser console for detailed error information.</p>
          </div>
        )}
      </div>
    </div>
  );
}

// Routing component with all routes restored
function Router() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <Switch>
        <Route path="/">
          <Suspense fallback={<LoadingFallback />}>
            <ProtectedRoute path="/" component={HomePage} />
          </Suspense>
        </Route>
        
        <Route path="/premium">
          <Suspense fallback={<LoadingFallback />}>
            <ProtectedRoute path="/premium" component={PremiumPage} />
          </Suspense>
        </Route>
        
        <Route path="/social">
          <Suspense fallback={<LoadingFallback />}>
            <ProtectedRoute path="/social" component={SocialInsights} />
          </Suspense>
        </Route>
        
        <Route path="/stats">
          <Suspense fallback={<LoadingFallback />}>
            <ProtectedRoute path="/stats" component={RewardStats} />
          </Suspense>
        </Route>
        
        <Route path="/discover">
          <Suspense fallback={<LoadingFallback />}>
            <ProtectedRoute path="/discover" component={DiscoverPage} />
          </Suspense>
        </Route>
        
        <Route path="/summary">
          <Suspense fallback={<LoadingFallback />}>
            <ProtectedRoute path="/summary" component={UserRewardsSummary} />
          </Suspense>
        </Route>
        
        <Route path="/auth">
          <Suspense fallback={<LoadingFallback />}>
            <AuthPage />
          </Suspense>
        </Route>
        
        <Route path="/share/reward/:id">
          <Suspense fallback={<LoadingFallback />}>
            <SharedReward />
          </Suspense>
        </Route>
        
        <Route>
          <Suspense fallback={<LoadingFallback />}>
            <NotFound />
          </Suspense>
        </Route>
      </Switch>
    </Suspense>
  );
}

function App() {
  try {
    return (
      <QueryClientProvider client={queryClient}>
        <Suspense fallback={<LoadingFallback />}>
          <ThemeProvider defaultTheme="system" storageKey="spinvault-theme">
            <Suspense fallback={<LoadingFallback />}>
              <AuthProvider>
                <Suspense fallback={<LoadingFallback />}>
                  <NotificationsProvider>
                    <Suspense fallback={<LoadingFallback />}>
                      <TooltipProvider>
                        <Toaster />
                        <Router />
                      </TooltipProvider>
                    </Suspense>
                  </NotificationsProvider>
                </Suspense>
              </AuthProvider>
            </Suspense>
          </ThemeProvider>
        </Suspense>
      </QueryClientProvider>
    );
  } catch (error) {
    console.error("Error rendering App:", error);
    return <ErrorFallback />;
  }
}

export default App;
