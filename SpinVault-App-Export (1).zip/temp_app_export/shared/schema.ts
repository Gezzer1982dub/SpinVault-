import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  // Added for premium subscription tracking
  isPremium: boolean("is_premium").default(false),
  premiumExpiresAt: timestamp("premium_expires_at"),
  // Stripe-specific fields
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  // User preferences
  preferences: jsonb("preferences").default({}),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

// Reward categories
export enum RewardCategory {
  // Traditional gambling categories
  FREE_SPINS = "FREE_SPINS",
  BONUS_CASH = "BONUS_CASH",
  DEPOSIT_MATCH = "DEPOSIT_MATCH",
  FREE_BET = "FREE_BET",
  BINGO_TICKETS = "BINGO_TICKETS",
  LOYALTY_POINTS = "LOYALTY_POINTS",
  OTHER = "OTHER",
  CUSTOM = "CUSTOM", // User-defined categories
  
  // Crypto gambling categories
  CRYPTO_BONUS = "CRYPTO_BONUS",
  RAKEBACK = "RAKEBACK",
  CASHBACK = "CASHBACK",
  DEPOSIT_BONUS = "DEPOSIT_BONUS",
  VIP_REWARD = "VIP_REWARD",
  CRYPTO_SPINS = "CRYPTO_SPINS",
  WELCOME_BONUS = "WELCOME_BONUS",
  CRYPTO_PROMO = "CRYPTO_PROMO"
}

// Custom categories schema
export const customCategories = pgTable("custom_categories", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  color: text("color").default("#6366F1"), // Default color (indigo)
  icon: text("icon").default("tag"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCustomCategorySchema = createInsertSchema(customCategories).pick({
  userId: true,
  name: true,
  description: true,
  color: true,
  icon: true,
});

export const updateCustomCategorySchema = createInsertSchema(customCategories)
  .partial()
  .pick({
    name: true,
    description: true,
    color: true,
    icon: true,
  });

// Reward schema
export const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  site: text("site").notNull(),
  reward: text("reward").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  claimed: boolean("claimed").default(false),
  category: text("category").default("OTHER"),
  customCategoryId: integer("custom_category_id"), // Reference to custom category if category is "CUSTOM"
  confidence: text("confidence"),
  // Link to the specific offer
  offerLink: text("offer_link"),  // Direct URL to the specific promotion
  // Progress tracking fields
  progressType: text("progress_type"),  // 'wagering', 'spins', 'deposit', 'playtime', etc.
  progressCurrent: integer("progress_current").default(0), // Current progress value
  progressTarget: integer("progress_target").default(0),   // Target to reach
  progressUnit: text("progress_unit"),  // 'GBP', 'spins', 'bets', 'minutes', etc.
  progressLastUpdated: timestamp("progress_last_updated"), // Last time progress was updated
  // Metadata
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Add date string schema for validation
const dateSchema = z.preprocess((arg) => {
  if (typeof arg === 'string' || arg instanceof Date) return new Date(arg);
  return arg;
}, z.date());

export const insertRewardSchema = createInsertSchema(rewards, {
  expiresAt: () => dateSchema,
  createdAt: () => dateSchema.optional(),
  progressLastUpdated: () => dateSchema.optional(),
})
  .pick({
    userId: true,
    site: true,
    reward: true,
    expiresAt: true,
    claimed: true,
    category: true,
    customCategoryId: true,
    confidence: true,
    offerLink: true,
    progressType: true,
    progressCurrent: true,
    progressTarget: true,
    progressUnit: true,
    progressLastUpdated: true,
    createdAt: true,
  });

export const updateRewardSchema = createInsertSchema(rewards, {
  expiresAt: () => dateSchema,
  progressLastUpdated: () => dateSchema.optional(),
})
  .partial() // Make all fields optional
  .pick({
    site: true,
    reward: true,
    expiresAt: true,
    claimed: true,
    category: true,
    customCategoryId: true,
    confidence: true,
    offerLink: true,
    progressType: true,
    progressCurrent: true,
    progressTarget: true,
    progressUnit: true,
    progressLastUpdated: true,
  });

// Define type for the settings JSON structure
export const SettingsSchema = z.object({
  enabledSites: z.array(z.string()).default(['Bet365', 'William Hill', 'Paddy Power']),
  autoSyncEnabled: z.boolean().default(false),
  notificationsEnabled: z.boolean().default(true),
  cryptoDetectionEnabled: z.boolean().default(false), // Premium feature - disabled by default
  detectionSettings: z.record(z.any()).default({})
});

export type Settings = z.infer<typeof SettingsSchema>;

// Extension settings schema for cross-device sync and detection settings
export const extensionSettings = pgTable("extension_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  // This matches our actual database structure which uses a single "settings" JSON column
  // for most settings rather than individual columns
  settings: jsonb("settings").default({}),
  dailyDetectionCount: integer("daily_detection_count").default(0),
  lastDetectionReset: timestamp("last_detection_reset").defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertExtensionSettingsSchema = createInsertSchema(extensionSettings).pick({
  userId: true,
  // Include the settings field
  settings: true,
  dailyDetectionCount: true,
  lastDetectionReset: true
});

export const updateExtensionSettingsSchema = createInsertSchema(extensionSettings).omit({
  id: true,
  userId: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertReward = z.infer<typeof insertRewardSchema>;
export type Reward = typeof rewards.$inferSelect;
export type UpdateReward = z.infer<typeof updateRewardSchema>;
export type InsertCustomCategory = z.infer<typeof insertCustomCategorySchema>;
export type CustomCategory = typeof customCategories.$inferSelect;
export type UpdateCustomCategory = z.infer<typeof updateCustomCategorySchema>;
// Public Offerings schema - for displaying available promotions to users
export const offerings = pgTable("offerings", {
  id: serial("id").primaryKey(),
  site: text("site").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").default("OTHER"),
  value: text("value").notNull(), // Estimated value
  requirements: text("requirements"), // Requirements to claim the reward
  expiresAt: timestamp("expires_at"), // When the offer expires, if applicable
  url: text("url"), // URL to claim the offer
  isNewMemberOffer: boolean("is_new_member_offer").default(false),
  isLimitedTime: boolean("is_limited_time").default(false),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertOfferingSchema = createInsertSchema(offerings, {
  expiresAt: () => dateSchema.optional(),
  detectedAt: () => dateSchema.optional(),
  updatedAt: () => dateSchema.optional(),
})
  .pick({
    site: true,
    title: true,
    description: true,
    category: true,
    value: true,
    requirements: true,
    expiresAt: true,
    url: true,
    isNewMemberOffer: true,
    isLimitedTime: true,
    detectedAt: true,
    updatedAt: true,
  });

export const updateOfferingSchema = createInsertSchema(offerings, {
  expiresAt: () => dateSchema.optional(),
})
  .partial()
  .pick({
    site: true,
    title: true,
    description: true,
    category: true,
    value: true,
    requirements: true,
    expiresAt: true,
    url: true,
    isNewMemberOffer: true,
    isLimitedTime: true,
  });

export type InsertExtensionSettings = z.infer<typeof insertExtensionSettingsSchema>;
export type ExtensionSettings = typeof extensionSettings.$inferSelect;
export type UpdateExtensionSettings = z.infer<typeof updateExtensionSettingsSchema>;
export type InsertOffering = z.infer<typeof insertOfferingSchema>;
export type Offering = typeof offerings.$inferSelect;
export type UpdateOffering = z.infer<typeof updateOfferingSchema>;

// Notification types
export enum NotificationType {
  REWARD_EXPIRING = "REWARD_EXPIRING",
  NEW_REWARD = "NEW_REWARD",
  REWARD_UPDATED = "REWARD_UPDATED",
  SYSTEM = "SYSTEM"
}

// Notification channels
export enum NotificationChannel {
  EMAIL = "EMAIL",
  PUSH = "PUSH",
  IN_APP = "IN_APP",
  SMS = "SMS" // For future implementation
}

// Notification status
export enum NotificationStatus {
  PENDING = "PENDING",
  SENT = "SENT",
  FAILED = "FAILED",
  READ = "READ"
}

// Notifications schema
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  channel: varchar("channel", { length: 20 }).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  status: varchar("status", { length: 20 }).notNull().default(NotificationStatus.PENDING),
  metadata: jsonb("metadata").default({}),
  relatedId: integer("related_id"), // ID of related entity (reward, etc.)
  scheduledFor: timestamp("scheduled_for"), // When to send the notification
  sentAt: timestamp("sent_at"), // When notification was sent
  readAt: timestamp("read_at"), // When notification was read by user
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertNotificationSchema = createInsertSchema(notifications, {
  scheduledFor: () => dateSchema.optional(),
  sentAt: () => dateSchema.optional(),
  readAt: () => dateSchema.optional(),
  createdAt: () => dateSchema.optional(),
}).pick({
  userId: true,
  type: true,
  channel: true,
  title: true,
  message: true,
  status: true,
  metadata: true,
  relatedId: true,
  scheduledFor: true,
});

export const updateNotificationSchema = createInsertSchema(notifications, {
  scheduledFor: () => dateSchema.optional(),
  sentAt: () => dateSchema.optional(),
  readAt: () => dateSchema.optional(),
})
  .partial()
  .pick({
    status: true,
    sentAt: true,
    readAt: true,
    scheduledFor: true,
    metadata: true,
  });

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type UpdateNotification = z.infer<typeof updateNotificationSchema>;
