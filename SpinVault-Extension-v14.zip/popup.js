/**
 * SpinVault Extension - Popup Script
 * This handles the popup UI interaction and state management
 */

document.addEventListener('DOMContentLoaded', function() {
  console.log('SpinVault popup loaded');
  
  // Cache DOM elements
  const statusMessage = document.getElementById('statusMessage');
  const loginSection = document.getElementById('loginSection');
  const scanButton = document.getElementById('scanButton');
  const viewAppButton = document.getElementById('viewAppButton');
  const rewardsList = document.getElementById('rewardsList');
  const noRewardsMessage = document.getElementById('noRewardsMessage');
  
  // App URL
  const APP_URL = 'https://e3358ddb-cf0c-495d-95cd-423fbf06a5bd-00-3en8vm9jsxml6.picard.replit.dev';
  
  // Initialize popup
  init();
  
  // Main initialization function
  async function init() {
    try {
      updateStatus('Checking login status...');
      
      // Check login status
      const loginStatus = await checkLoginStatus();
      
      // Update UI based on login status
      if (loginStatus.loggedIn) {
        updateStatus(`Logged in as ${loginStatus.user.username}`);
        renderLoggedInState(loginStatus.user);
      } else if (loginStatus.error) {
        updateStatus(`Error: ${loginStatus.error}`, 'error');
        renderLoginForm();
      } else {
        updateStatus('Not logged in');
        renderLoginForm();
      }
      
      // Load rewards regardless of login status (might have locally cached ones)
      loadRewards();
      
      // Set up button handlers
      setupEventListeners();
      
    } catch (error) {
      console.error('Error initializing popup:', error);
      updateStatus('Error initializing extension', 'error');
    }
  }
  
  // Check login status with background script
  async function checkLoginStatus() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: 'checkLoginStatus' }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error checking login status:', chrome.runtime.lastError);
          resolve({ loggedIn: false, error: chrome.runtime.lastError.message });
        } else {
          resolve(response);
        }
      });
    });
  }
  
  // Update status message
  function updateStatus(message, type = 'info') {
    statusMessage.textContent = message;
    statusMessage.className = 'status';
    
    // Add status type as class
    statusMessage.classList.add(`status-${type}`);
  }
  
  // Render logged in UI
  function renderLoggedInState(user) {
    loginSection.innerHTML = `
      <p>Hello <strong>${user.username}</strong>!</p>
      <button id="logoutButton" class="button">Log Out</button>
    `;
    
    // Add logout handler
    document.getElementById('logoutButton').addEventListener('click', handleLogout);
  }
  
  // Render login form
  function renderLoginForm() {
    loginSection.innerHTML = `
      <p>Log in to sync your rewards and access SpinVault web app features.</p>
      <button id="loginButton" class="button">Log In</button>
    `;
    
    // Add login handler
    document.getElementById('loginButton').addEventListener('click', handleLogin);
  }
  
  // Handle login button click
  function handleLogin() {
    updateStatus('Opening login page...');
    
    // Send message to background script to open login page
    chrome.runtime.sendMessage({ action: 'openLogin' }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('Error opening login page:', chrome.runtime.lastError);
        updateStatus('Error opening login page', 'error');
      } else {
        // Close the popup
        window.close();
      }
    });
  }
  
  // Handle logout button click
  async function handleLogout() {
    updateStatus('Logging out...');
    
    try {
      // Send message to background script to logout
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'logout' }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('Error logging out:', chrome.runtime.lastError);
            throw new Error(chrome.runtime.lastError.message);
          }
          resolve(response);
        });
      });
      
      if (response.success) {
        updateStatus('Logged out successfully');
        renderLoginForm();
      } else {
        updateStatus('Error logging out', 'error');
      }
    } catch (error) {
      console.error('Error during logout:', error);
      updateStatus('Error logging out: ' + error.message, 'error');
    }
  }
  
  // Load rewards from storage
  async function loadRewards() {
    try {
      // Get rewards from background script
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'getRewards' }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('Error getting rewards:', chrome.runtime.lastError);
            throw new Error(chrome.runtime.lastError.message);
          }
          resolve(response);
        });
      });
      
      // Update UI with rewards
      if (response.rewards && response.rewards.length > 0) {
        renderRewards(response.rewards);
      } else {
        // No rewards, show message
        noRewardsMessage.style.display = 'block';
        rewardsList.innerHTML = '';
      }
    } catch (error) {
      console.error('Error loading rewards:', error);
      updateStatus('Error loading rewards', 'error');
    }
  }
  
  // Render rewards in the UI
  function renderRewards(rewards) {
    // Hide no rewards message
    noRewardsMessage.style.display = 'none';
    
    // Clear previous rewards
    rewardsList.innerHTML = '';
    
    // Only show 5 most recent rewards
    const recentRewards = rewards.slice(0, 5);
    
    // Create HTML for each reward
    recentRewards.forEach(reward => {
      const rewardElement = document.createElement('div');
      rewardElement.className = 'reward-item';
      
      // Format date
      let dateDisplay = '';
      try {
        const date = new Date(reward.detectedAt);
        dateDisplay = `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
      } catch (error) {
        dateDisplay = 'Unknown date';
      }
      
      rewardElement.innerHTML = `
        <div class="reward-site">${reward.site}</div>
        <div class="reward-value">${reward.reward}</div>
        <div class="reward-date">Detected: ${dateDisplay}</div>
      `;
      
      rewardsList.appendChild(rewardElement);
    });
    
    // Show count if there are more
    if (rewards.length > 5) {
      const moreElement = document.createElement('div');
      moreElement.className = 'more-rewards';
      moreElement.textContent = `+ ${rewards.length - 5} more rewards. View all in the app.`;
      rewardsList.appendChild(moreElement);
    }
  }
  
  // Set up event listeners for buttons
  function setupEventListeners() {
    // Scan current page
    scanButton.addEventListener('click', async () => {
      updateStatus('Scanning current page...', 'loading');
      
      try {
        const response = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ action: 'scanPage' }, (response) => {
            if (chrome.runtime.lastError) {
              console.error('Error scanning page:', chrome.runtime.lastError);
              throw new Error(chrome.runtime.lastError.message);
            }
            resolve(response);
          });
        });
        
        if (response.success) {
          if (response.rewards && response.rewards.length > 0) {
            updateStatus(`Found ${response.rewards.length} rewards!`, 'success');
            loadRewards(); // Refresh rewards list
          } else {
            updateStatus(response.message || 'No rewards found on this page', 'warning');
          }
        } else {
          updateStatus(response.message || 'Scan failed', 'error');
        }
      } catch (error) {
        console.error('Error during page scan:', error);
        updateStatus('Error scanning page: ' + error.message, 'error');
      }
    });
    
    // Open app
    viewAppButton.addEventListener('click', () => {
      chrome.tabs.create({ url: APP_URL });
    });
  }
});