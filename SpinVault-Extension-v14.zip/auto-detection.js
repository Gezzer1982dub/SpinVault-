/**
 * SpinVault Extension - Automatic Detection Module
 * Provides enhanced detection capabilities for all supported gambling sites
 */

// List of supported gambling sites and their detection selectors/patterns
const SITE_CONFIGURATIONS = {
  'Bet365': {
    domainMatches: ['bet365.com', 'bet365.co.uk', 'bet365.es'],
    selectors: {
      offers: ['.promo-container', '.offer-container', '.bonus-card', '.my-offers'],
      loginState: ['.hm-UserName', '.um-UserManagement_Username', '#statusText', '.myaccount-logged-in']
    },
    keywords: ['free bet', 'free spin', 'bonus', 'offer', 'promo', 'promotion', 'cash out']
  },
  'Paddy Power': {
    domainMatches: ['paddypower.com', 'paddypower.co.uk', 'paddypower.ie'],
    selectors: {
      offers: ['.pp-promos', '.pp-promo', '.offers-wrapper', '.promotions-container', '.my-account-promotions'],
      loginState: ['.user-details', '.user-panel', '.customer-tab']
    },
    keywords: ['free bet', 'free spin', 'power up', 'power price', 'odds boost', 'acca insurance']
  },
  'Sky Bet': {
    domainMatches: ['skybet.com', 'skybet.co.uk'],
    selectors: {
      offers: ['.promotions-module', '.promotion-card', '.offers-list', '.boost-card'],
      loginState: ['.skybet-account-menu', '.identity__name', '.sb-member-info']
    },
    keywords: ['free bet', 'price boost', 'bet builder', 'club', 'acca insurance']
  },
  'William Hill': {
    domainMatches: ['williamhill.com', 'williamhill.co.uk'],
    selectors: {
      offers: ['.promotion-pod', '.promotions-list', '.marketing-card', '.offers-container'],
      loginState: ['.customer-details', '.username-container', '.logged-in-state']
    },
    keywords: ['free bet', 'enhanced odds', 'acca freedom', 'bonus', 'insurance']
  },
  'Ladbrokes': {
    domainMatches: ['ladbrokes.com', 'ladbrokes.co.uk'],
    selectors: {
      offers: ['.promotions', '.promotion-grid', '.promotion-card', '.promo-tile'],
      loginState: ['.user-state', '.account-info', '.signed-in']
    },
    keywords: ['free bet', 'odds boost', 'acca insurance', 'freespin']
  },
  'Coral': {
    domainMatches: ['coral.co.uk'],
    selectors: {
      offers: ['.promotion-container', '.promo-banner', '.coral-offers'],
      loginState: ['.login-status', '.account-info', '.member-info']
    },
    keywords: ['free bet', 'odds boost', 'acca insurance', 'build your bet']
  },
  'Betfred': {
    domainMatches: ['betfred.com', 'betfred.co.uk'],
    selectors: {
      offers: ['.bf-promo', '.promotion-container', '.offers-section'],
      loginState: ['.account-info', '.bf-account', '.logged-in-status']
    },
    keywords: ['free bet', 'double delight', 'hat-trick heaven', 'acca insurance']
  },
  'Mecca Bingo': {
    domainMatches: ['meccabingo.com'],
    selectors: {
      offers: ['.promotions-list', '.mecca-promos', '.offers-container'],
      loginState: ['.account-status', '.mecca-account', '.user-details']
    },
    keywords: ['free bingo', 'bonus', 'free spins', 'wheel of fortune']
  },
  'Heart Bingo': {
    domainMatches: ['heartbingo.co.uk'],
    selectors: {
      offers: ['.promotions-container', '.heart-offers', '.promo-tiles'],
      loginState: ['.user-panel', '.account-status', '.login-info']
    },
    keywords: ['free bingo', 'free spins', 'daily jackpot', 'welcome offer']
  },
  '888Casino': {
    domainMatches: ['888casino.com'],
    selectors: {
      offers: ['.promotions-grid', '.offers-list', '.promo-cards'],
      loginState: ['.user-info', '.account-status', '.login-container']
    },
    keywords: ['free spins', 'bonus', 'cashback', 'daily offer']
  }
};

// Detect which gambling site the user is on
function detectSite(url) {
  if (!url) return null;
  
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    
    for (const [siteName, config] of Object.entries(SITE_CONFIGURATIONS)) {
      if (config.domainMatches.some(domain => hostname.includes(domain))) {
        return siteName;
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error detecting site from URL:', error);
    return null;
  }
}

// Check if the user is logged in to the gambling site
function isLoggedIn(siteName) {
  if (!siteName || !SITE_CONFIGURATIONS[siteName]) return false;
  
  const config = SITE_CONFIGURATIONS[siteName];
  
  // Check if any of the login state selectors exist
  return config.selectors.loginState.some(selector => {
    const elements = document.querySelectorAll(selector);
    return elements.length > 0;
  });
}

// Extract text content from elements matching selectors
function extractTextFromSelectors(selectors) {
  let combinedText = '';
  
  selectors.forEach(selector => {
    try {
      const elements = document.querySelectorAll(selector);
      elements.forEach(element => {
        combinedText += ' ' + element.textContent;
      });
    } catch (error) {
      console.warn(`Error extracting text from selector ${selector}:`, error);
    }
  });
  
  return combinedText.trim();
}

// Extract all visible text from the page as fallback
function extractVisibleText() {
  // Get all elements that are potentially visible
  const textElements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, span, div, a, button');
  let text = '';
  
  textElements.forEach(element => {
    // Skip hidden elements
    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
      return;
    }
    
    text += ' ' + element.textContent;
  });
  
  return text.trim();
}

// Find rewards based on site-specific patterns and keywords
function findRewards(siteName, fullText) {
  if (!siteName || !SITE_CONFIGURATIONS[siteName]) {
    return [];
  }
  
  const config = SITE_CONFIGURATIONS[siteName];
  const keywords = config.keywords;
  
  // Split text into paragraphs to analyze each potential offer separately
  const paragraphs = fullText.split(/\n\n+|\r\n\r\n+/).filter(Boolean);
  const rewards = [];
  
  paragraphs.forEach(paragraph => {
    // Convert to lowercase for case-insensitive matching
    const lowerParagraph = paragraph.toLowerCase();
    
    // Check if paragraph contains any of the keywords
    const matchedKeyword = keywords.find(keyword => lowerParagraph.includes(keyword.toLowerCase()));
    
    if (matchedKeyword) {
      // Try to extract a meaningful title (first sentence or first 100 chars)
      let title = paragraph.split(/[.!?](\s|$)/)[0].trim();
      if (title.length > 100) {
        title = title.substring(0, 97) + '...';
      }
      
      // Try to extract expiry date
      let expiryText = '';
      let expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // Default 7 days from now
      
      // Advanced expiry date detection with multiple formats
      const expiryPatterns = [
        // Format: "valid until 31st December 2025"
        /(?:valid|available|offer|expires?|ends?)\s+(?:until|before|on|by)?\s+(\d{1,2}(?:st|nd|rd|th)?\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{4})/i,
        // Format: "valid until 31/12/2025"
        /(?:valid|available|offer|expires?|ends?)\s+(?:until|before|on|by)?\s+(\d{1,2}\/\d{1,2}\/\d{2,4})/i,
        // Format: "ends Monday" or "ends tomorrow"
        /(?:valid|available|offer|expires?|ends?)\s+(?:until|before|on|by)?\s+(today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday)/i,
        // Format: "offer ends at midnight" 
        /(?:valid|available|offer|expires?|ends?)\s+(?:until|before|on|by)?\s+(?:at)?\s+(midnight|noon)/i,
        // Simple date format without context: "31/12/2025"
        /(\d{1,2}\/\d{1,2}\/\d{2,4})/i,
        // Simple date format without context: "31st December 2025"
        /(\d{1,2}(?:st|nd|rd|th)?\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{4})/i
      ];
      
      // Try to match expiry patterns
      for (const pattern of expiryPatterns) {
        const match = paragraph.match(pattern);
        if (match && match[1]) {
          expiryText = match[0];
          
          // Try to parse the date from the matched text
          try {
            // For full date formats
            if (/\d{1,2}\/\d{1,2}\/\d{2,4}/.test(match[1]) || 
                /\d{1,2}(?:st|nd|rd|th)?\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i.test(match[1])) {
              
              // Replace ordinal suffixes to help date parsing
              const cleanDateText = match[1].replace(/(st|nd|rd|th)/i, '');
              
              // Try different date parsing approaches
              let parsedDate = new Date(cleanDateText);
              
              // If that fails, try with UK format (dd/mm/yyyy)
              if (isNaN(parsedDate.getTime()) && /\d{1,2}\/\d{1,2}\/\d{2,4}/.test(cleanDateText)) {
                const parts = cleanDateText.split('/');
                if (parts.length === 3) {
                  // Assume UK format: day/month/year
                  let year = parseInt(parts[2]);
                  // Handle 2-digit years
                  if (year < 100) {
                    year += year < 50 ? 2000 : 1900;
                  }
                  parsedDate = new Date(year, parseInt(parts[1]) - 1, parseInt(parts[0]));
                }
              }
              
              if (!isNaN(parsedDate.getTime())) {
                expiresAt = parsedDate;
              }
            } 
            // For relative day names like "tomorrow", "Monday", etc.
            else if (/today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday/i.test(match[1])) {
              const today = new Date();
              const dayText = match[1].toLowerCase();
              
              if (dayText === 'today') {
                // End of today
                expiresAt = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59);
              } else if (dayText === 'tomorrow') {
                // End of tomorrow
                expiresAt = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 23, 59, 59);
              } else {
                // Find the next occurrence of the specified day
                const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
                const targetDay = dayNames.indexOf(dayText);
                if (targetDay !== -1) {
                  const currentDay = today.getDay();
                  let daysUntilTarget = targetDay - currentDay;
                  if (daysUntilTarget <= 0) daysUntilTarget += 7; // Next week if day has already passed
                  expiresAt = new Date(today.getFullYear(), today.getMonth(), today.getDate() + daysUntilTarget, 23, 59, 59);
                }
              }
            }
            // For time-based expirations like "midnight" or "noon"
            else if (/midnight|noon/i.test(match[1])) {
              const today = new Date();
              if (/midnight/i.test(match[1])) {
                // End of today at midnight
                expiresAt = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 0, 0, 0);
              } else if (/noon/i.test(match[1])) {
                // Today at noon
                expiresAt = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 12, 0, 0);
              }
            }
          } catch (err) {
            console.error('SpinVault: Error parsing expiry date:', err);
            // Keep default expiry if parsing fails
          }
          
          break; // Stop after finding the first valid expiry pattern
        }
      }
      
      // Determine category based on keywords in the text
      let category = 'OTHER';
      if (lowerParagraph.includes('free bet') || lowerParagraph.includes('bet')) {
        category = 'FREE_BET';
      } else if (lowerParagraph.includes('spin') || lowerParagraph.includes('slot')) {
        category = 'FREE_SPIN';
      } else if (lowerParagraph.includes('bonus') || lowerParagraph.includes('cash')) {
        category = 'DEPOSIT_BONUS';
      } else if (lowerParagraph.includes('odds') || lowerParagraph.includes('boost')) {
        category = 'ODDS_BOOST';
      } else if (lowerParagraph.includes('acca') || lowerParagraph.includes('accumulator')) {
        category = 'ACCA_INSURANCE';
      } else if (lowerParagraph.includes('cashback') || lowerParagraph.includes('money back')) {
        category = 'CASHBACK';
      } else if (lowerParagraph.includes('prize') || lowerParagraph.includes('jackpot')) {
        category = 'JACKPOT';
      } else if (lowerParagraph.includes('welcome') && lowerParagraph.includes('offer')) {
        category = 'WELCOME_OFFER';
      } else if (lowerParagraph.includes('bingo')) {
        category = 'FREE_GAME';
      }
      
      // Add reward if title is meaningful
      if (title && title.length > 5) {
        rewards.push({
          site: siteName,
          reward: title,
          fullText: paragraph,
          category,
          expiryText: expiryText,
          detectedAt: new Date().toISOString(),
          expiresAt: expiresAt.toISOString()
        });
      }
    }
  });
  
  // Remove duplicates (same title for same site)
  const uniqueRewards = rewards.filter((reward, index, self) => 
    index === self.findIndex(r => r.site === reward.site && r.reward === reward.reward)
  );
  
  return uniqueRewards;
}

// Scan the current page for rewards
async function scanPage() {
  try {
    // Get the current URL
    const url = window.location.href;
    
    // Detect which gambling site we're on
    const siteName = detectSite(url);
    if (!siteName) {
      return { success: false, message: 'Not a supported gambling site' };
    }
    
    console.log(`SpinVault: Scanning ${siteName} for rewards...`);
    
    // Check if user is logged in
    const userLoggedIn = isLoggedIn(siteName);
    console.log(`SpinVault: User logged in to ${siteName}: ${userLoggedIn}`);
    
    // Get site configuration
    const siteConfig = SITE_CONFIGURATIONS[siteName];
    
    // Get text from offer elements first
    let offerText = extractTextFromSelectors(siteConfig.selectors.offers);
    
    // If no specific offer text found, fallback to all visible text
    if (!offerText || offerText.length < 100) {
      offerText = extractVisibleText();
    }
    
    // Find rewards in the text
    const rewards = findRewards(siteName, offerText);
    
    if (rewards.length > 0) {
      console.log(`SpinVault: Found ${rewards.length} rewards on ${siteName}`);
      return { 
        success: true, 
        rewards,
        message: `Found ${rewards.length} rewards on ${siteName}`
      };
    } else {
      console.log(`SpinVault: No rewards found on ${siteName}`);
      return { 
        success: true, 
        rewards: [],
        message: 'No rewards found on this page'
      };
    }
  } catch (error) {
    console.error('SpinVault: Error scanning page:', error);
    return { 
      success: false, 
      message: 'Error scanning page: ' + error.message 
    };
  }
}

// Export functions for use in content script
window.SpinVaultDetection = {
  scanPage,
  detectSite,
  isLoggedIn,
  findRewards
};