/**
 * SpinVault Extension - Background Script
 * This handles authentication, scanning, and communication with the server
 */

// Server URL - update if deployed elsewhere
const SERVER_URL = 'https://e3358ddb-cf0c-495d-95cd-423fbf06a5bd-00-3en8vm9jsxml6.picard.replit.dev';

// User state
let currentUser = null;
let isScanning = false;

// On install, set up default state
chrome.runtime.onInstalled.addListener(async () => {
  console.log('SpinVault extension installed');
  
  // Set default settings
  await chrome.storage.local.set({
    autoDetectionEnabled: true, // Enable automatic detection by default
    detectionEnabled: true,
    lastScan: null,
    rewards: [],
    loginRedirectPending: false
  });
  
  // Check login status on install
  checkLoginStatus();
});

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message);
  
  if (message.action === 'checkLoginStatus') {
    checkLoginStatus().then(sendResponse);
    return true; // Keep channel open for async response
  }
  
  if (message.action === 'scanPage') {
    scanCurrentTab().then(sendResponse);
    return true; // Keep channel open for async response
  }
  
  if (message.action === 'getRewards') {
    chrome.storage.local.get('rewards', (data) => {
      sendResponse({ rewards: data.rewards || [] });
    });
    return true; // Keep channel open for async response
  }
  
  if (message.action === 'openLogin') {
    openLoginPage();
    sendResponse({ success: true });
    return false;
  }
  
  if (message.action === 'logout') {
    logout().then(sendResponse);
    return true; // Keep channel open for async response
  }
  
  if (message.action === 'saveReward') {
    saveReward(message.reward).then(sendResponse);
    return true; // Keep channel open for async response
  }
});

// Check login status with server - this is the critical functionality
async function checkLoginStatus() {
  try {
    console.log('Checking login status with server...');
    
    // Use better fetch options to ensure cookies are sent
    const response = await fetch(`${SERVER_URL}/api/user`, {
      method: 'GET',
      credentials: 'include', // This is critical for cookies
      headers: {
        'Accept': 'application/json',
        'X-Source': 'extension'
      },
      // Add cache busting parameter
      cache: 'no-store'
    });
    
    console.log('Login status response:', response.status);
    
    if (response.ok) {
      // User is logged in
      const userData = await response.json();
      console.log('User is logged in:', userData);
      
      // Update state and storage
      currentUser = userData;
      await chrome.storage.local.set({ user: userData });
      
      return { 
        loggedIn: true, 
        user: userData 
      };
    } else {
      // User is not logged in
      console.log('User is not logged in');
      currentUser = null;
      await chrome.storage.local.remove('user');
      
      return { 
        loggedIn: false 
      };
    }
  } catch (error) {
    console.error('Error checking login status:', error);
    
    // Check if we have a saved user even if the network request failed
    const { user } = await chrome.storage.local.get('user');
    
    if (user) {
      console.log('Using cached user data due to network error');
      currentUser = user;
      return { 
        loggedIn: true, 
        user,
        offline: true
      };
    }
    
    return { 
      loggedIn: false, 
      error: error.message 
    };
  }
}

// Open login page in a new tab
function openLoginPage() {
  // Store that we're waiting for a login redirect
  chrome.storage.local.set({ loginRedirectPending: true });
  
  // Open the login page in a new tab
  chrome.tabs.create({ 
    url: `${SERVER_URL}/auth?source=extension&time=${Date.now()}` 
  });
}

// Log out from the server
async function logout() {
  try {
    // Call server logout endpoint
    const response = await fetch(`${SERVER_URL}/api/logout`, {
      method: 'POST',
      credentials: 'include'
    });
    
    // Clear local storage regardless of server response
    currentUser = null;
    await chrome.storage.local.remove('user');
    
    return { success: true };
  } catch (error) {
    console.error('Error logging out:', error);
    
    // Still clear local storage on error
    currentUser = null;
    await chrome.storage.local.remove('user');
    
    return { 
      success: true, 
      offline: true 
    };
  }
}

// Save reward to local storage and server
async function saveReward(reward) {
  try {
    // Add timestamp if not present
    const rewardWithTimestamp = {
      ...reward,
      detectedAt: reward.detectedAt || new Date().toISOString()
    };
    
    // Get existing rewards from storage
    const { rewards = [] } = await chrome.storage.local.get('rewards');
    
    // Add new reward at the beginning
    const updatedRewards = [rewardWithTimestamp, ...rewards];
    
    // Store locally
    await chrome.storage.local.set({ 
      rewards: updatedRewards.slice(0, 100) // Keep only the latest 100
    });
    
    // If user is logged in, also send to server
    if (currentUser) {
      try {
        const response = await fetch(`${SERVER_URL}/api/rewards`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            site: reward.site,
            reward: reward.reward,
            expiresAt: reward.expiresAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
            category: reward.category || 'FREE_BET',
            notes: reward.notes || ''
          }),
          credentials: 'include'
        });
        
        if (response.ok) {
          console.log('Reward sent to server successfully');
          return { success: true, savedToServer: true };
        } else {
          console.error('Failed to send reward to server:', response.status);
          return { success: true, savedToServer: false };
        }
      } catch (error) {
        console.error('Error sending reward to server:', error);
        return { success: true, savedToServer: false };
      }
    }
    
    return { success: true };
  } catch (error) {
    console.error('Error saving reward:', error);
    return { success: false, error: error.message };
  }
}

// Scan current tab for rewards
async function scanCurrentTab() {
  try {
    // Prevent concurrent scans
    if (isScanning) {
      return { 
        success: false, 
        message: 'Scan already in progress' 
      };
    }
    
    isScanning = true;
    console.log('Starting page scan...');
    
    // Get the current active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab) {
      isScanning = false;
      return { 
        success: false, 
        message: 'No active tab to scan' 
      };
    }
    
    console.log('Scanning tab:', tab.url);
    
    // Detect site from URL
    const site = getSiteFromUrl(tab.url);
    
    if (!site) {
      isScanning = false;
      return { 
        success: false, 
        message: 'Not a supported gambling site' 
      };
    }
    
    // Send message to content script to scan the page
    try {
      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(
          tab.id, 
          { action: 'scanPage', site },
          (result) => {
            // Handle error if content script not loaded or no response
            if (chrome.runtime.lastError) {
              console.error('Error sending message to content script:', chrome.runtime.lastError);
              resolve({ 
                success: false, 
                error: chrome.runtime.lastError.message 
              });
              return;
            }
            resolve(result);
          }
        );
      });
      
      // If content script response successful
      if (response && response.success) {
        console.log('Content script scan results:', response);
        
        // Record the scan time
        await chrome.storage.local.set({ lastScan: new Date().toISOString() });
        
        // If rewards found, save them
        if (response.rewards && response.rewards.length > 0) {
          // Save each reward
          for (const reward of response.rewards) {
            await saveReward(reward);
          }
          
          isScanning = false;
          return { 
            success: true, 
            message: `Found ${response.rewards.length} rewards!`,
            rewards: response.rewards 
          };
        }
        
        isScanning = false;
        return { 
          success: true, 
          message: 'No rewards found on this page' 
        };
      }
      
      // Try falling back to direct detection if content script fails or not installed
      console.log('Content script scan failed, trying server-side detection...');
      
      // Extract the full hostname
      const hostname = new URL(tab.url).hostname;
      
      // Call server-side detection API
      const serverResponse = await fetch(`${SERVER_URL}/api/extension/detect-rewards`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          site: site,
          url: tab.url,
          hostname: hostname
        }),
        credentials: 'include'
      });
      
      if (serverResponse.ok) {
        const data = await serverResponse.json();
        
        if (data.success && data.rewards && data.rewards.length > 0) {
          // Save the server-detected rewards
          for (const reward of data.rewards) {
            await saveReward(reward);
          }
          
          isScanning = false;
          return { 
            success: true, 
            message: `Found ${data.rewards.length} rewards using server detection!`,
            rewards: data.rewards 
          };
        }
      }
      
      isScanning = false;
      return { 
        success: false, 
        message: 'No rewards detected' 
      };
    } catch (error) {
      console.error('Error during scanning:', error);
      isScanning = false;
      return { 
        success: false, 
        message: 'Error during scan: ' + error.message 
      };
    }
  } finally {
    isScanning = false;
  }
}

// Advanced reward categorization
function categorizeReward(reward) {
  // If a category is already assigned, use it
  if (reward.category && reward.category !== 'OTHER') {
    return reward.category;
  }
  
  // Lowercase text for case-insensitive matching
  const text = (reward.fullText || reward.reward || '').toLowerCase();
  
  // Define pattern matchers for different reward types
  const patterns = {
    'FREE_BET': [
      'free bet', 'bet £', 'bet $', 'bet €', 'stake back', 'money back bet', 
      'risk free', 'best odds', 'bet boost', 'bet credit'
    ],
    'FREE_SPIN': [
      'free spin', 'spin credit', 'slot', 'casino bonus', 'casino offer', 
      'bonus spin', 'extra spin', 'wager free spin'
    ],
    'DEPOSIT_BONUS': [
      'deposit bonus', 'deposit match', 'bonus credit', 'first deposit', 
      'reload bonus', '% bonus', 'match deposit'
    ],
    'ODDS_BOOST': [
      'odds boost', 'price boost', 'enhanced odds', 'power price', 
      'enhanced price', 'double odds', 'acca boost'
    ],
    'ACCA_INSURANCE': [
      'acca insurance', 'accumulator insurance', 'insurance', 'acca protection', 
      'money back if', 'acca free bet'
    ],
    'CASHBACK': [
      'cashback', 'money back', 'cash refund', 'cash out', 'early payout', 
      'rebate', 'refund if'
    ],
    'FREE_GAME': [
      'free bingo', 'free game', 'game credit', 'free scratchcard', 
      'free live casino', 'bingo ticket'
    ],
    'WELCOME_OFFER': [
      'welcome offer', 'welcome bonus', 'sign up offer', 'new customer', 
      'new account', 'sign up bonus'
    ],
    'JACKPOT': [
      'jackpot', 'prize draw', 'prize pool', 'mega prize', 'win a share', 
      'million pound', 'daily jackpot'
    ],
    'LOYALTY': [
      'loyalty', 'vip', 'reward club', 'points', 'reward program', 
      'loyalty bonus', 'vip club', 'vip reward'
    ],
    'REFER_FRIEND': [
      'refer', 'friend', 'referral', 'refer a friend', 'tell a friend', 
      'refer and earn', 'refer & earn'
    ]
  };
  
  // Find the best matching category
  let bestCategory = 'OTHER';
  let bestMatchCount = 0;
  
  for (const [category, keywords] of Object.entries(patterns)) {
    const matchCount = keywords.filter(keyword => text.includes(keyword)).length;
    if (matchCount > bestMatchCount) {
      bestMatchCount = matchCount;
      bestCategory = category;
    }
  }
  
  // Advanced context-based categorization logic
  if (bestCategory === 'OTHER') {
    // Generic fallback logic based on common terms
    if (text.includes('bet') && !text.includes('casino')) {
      bestCategory = 'FREE_BET';
    } else if (text.includes('casino') || text.includes('slot')) {
      bestCategory = 'FREE_SPIN';
    } else if (text.includes('deposit') || text.includes('bonus')) {
      bestCategory = 'DEPOSIT_BONUS';
    } else if (text.includes('new') && (text.includes('customer') || text.includes('account'))) {
      bestCategory = 'WELCOME_OFFER';
    }
  }
  
  return bestCategory;
}

// Save reward to local storage and server
async function saveReward(reward) {
  try {
    // Add timestamp if not present
    const rewardWithTimestamp = {
      ...reward,
      detectedAt: reward.detectedAt || new Date().toISOString()
    };
    
    // Apply improved categorization
    rewardWithTimestamp.category = categorizeReward(rewardWithTimestamp);
    
    // Get existing rewards from storage
    const { rewards = [] } = await chrome.storage.local.get('rewards');
    
    // Check if this reward already exists (avoid duplicates)
    const isDuplicate = rewards.some(existingReward => 
      existingReward.site === rewardWithTimestamp.site && 
      existingReward.reward === rewardWithTimestamp.reward
    );
    
    if (isDuplicate) {
      console.log('Skipping duplicate reward:', rewardWithTimestamp.reward);
      return { success: true, duplicate: true };
    }
    
    // Add new reward at the beginning
    const updatedRewards = [rewardWithTimestamp, ...rewards];
    
    // Store locally
    await chrome.storage.local.set({ 
      rewards: updatedRewards.slice(0, 100) // Keep only the latest 100
    });
    
    // If user is logged in, also send to server
    if (currentUser) {
      try {
        const response = await fetch(`${SERVER_URL}/api/rewards`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            site: reward.site,
            reward: reward.reward,
            expiresAt: reward.expiresAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
            category: rewardWithTimestamp.category,
            notes: reward.notes || reward.fullText || ''
          }),
          credentials: 'include'
        });
        
        if (response.ok) {
          console.log('Reward sent to server successfully');
          return { success: true, savedToServer: true };
        } else {
          console.error('Failed to send reward to server:', response.status);
          return { success: true, savedToServer: false };
        }
      } catch (error) {
        console.error('Error sending reward to server:', error);
        return { success: true, savedToServer: false };
      }
    }
    
    return { success: true };
  } catch (error) {
    console.error('Error saving reward:', error);
    return { success: false, error: error.message };
  }
}

// Determine gambling site from URL
function getSiteFromUrl(url) {
  if (!url) return null;
  
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    
    if (hostname.includes('bet365')) return 'Bet365';
    if (hostname.includes('paddypower')) return 'Paddy Power';
    if (hostname.includes('skybet')) return 'Sky Bet';
    if (hostname.includes('williamhill')) return 'William Hill';
    if (hostname.includes('ladbrokes')) return 'Ladbrokes';
    if (hostname.includes('coral')) return 'Coral';
    if (hostname.includes('betfred')) return 'Betfred';
    if (hostname.includes('meccabingo')) return 'Mecca Bingo';
    if (hostname.includes('heartbingo')) return 'Heart Bingo';
    if (hostname.includes('888casino')) return '888Casino';
    if (hostname.includes('888sport')) return '888Sport';
    if (hostname.includes('betfair')) return 'Betfair';
    if (hostname.includes('unibet')) return 'Unibet';
    if (hostname.includes('betway')) return 'Betway';
    if (hostname.includes('betvictor')) return 'BetVictor';
    if (hostname.includes('10bet')) return '10Bet';
    if (hostname.includes('boylesports')) return 'BoyleSports';
    
    return null;
  } catch (error) {
    console.error('Error parsing URL:', error);
    return null;
  }
}

// Add listener for tab updates to handle auto-scanning and login redirects
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Only run when the page is fully loaded
  if (changeInfo.status === 'complete') {
    
    // Handle login redirect detection
    if (tab.url && tab.url.includes(SERVER_URL)) {
      chrome.storage.local.get('loginRedirectPending', async (data) => {
        if (data.loginRedirectPending) {
          console.log('Detected potential login redirect, checking status...');
          
          // Wait a moment for cookies to be set
          setTimeout(async () => {
            const status = await checkLoginStatus();
            
            if (status.loggedIn) {
              console.log('User successfully logged in after redirect');
              chrome.storage.local.set({ loginRedirectPending: false });
            }
          }, 1000);
        }
      });
    }
    
    // Auto-detect rewards if it's a gambling site
    if (tab.url) {
      const site = getSiteFromUrl(tab.url);
      
      if (site) {
        // Check if auto-detection is enabled
        chrome.storage.local.get(['autoDetectionEnabled', 'lastScan'], async (data) => {
          if (data.autoDetectionEnabled !== false) { // Default to true if not set
            // Check if we've scanned recently (avoid scanning the same page too often)
            const now = Date.now();
            let shouldScan = true;
            
            if (data.lastScan) {
              const lastScanTime = new Date(data.lastScan).getTime();
              // Only scan if more than 5 minutes have passed since last scan for this site
              shouldScan = (now - lastScanTime) > 5 * 60 * 1000;
            }
            
            if (shouldScan) {
              console.log(`Auto-scanning detected gambling site: ${site}`);
              
              // Wait a few seconds for the page to fully render
              setTimeout(() => {
                scanCurrentTab().then(result => {
                  if (result.success && result.rewards && result.rewards.length > 0) {
                    // Show notification of detected rewards
                    chrome.notifications.create({
                      type: 'basic',
                      iconUrl: 'icon128.png',
                      title: 'SpinVault - Rewards Detected!',
                      message: `Found ${result.rewards.length} rewards on ${site}`,
                      priority: 2
                    });
                  }
                });
              }, 3000);
            } else {
              console.log('Skipping auto-scan (scanned recently)');
            }
          }
        });
      }
    }
  }
});