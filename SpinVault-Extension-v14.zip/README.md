# SpinVault Extension v1.3.0

This is the latest stable version of the SpinVault extension with enhanced reward detection capabilities.

## Key Improvements in v1.3.0
- Fixed duplicate reward detection issues in William Hill
- Improved categorization of similar promotions
- Enhanced text extraction for better reward details
- More aggressive deduplication for all gambling sites

## William Hill Specific Fixes
- Better separation of Sports and Casino offers
- Specialized parsing for "SportsBET" and "VegasGET" promotions
- Improved text node scanning for complete offer details
- Multilevel duplication prevention (exact text + categorization)

## Installation Instructions
1. Go to Chrome Extensions (chrome://extensions/)
2. Enable Developer Mode (toggle in top right)
3. Click "Load unpacked" and select this folder
4. The extension will appear in your browser toolbar

## Usage
1. Login to the SpinVault web app first
2. Click the extension icon to log in with the same credentials
3. Visit gambling sites to automatically detect rewards
4. Use "Scan Current Page" in the extension popup to manually trigger detection
5. View your rewards in the extension or on the SpinVault web app

## Supported Sites
- William Hill
- Paddy Power
- Bet365
- Sky Bet
- Ladbrokes
- Coral
- Betfred
- 888 Sport/Casino
- Mecca Bingo
- Heart Bingo
- More coming soon...