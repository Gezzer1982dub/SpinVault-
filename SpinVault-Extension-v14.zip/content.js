/**
 * SpinVault Extension - Content Script
 * This handles the enhanced automatic detection of rewards on all gambling sites
 */

// Track initialization state
let isInitialized = false;
let autoDetectionScriptInjected = false;

// Initialize and detect offers when the content script loads
window.addEventListener('load', () => {
  console.log('SpinVault: Content script loaded');
  injectAutoDetectionScript();
  initDetection();
});

// Inject the auto-detection script into the page
function injectAutoDetectionScript() {
  if (autoDetectionScriptInjected) return;
  
  try {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('auto-detection.js');
    script.onload = function() {
      console.log('SpinVault: Auto-detection script loaded successfully');
      autoDetectionScriptInjected = true;
      
      // Check if we need to re-trigger detection after script is loaded
      if (isInitialized) {
        console.log('SpinVault: Re-running detection with newly loaded script');
        const site = getSiteFromUrl(window.location.href);
        if (site) {
          scanPage(site);
        }
      }
      
      // This script should remain in the page for detection to work
      // this.remove(); 
    };
    (document.head || document.documentElement).appendChild(script);
    console.log('SpinVault: Auto-detection script injected');
  } catch (error) {
    console.error('SpinVault: Error injecting auto-detection script:', error);
  }
}

// Initialize the detector with auto retry
function initDetection() {
  if (isInitialized) return;
  
  // Wait for page to be fully loaded and stable
  setTimeout(async () => {
    try {
      console.log('SpinVault: Initializing enhanced reward detector...');
      isInitialized = true;
      
      // Listen for messages from background script
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'scanPage') {
          console.log('SpinVault: Received scan request for', message.site);
          
          scanPage(message.site)
            .then(result => {
              console.log('SpinVault: Scan results:', result);
              sendResponse(result);
            })
            .catch(error => {
              console.error('SpinVault: Scan error:', error);
              sendResponse({ 
                success: false, 
                error: error.message 
              });
            });
          
          return true; // Keep message channel open for async response
        }
      });
      
      console.log('SpinVault: Enhanced reward detector initialized successfully');
      
      // Setup DOM observer for continuous monitoring
      setupDOMObserver();
      
      // Auto-scan after initialization if on a gambling site
      // Automatically detect the current site we're on
      const site = getSiteFromUrl(window.location.href);
      
      if (site) {
        console.log(`SpinVault: Auto-detected gambling site: ${site}`);
        
        // Wait for page to fully render before auto-scanning
        setTimeout(async () => {
          console.log(`SpinVault: Auto-scanning ${site} page...`);
          try {
            const results = await scanPage(site);
            
            if (results.success && results.rewards && results.rewards.length > 0) {
              console.log(`SpinVault: Auto-scan found ${results.rewards.length} rewards!`);
              
              // Send rewards to background script for storage
              for (const reward of results.rewards) {
                chrome.runtime.sendMessage({
                  action: 'saveReward',
                  reward: reward
                });
              }
            } else {
              console.log('SpinVault: Auto-scan completed, no rewards found');
            }
          } catch (error) {
            console.error('SpinVault: Auto-scan error:', error);
          }
        }, 3000);
      }
      
    } catch (error) {
      console.error('SpinVault: Error initializing reward detector:', error);
      isInitialized = false;
      
      // Retry initialization after a delay
      setTimeout(initDetection, 2000);
    }
  }, 1000);
}

// Get site name from URL
function getSiteFromUrl(url) {
  if (!url) return null;
  
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    
    if (hostname.includes('bet365')) return 'Bet365';
    if (hostname.includes('paddypower')) return 'Paddy Power';
    if (hostname.includes('skybet')) return 'Sky Bet';
    if (hostname.includes('williamhill')) return 'William Hill';
    if (hostname.includes('ladbrokes')) return 'Ladbrokes';
    if (hostname.includes('coral')) return 'Coral';
    if (hostname.includes('betfred')) return 'Betfred';
    if (hostname.includes('meccabingo')) return 'Mecca Bingo';
    if (hostname.includes('heartbingo')) return 'Heart Bingo';
    if (hostname.includes('888casino')) return '888Casino';
    if (hostname.includes('betfair')) return 'Betfair';
    if (hostname.includes('unibet')) return 'Unibet';
    if (hostname.includes('betway')) return 'Betway';
    if (hostname.includes('betvictor')) return 'BetVictor';
    if (hostname.includes('10bet')) return '10Bet';
    if (hostname.includes('boylesports')) return 'BoyleSports';
    
    return null;
  } catch (error) {
    console.error('SpinVault: Error parsing URL:', error);
    return null;
  }
}

// Setup a DOM observer to detect new content that might contain offers
function setupDOMObserver() {
  const observer = new MutationObserver((mutations) => {
    // Check if we detect significant changes to the page content
    const significantChange = mutations.some(mutation => {
      return Array.from(mutation.addedNodes).some(node => {
        // Check if this is a significant DOM change (new element with text content)
        if (node.nodeType === Node.ELEMENT_NODE) {
          // Check if it has an HTML element
          if (node instanceof HTMLElement) {
            const hasText = node.innerText && node.innerText.trim().length > 50;
            const isPotentialOffer = 
              node.classList && (
                node.classList.contains('promo') || 
                node.classList.contains('offer') || 
                node.classList.contains('promotion') ||
                node.classList.contains('bonus') ||
                (node.innerHTML && (
                  node.innerHTML.toLowerCase().includes('free bet') ||
                  node.innerHTML.toLowerCase().includes('promotion')
                ))
              );
            
            return hasText || isPotentialOffer;
          }
        }
        return false;
      });
    });
    
    if (significantChange) {
      console.log('SpinVault: Detected significant DOM changes, re-scanning for offers...');
      const site = getSiteFromUrl(window.location.href);
      
      if (site) {
        // Wait a short moment for any animations or content to fully appear
        setTimeout(() => scanPage(site), 1000);
      }
    }
  });
  
  // Start observing the document
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: false,
    characterData: false
  });
  
  console.log('SpinVault: DOM observer started for automatic detection');
}

// Main function to scan current page based on site
async function scanPage(site) {
  console.log(`SpinVault: Scanning ${site} page for rewards...`);
  
  try {
    // Clean existing page content to avoid code snippets
    try {
      // Remove script code blocks that might be showing in the DOM
      const scriptDisplays = document.querySelectorAll('pre, code, [class*="code"], [class*="script"]');
      for (const element of scriptDisplays) {
        // Don't actually remove from DOM, just mark to be ignored
        element.setAttribute('data-spinvault-ignore', 'true');
      }
    } catch (err) {
      console.error('SpinVault: Error cleaning page before scan:', err);
    }
    
    // Start with universal text node scanning method (most reliable across all sites)
    console.log(`SpinVault: Scanning ${site} using universal text node method`);
    const textNodeRewards = await scanForRewardsUsingTextNodes(site);
    let rewards = [...textNodeRewards]; 
    console.log(`SpinVault: Found ${textNodeRewards.length} rewards using text node scan`);
    
    // Then use site-specific scanners as a supplement
    console.log(`SpinVault: Using site-specific scanner for ${site}`);
    let siteSpecificRewards = [];
    
    // Select the appropriate scanning function based on site
    switch (site) {
      case 'Bet365':
        siteSpecificRewards = await scanBet365();
        break;
      case 'Paddy Power':
        siteSpecificRewards = await scanPaddyPower();
        break;
      case 'Sky Bet':
        siteSpecificRewards = await scanSkyBet();
        break;
      case 'William Hill':
        siteSpecificRewards = await scanWilliamHill();
        break;
      case 'Ladbrokes':
        siteSpecificRewards = await scanLadbrokes();
        break;
      case 'Coral':
        siteSpecificRewards = await scanCoral();
        break;
      case 'Betfred':
        siteSpecificRewards = await scanBetfred();
        break;
      case '888Casino':
      case '888Sport':
        siteSpecificRewards = await scan888();
        break;
      case 'Mecca Bingo':
        siteSpecificRewards = await scanMeccaBingo();
        break;
      case 'Heart Bingo':
        siteSpecificRewards = await scanHeartBingo();
        break;
      default:
        siteSpecificRewards = await scanGeneric();
    }
    
    // Add site-specific rewards to our existing list
    rewards = rewards.concat(siteSpecificRewards);
    
    // Remove duplicates by normalizing titles
    const uniqueRewards = [];
    const seenTitles = new Set();
    
    for (const reward of rewards) {
      const normalizedTitle = reward.reward.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!seenTitles.has(normalizedTitle)) {
        seenTitles.add(normalizedTitle);
        uniqueRewards.push(reward);
      }
    }
    
    // Update our rewards array to the deduplicated list
    rewards = uniqueRewards;
    
    console.log(`SpinVault: Found ${rewards.length} total rewards on ${site} after combining methods`);
    
    return {
      success: true,
      rewards,
      site,
      message: `Found ${rewards.length} rewards on ${site} using combined scanning methods`
    };
  } catch (error) {
    console.error(`SpinVault: Error scanning ${site}:`, error);
    return {
      success: false,
      error: error.message,
      site
    };
  }
}

// Extract text content from elements safely
function extractText(elements) {
  if (!elements || elements.length === 0) return [];
  
  return Array.from(elements).map(el => {
    try {
      return el.textContent.trim();
    } catch {
      return '';
    }
  }).filter(text => text.length > 0);
}

// Universal text node scanning method (works great across all sites)
async function scanForRewardsUsingTextNodes(siteName) {
  console.log(`SpinVault: Scanning ${siteName} using text node search`);
  const rewards = [];
  
  try {
    // Define keywords that indicate promotions across ALL gambling sites
    const promoKeywords = [
      'free bet', 'free spins', 'bonus', 'offer', 'promotion', 'promo',
      'money back', 'cash back', 'enhanced odds', 'price boost', 'bet boost',
      'welcome offer', 'new customer', 'sign up offer', 'sign-up offer',
      'extra places', 'cash out', 'best odds', 'guaranteed', 'acca',
      'free £', 'free €', 'get £', 'get €', 'bet £', 'bet €'
    ];
    
    // Track processed nodes to avoid duplicates
    const processedNodes = new Set();
    
    // Search for each keyword in the document
    for (const keyword of promoKeywords) {
      try {
        console.log(`SpinVault: Searching for keyword "${keyword}" in ${siteName}`);
        
        // Create a text node iterator to find all text containing the keyword
        const iterator = document.createNodeIterator(
          document.body,
          NodeFilter.SHOW_TEXT,
          { acceptNode: node => {
              const text = (node.textContent || '').toLowerCase();
              return text.includes(keyword.toLowerCase()) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
            }
          }
        );
        
        let textNode;
        let matchesFound = 0;
        
        // Iterate through all matching text nodes
        while ((textNode = iterator.nextNode())) {
          try {
            // Skip if we already processed this node
            if (processedNodes.has(textNode)) continue;
            processedNodes.add(textNode);
            
            // Skip if node is marked to be ignored
            const parent = findParentElement(textNode);
            if (parent && parent.getAttribute('data-spinvault-ignore') === 'true') {
              continue;
            }
            
            // Skip nodes that are part of scripts, code blocks, or other irrelevant elements
            if (isInIrrelevantElement(textNode)) {
              continue;
            }
            
            const text = textNode.textContent.trim();
            if (text.length < 10) continue; // Too short to be useful
            
            matchesFound++;
            
            // Get more context by finding the parent element with meaningful content
            const contextElement = findContextElement(textNode);
            let contextText = contextElement ? contextElement.textContent.trim() : text;
            
            // Limit context text length
            if (contextText.length > 200) {
              contextText = contextText.substring(0, 200) + '...';
            }
            
            // Try to extract a better title from headings or emphasized text near this node
            let title = '';
            if (contextElement) {
              const heading = contextElement.querySelector('h1, h2, h3, h4, h5, h6, strong, b, em, [class*="title"]');
              if (heading) {
                title = heading.textContent.trim();
              }
            }
            
            // Use the text node content if we couldn't find a better title
            if (!title || title.length < 5) {
              title = text.length > 100 ? text.substring(0, 100) + '...' : text;
            }
            
            // Add the reward
            rewards.push({
              reward: title,
              notes: contextText,
              site: siteName,
              url: window.location.href,
              category: 'FREE_BET', // Default category
              detectedAt: new Date().toISOString()
            });
          } catch (err) {
            console.error(`SpinVault: Error processing text node match for "${keyword}":`, err);
          }
        }
        
        console.log(`SpinVault: Found ${matchesFound} matches for keyword "${keyword}"`);
      } catch (err) {
        console.error(`SpinVault: Error searching for keyword "${keyword}":`, err);
      }
    }
    
    // Remove duplicate rewards by normalizing and comparing titles
    const uniqueRewards = [];
    const seenTitles = new Set();
    
    for (const reward of rewards) {
      const normalizedTitle = reward.reward.toLowerCase().replace(/\s+/g, ' ').trim();
      if (!seenTitles.has(normalizedTitle)) {
        seenTitles.add(normalizedTitle);
        uniqueRewards.push(reward);
      }
    }
    
    console.log(`SpinVault: Found ${uniqueRewards.length} unique rewards using text node scanning`);
    return uniqueRewards;
  } catch (err) {
    console.error(`SpinVault: Error in text node scanning:`, err);
    return [];
  }
}

// Helper function to find the parent element of a text node
function findParentElement(node) {
  let parent = node.parentNode;
  while (parent && parent.nodeType !== Node.ELEMENT_NODE) {
    parent = parent.parentNode;
  }
  return parent;
}

// Helper function to check if a node is inside an irrelevant element
function isInIrrelevantElement(node) {
  const parent = findParentElement(node);
  if (!parent) return false;
  
  // Skip text in scripts, styles, and other irrelevant elements
  const tagName = parent.tagName.toLowerCase();
  if (['script', 'style', 'noscript', 'iframe', 'code', 'pre'].includes(tagName)) {
    return true;
  }
  
  // Skip hidden elements
  const style = window.getComputedStyle(parent);
  if (style.display === 'none' || style.visibility === 'hidden') {
    return true;
  }
  
  // Skip elements with classes indicating they're not relevant
  const classList = parent.className.toLowerCase();
  const irrelevantClasses = ['code', 'script', 'json', 'hidden', 'template'];
  if (irrelevantClasses.some(cls => classList.includes(cls))) {
    return true;
  }
  
  return false;
}

// Helper function to find a meaningful context element around a text node
function findContextElement(node) {
  // Start with the parent element
  let element = findParentElement(node);
  if (!element) return null;
  
  // If the parent is very small, try to find a larger container
  const minContextLength = 20;
  
  // Check if this element has enough context
  let contextText = element.textContent.trim();
  if (contextText.length >= minContextLength) {
    return element;
  }
  
  // If not, look for ancestors with more context
  let ancestor = element.parentElement;
  const maxAncestorLevels = 3; // Don't go too far up
  let level = 0;
  
  while (ancestor && level < maxAncestorLevels) {
    contextText = ancestor.textContent.trim();
    
    // If this ancestor has enough context but not too much
    if (contextText.length >= minContextLength && contextText.length < 1000) {
      return ancestor;
    }
    
    ancestor = ancestor.parentElement;
    level++;
  }
  
  // Fall back to the original element if we couldn't find better context
  return element;
}

// Generic scanner for any gambling site
async function scanGeneric() {
  console.log('SpinVault: Running generic scan...');
  const rewards = [];
  
  try {
    // CRITICAL FIX: First, let's filter out elements that might show JavaScript code
    // These are the elements showing up incorrectly in Paddy Power
    try {
      const codeElements = document.querySelectorAll('script, pre, code, [class*="code"], [class*="json"]');
      for (const element of codeElements) {
        element.setAttribute('data-spinvault-ignore', 'true');
      }
      
      // Also mark any elements containing typical JavaScript syntax
      const allElements = document.querySelectorAll('*');
      for (const element of allElements) {
        try {
          const text = element.textContent || '';
          if ((text.includes('function(') || text.includes('var ') || 
               text.includes('{') && text.includes('}') || 
               text.includes('window.') || text.includes('document.') ||
               text.includes('push(') || text.includes('.css')) && 
              text.length > 30) {
            element.setAttribute('data-spinvault-ignore', 'true');
          }
        } catch (err) {
          // Ignore errors when checking elements
        }
      }
    } catch (err) {
      console.error('SpinVault: Error filtering code elements:', err);
    }
    
    // Enhanced detection approach:
    // 1. Look for elements with promotion-related classes or IDs
    // 2. Look for text containing promotion keywords
    // 3. Look for images with promotion-related src attributes
    // 4. Scan all headings and strong text elements for keywords
    
    // Define keywords for promotions and free bets
    const promoKeywords = [
      'bonus', 'free bet', 'offer', 'promotion', 'reward', 'free spin', 
      'cash back', 'money back', 'free to play', 'deposit match', 'acca', 
      'enhanced odds', 'price boost', 'odds boost', 'accumulator',
      'welcome', 'new customer', 'sign up', 'register'
    ];
    
    // First approach: Collect all promotion-like elements by selectors
    console.log('Scanning for promotion elements by selector...');
    
    const promotionSelectors = [
      '[class*="promo"]', '[class*="offer"]', '[class*="bonus"]',
      '[id*="promo"]', '[id*="offer"]', '[id*="bonus"]',
      'a[href*="promo"]', 'a[href*="offer"]', 'a[href*="bonus"]', 'a[href*="promotion"]',
      '[class*="promotion"]', '[class*="deal"]', '[class*="special"]',
      'img[src*="promo"]', 'img[src*="offer"]', 'img[alt*="promotion"]',
      '[data-test*="promo"]', '[data-testid*="promo"]',
      '.offers', '.promotions', '.bonuses', '.free-bets', '.rewards'
    ];
    
    const compoundSelector = promotionSelectors.join(', ');
    let promotionElements = Array.from(document.querySelectorAll(compoundSelector));
    
    console.log(`Found ${promotionElements.length} potential promotion elements by selector`);
    
    // Second approach: Scan heading text for keywords
    console.log('Scanning headings and strong text for promotion keywords...');
    
    const textElements = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6, strong, b, [class*="title"], [class*="heading"]'));
    
    console.log(`Found ${textElements.length} text elements to scan for keywords`);
    
    // Add text elements containing keywords to our promotion elements list
    for (const element of textElements) {
      try {
        const text = element.textContent.trim().toLowerCase();
        if (text.length > 5 && promoKeywords.some(keyword => text.includes(keyword.toLowerCase()))) {
          promotionElements.push(element);
        }
      } catch (err) {
        console.error('Error processing text element:', err);
      }
    }
    
    // Remove duplicate elements
    promotionElements = [...new Set(promotionElements)];
    
    console.log(`Found ${promotionElements.length} promotion elements in total after combining and deduplicating`);
    
    // Process each promotion element
    for (const element of promotionElements) {
      try {
        const text = element.textContent.trim();
        
        // Skip if text is too short or empty
        if (text.length < 5) {
          continue;
        }
        
        // Get more context from parent element if the text is very short
        let fullText = text;
        if (text.length < 20 && element.parentElement) {
          fullText = element.parentElement.textContent.trim();
          // Still skip if we can't get enough text
          if (fullText.length < 10) {
            continue;
          }
        }
        
        // Try to find description or details
        let description = '';
        let descriptionElement = null;
        
        // First look for nearby paragraphs
        if (element.nextElementSibling && element.nextElementSibling.tagName === 'P') {
          descriptionElement = element.nextElementSibling;
        } else {
          descriptionElement = element.querySelector('p, [class*="description"], [class*="content"], [class*="text"]');
        }
        
        if (descriptionElement) {
          description = descriptionElement.textContent.trim();
        }
        
        // Try to determine expiration
        let expiryText = '';
        const expiryRegex = /(\d{1,2}(st|nd|rd|th)?\s+\w+\s+\d{4})|(\d{1,2}\/\d{1,2}\/\d{2,4})|until|before|ends/i;
        
        // Look for expiry date in text
        if (expiryRegex.test(fullText)) {
          const match = fullText.match(new RegExp(`.{0,20}${expiryRegex.source}.{0,20}`, 'i'));
          if (match) {
            expiryText = match[0];
          }
        }
        
        // Or look for elements specifically about expiry
        const expiryElement = element.querySelector('[class*="expiry"],[class*="date"],[class*="time"],[class*="valid"]');
        if (expiryElement) {
          expiryText = expiryElement.textContent.trim();
        }
        
        // Extract a reasonable title
        let title = text;
        if (text.length > 100) {
          // If text is long, look for a heading inside it
          const headingElement = element.querySelector('h1, h2, h3, h4, h5, h6, [class*="title"], [class*="heading"]');
          if (headingElement) {
            title = headingElement.textContent.trim();
          } else {
            // Or just take first sentence or first part
            const sentences = text.split(/[.!?]/);
            if (sentences.length > 1 && sentences[0].length > 10) {
              title = sentences[0].trim();
            } else {
              title = text.substring(0, 100) + '...';
            }
          }
        }
        
        // Determine if this is likely a promotion
        const isLikelyPromotion = promoKeywords.some(keyword => 
          fullText.toLowerCase().includes(keyword.toLowerCase())
        );
        
        if (isLikelyPromotion) {
          // Create reward object
          rewards.push({
            reward: title,
            notes: description || fullText,
            expiryText: expiryText,
            site: window.location.hostname.replace('www.', ''),
            url: window.location.href,
            category: 'FREE_BET',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing promotion element:', err);
      }
    }
    
    console.log(`Found ${rewards.length} raw rewards before deduplication`);
    
    // Deduplicate rewards by title
    const uniqueRewards = [];
    const seen = new Set();
    
    for (const reward of rewards) {
      const normalizedTitle = reward.reward.toLowerCase().replace(/\s+/g, ' ').trim();
      if (normalizedTitle && !seen.has(normalizedTitle)) {
        seen.add(normalizedTitle);
        uniqueRewards.push(reward);
      }
    }
    
    console.log(`Found ${uniqueRewards.length} unique rewards after filtering`);
    return uniqueRewards;
  } catch (error) {
    console.error('Error in generic scan:', error);
    return [];
  }
}

// Bet365 specific scanner
async function scanBet365() {
  console.log('Scanning Bet365...');
  const rewards = [];
  
  try {
    // Check for offers in promotions area
    const promoElements = document.querySelectorAll('.promotion-item, .promo-pod, [class*="OfferContainer"]');
    
    console.log(`Found ${promoElements.length} promo elements on Bet365`);
    
    for (const element of promoElements) {
      try {
        // Extract title
        let title = '';
        const titleElement = element.querySelector('h3, h4, [class*="Title"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          title = element.textContent.trim().substring(0, 100);
        }
        
        // Extract description
        let description = '';
        const descElement = element.querySelector('p, [class*="Description"]');
        if (descElement) {
          description = descElement.textContent.trim();
        }
        
        // Add to rewards if title exists
        if (title) {
          rewards.push({
            reward: title,
            notes: description,
            site: 'Bet365',
            url: window.location.href,
            category: 'FREE_BET',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing Bet365 promo:', err);
      }
    }
    
    // Check for My Offers section if logged in
    const myOfferElements = document.querySelectorAll('[class*="MyOffer"], [id*="myoffer"]');
    console.log(`Found ${myOfferElements.length} personal offer elements on Bet365`);
    
    for (const element of myOfferElements) {
      try {
        const text = element.textContent.trim();
        
        if (text.length > 10) {
          rewards.push({
            reward: text.length > 100 ? text.substring(0, 100) + '...' : text,
            notes: 'Personal offer detected',
            site: 'Bet365',
            url: window.location.href,
            category: 'PERSONAL_OFFER',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing Bet365 personal offer:', err);
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('Error scanning Bet365:', error);
    return [];
  }
}

// Betfred specific scanner
async function scanBetfred() {
  console.log('SpinVault: Scanning Betfred...');
  const rewards = [];
  
  try {
    // Look for promotion elements
    const promoElements = document.querySelectorAll('.bf-promo, .promotion-container, .offers-section, [class*="promo"], .promotion-tile, .promo-wrapper');
    console.log(`SpinVault: Found ${promoElements.length} promo elements on Betfred`);
    
    // Process each promotion element
    for (const element of promoElements) {
      try {
        // Get title
        let title = '';
        const titleElement = element.querySelector('h1, h2, h3, h4, h5, h6, [class*="title"], [class*="heading"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          // Use first sentence as title or first 80 chars
          const text = element.textContent.trim();
          const firstSentence = text.split(/[.!?](\s|$)/)[0];
          title = firstSentence.length > 80 ? firstSentence.substring(0, 77) + '...' : firstSentence;
        }
        
        // Get description
        let description = '';
        const descriptionElement = element.querySelector('p, [class*="desc"], [class*="content"], [class*="text"]');
        if (descriptionElement && descriptionElement !== titleElement) {
          description = descriptionElement.textContent.trim();
        }
        
        // Get expiry date if available
        let expiryDate = '';
        const expiryRegex = /([0-9]{1,2}(st|nd|rd|th)?\s+\w+\s+20[0-9]{2})|([0-9]{1,2}\/[0-9]{1,2}\/[0-9]{2,4})|until|before|ends|valid/i;
        
        if (expiryRegex.test(element.textContent)) {
          const match = element.textContent.match(new RegExp(`.{0,30}${expiryRegex.source}.{0,30}`, 'i'));
          if (match) {
            expiryDate = match[0].trim();
          }
        }
        
        // Determine category based on keywords
        let category = 'FREE_BET';
        const lowerText = element.textContent.toLowerCase();
        
        if (lowerText.includes('double delight') || lowerText.includes('hat-trick heaven')) {
          category = 'ODDS_BOOST';
        } else if (lowerText.includes('acca')) {
          category = 'ACCA_INSURANCE';
        } else if (lowerText.includes('casino') || lowerText.includes('spin')) {
          category = 'FREE_SPIN';
        }
        
        // Add reward if we have a meaningful title
        if (title && title.length > 5) {
          rewards.push({
            reward: title,
            notes: description,
            site: 'Betfred',
            url: window.location.href,
            category,
            expiryText: expiryDate,
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('SpinVault: Error processing Betfred promo:', err);
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('SpinVault: Error scanning Betfred:', error);
    return [];
  }
}

// 888 Casino and 888 Sport scanner
async function scan888() {
  console.log('SpinVault: Scanning 888 site...');
  const rewards = [];
  
  try {
    // Check if we're on Casino or Sport
    const is888Casino = window.location.hostname.includes('casino');
    const siteName = is888Casino ? '888Casino' : '888Sport';
    
    // Look for promotion elements with common 888 selectors
    const promoElements = document.querySelectorAll('.promotions-grid, .offers-list, .promo-cards, .promotion-tile, [class*="promo"], [id*="promotion"], .bonus-card');
    console.log(`SpinVault: Found ${promoElements.length} promo elements on ${siteName}`);
    
    // Process each promotion element
    for (const element of promoElements) {
      try {
        // Get title
        let title = '';
        const titleElement = element.querySelector('h1, h2, h3, h4, h5, h6, [class*="title"], [class*="name"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          // Try to extract a meaningful title
          const fullText = element.textContent.trim();
          const lines = fullText.split('\n').filter(line => line.trim().length > 0);
          if (lines.length > 0) {
            title = lines[0].trim();
            if (title.length > 100) {
              title = title.substring(0, 97) + '...';
            }
          }
        }
        
        // Get description
        let description = '';
        const descriptionElement = element.querySelector('p, [class*="desc"], [class*="text"], [class*="content"]');
        if (descriptionElement && descriptionElement !== titleElement) {
          description = descriptionElement.textContent.trim();
        }
        
        // Determine category based on content
        let category = 'FREE_BET';
        const lowerText = element.textContent.toLowerCase();
        
        if (is888Casino || lowerText.includes('casino') || lowerText.includes('slot') || lowerText.includes('spin')) {
          category = 'FREE_SPIN';
        } else if (lowerText.includes('cashback') || lowerText.includes('money back')) {
          category = 'CASHBACK';
        } else if (lowerText.includes('deposit') || lowerText.includes('bonus')) {
          category = 'DEPOSIT_BONUS';
        }
        
        // Add reward if we have a meaningful title
        if (title && title.length > 5) {
          rewards.push({
            reward: title,
            notes: description,
            site: siteName,
            url: window.location.href,
            category,
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error(`SpinVault: Error processing ${siteName} promo:`, err);
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('SpinVault: Error scanning 888:', error);
    return [];
  }
}

// Mecca Bingo scanner
async function scanMeccaBingo() {
  console.log('SpinVault: Scanning Mecca Bingo...');
  const rewards = [];
  
  try {
    // Look for promotion elements
    const promoElements = document.querySelectorAll('.promotions-list, .mecca-promos, .offers-container, .promo-tile, [class*="promo"], [class*="offer"]');
    console.log(`SpinVault: Found ${promoElements.length} promo elements on Mecca Bingo`);
    
    // Process each promotion element
    for (const element of promoElements) {
      try {
        // Get title
        let title = '';
        const titleElement = element.querySelector('h1, h2, h3, h4, h5, h6, [class*="title"], [class*="heading"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          const fullText = element.textContent.trim();
          const firstSentence = fullText.split(/[.!?](\s|$)/)[0];
          title = firstSentence.length > 80 ? firstSentence.substring(0, 77) + '...' : firstSentence;
        }
        
        // Get description
        let description = '';
        const descriptionElement = element.querySelector('p, [class*="desc"], [class*="content"]');
        if (descriptionElement && descriptionElement !== titleElement) {
          description = descriptionElement.textContent.trim();
        }
        
        // Determine category based on content
        let category = 'FREE_SPIN';
        const lowerText = element.textContent.toLowerCase();
        
        if (lowerText.includes('free bingo') || lowerText.includes('bingo bonus')) {
          category = 'FREE_GAME';
        } else if (lowerText.includes('deposit') || lowerText.includes('bonus')) {
          category = 'DEPOSIT_BONUS';
        }
        
        // Add reward if we have a meaningful title
        if (title && title.length > 5) {
          rewards.push({
            reward: title,
            notes: description,
            site: 'Mecca Bingo',
            url: window.location.href,
            category,
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('SpinVault: Error processing Mecca Bingo promo:', err);
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('SpinVault: Error scanning Mecca Bingo:', error);
    return [];
  }
}

// Heart Bingo scanner
async function scanHeartBingo() {
  console.log('SpinVault: Scanning Heart Bingo...');
  const rewards = [];
  
  try {
    // Look for promotion elements
    const promoElements = document.querySelectorAll('.promotions-container, .heart-offers, .promo-tiles, .promotion-wrapper, [class*="promotion"], [class*="promo"]');
    console.log(`SpinVault: Found ${promoElements.length} promo elements on Heart Bingo`);
    
    // Process each promotion element
    for (const element of promoElements) {
      try {
        // Get title
        let title = '';
        const titleElement = element.querySelector('h1, h2, h3, h4, h5, h6, [class*="title"], [class*="heading"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          const fullText = element.textContent.trim();
          const firstSentence = fullText.split(/[.!?](\s|$)/)[0];
          title = firstSentence.length > 80 ? firstSentence.substring(0, 77) + '...' : firstSentence;
        }
        
        // Get description
        let description = '';
        const descriptionElement = element.querySelector('p, [class*="desc"], [class*="detail"], [class*="content"]');
        if (descriptionElement && descriptionElement !== titleElement) {
          description = descriptionElement.textContent.trim();
        }
        
        // Determine category based on content
        let category = 'FREE_SPIN';
        const lowerText = element.textContent.toLowerCase();
        
        if (lowerText.includes('free bingo') || lowerText.includes('bingo bonus')) {
          category = 'FREE_GAME';
        } else if (lowerText.includes('jackpot') || lowerText.includes('daily jackpot')) {
          category = 'JACKPOT';
        } else if (lowerText.includes('welcome') || lowerText.includes('new player')) {
          category = 'WELCOME_OFFER';
        }
        
        // Add reward if we have a meaningful title
        if (title && title.length > 5) {
          rewards.push({
            reward: title,
            notes: description,
            site: 'Heart Bingo',
            url: window.location.href,
            category,
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('SpinVault: Error processing Heart Bingo promo:', err);
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('SpinVault: Error scanning Heart Bingo:', error);
    return [];
  }
}

// Paddy Power specific scanner
async function scanPaddyPower() {
  console.log('SpinVault: Scanning Paddy Power...');
  const rewards = [];
  
  try {
    // CRITICAL FIX: First, mark any elements containing JavaScript code to be ignored
    // These are the elements showing up incorrectly in Paddy Power
    try {
      const codeElements = document.querySelectorAll('script, pre, code, [class*="code"], [class*="json"]');
      for (const element of codeElements) {
        element.setAttribute('data-spinvault-ignore', 'true');
      }
      
      // Also filter out any elements containing code-like text
      const allElements = document.querySelectorAll('div, span, p');
      for (const element of allElements) {
        try {
          const text = element.textContent || '';
          if ((text.includes('function(') || text.includes('var ') || 
               text.includes('{') && text.includes('}') || 
               text.includes('window.') || text.includes('document.') ||
               text.includes('push(') || text.includes('.css') || 
               text.includes('JSON.parse') || text.includes('createElement')) && 
              text.length > 30) {
            element.setAttribute('data-spinvault-ignore', 'true');
          }
        } catch (err) {
          // Ignore errors when checking elements
        }
      }
    } catch (err) {
      console.error('SpinVault: Error filtering code elements:', err);
    }
    
    // First approach: Direct text scraping from whole page
    // This is a fallback that works on most pages regardless of structure
    const allTextElements = document.querySelectorAll('h1, h2, h3, h4, h5, strong, b, [class*="title"], [class*="heading"]');
    console.log(`SpinVault: Found ${allTextElements.length} text elements to analyze`);
    
    const keyPhrases = ['free bet', 'free to play', 'free spin', 'acca', 'promo', 'offer', 'bonus', 'power price', 'money back'];
    
    for (const element of allTextElements) {
      try {
        const text = element.textContent.trim();
        if (text.length > 10 && keyPhrases.some(phrase => text.toLowerCase().includes(phrase))) {
          console.log('Found potential promotion:', text);
          
          // Get description - look at nearby elements
          let description = '';
          let nextElement = element.nextElementSibling;
          if (nextElement && nextElement.tagName.match(/^(P|DIV|SPAN)$/i)) {
            description = nextElement.textContent.trim();
          }
          
          rewards.push({
            reward: text,
            notes: description,
            site: 'Paddy Power',
            url: window.location.href,
            category: 'FREE_BET',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing Paddy Power text element:', err);
      }
    }
    
    // Second approach: Look for promotional banners and cards
    console.log('Trying to find promotion cards...');
    const promoSelectors = [
      '.promotion-card', '.promo-card', '.offers-card', 
      '[data-testid*="promotion"]', 'img[src*="promo"]',
      '[class*="promo"]', '[class*="offer"]', '[class*="promotion"]',
      '[id*="promo"]', '[id*="offer"]', '[id*="promotion"]'
    ];
    
    const compoundSelector = promoSelectors.join(', ');
    const promoElements = document.querySelectorAll(compoundSelector);
    
    console.log(`Found ${promoElements.length} promo elements on Paddy Power using compound selector`);
    
    for (const element of promoElements) {
      try {
        // Get title
        let title = '';
        const titleElement = element.querySelector('h3, h4, [class*="title"], [class*="header"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          title = element.textContent.trim().substring(0, 100);
        }
        
        // Get description
        let description = '';
        const descElement = element.querySelector('p, [class*="description"], [class*="body"]');
        if (descElement) {
          description = descElement.textContent.trim();
        }
        
        // Add to rewards if has meaningful title
        if (title && title.length > 5) {
          rewards.push({
            reward: title,
            notes: description,
            site: 'Paddy Power',
            url: window.location.href,
            category: 'FREE_BET',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing Paddy Power promo:', err);
      }
    }
    
    // Third approach: Look for specific promotion sections in URL
    if (window.location.href.includes('/promotions') || window.location.href.includes('/promos')) {
      console.log('On promotions page, scanning all content sections');
      
      // On promotions page, grab all major sections
      const contentSections = document.querySelectorAll('.section, .card, .tile, article, [class*="card"], [class*="tile"]');
      
      for (const section of contentSections) {
        try {
          const text = section.textContent.trim();
          if (text.length > 10 && text.length < 500) { // Reasonable size for a promotion
            const lines = text.split('\n').filter(line => line.trim().length > 0);
            const title = lines[0] || text.substring(0, 50);
            
            rewards.push({
              reward: title,
              notes: text.length > 200 ? text.substring(0, 200) + '...' : text,
              site: 'Paddy Power',
              url: window.location.href,
              category: 'FREE_BET',
              detectedAt: new Date().toISOString()
            });
          }
        } catch (err) {
          console.error('Error processing promotion section:', err);
        }
      }
    }
    
    // Check My Account section for personal offers if logged in
    if (document.querySelector('[data-testid="account-dropdown"], [class*="accountMenu"]')) {
      console.log('User appears to be logged in, checking for personal offers');
      
      const personalOfferElements = document.querySelectorAll(
        '[data-testid*="message"], [class*="accountMessage"], [class*="notification"]'
      );
      
      for (const element of personalOfferElements) {
        try {
          const text = element.textContent.trim();
          
          if (text.length > 10 && (
            text.toLowerCase().includes('bet') || 
            text.toLowerCase().includes('offer') || 
            text.toLowerCase().includes('bonus')
          )) {
            rewards.push({
              reward: text.length > 100 ? text.substring(0, 100) + '...' : text,
              notes: 'Personal offer detected',
              site: 'Paddy Power',
              url: window.location.href,
              category: 'PERSONAL_OFFER',
              detectedAt: new Date().toISOString()
            });
          }
        } catch (err) {
          console.error('Error processing Paddy Power personal offer:', err);
        }
      }
    }
    
    // Remove duplicates
    const uniqueRewards = [];
    const seen = new Set();
    
    for (const reward of rewards) {
      const key = reward.reward.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        uniqueRewards.push(reward);
      }
    }
    
    console.log(`Found ${uniqueRewards.length} unique rewards after filtering`);
    return uniqueRewards;
  } catch (error) {
    console.error('Error scanning Paddy Power:', error);
    return [];
  }
}

// Sky Bet specific scanner
async function scanSkyBet() {
  console.log('Scanning Sky Bet...');
  const rewards = [];
  
  try {
    // Look for promotional sections
    const promoElements = document.querySelectorAll(
      '.promo, .promotion, [data-testid*="promo"], [data-testid*="offer"]'
    );
    
    console.log(`Found ${promoElements.length} promo elements on Sky Bet`);
    
    for (const element of promoElements) {
      try {
        // Get title
        let title = '';
        const titleElement = element.querySelector('h2, h3, h4, [class*="Title"], [class*="Headline"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          title = element.textContent.trim().substring(0, 100);
        }
        
        // Get description
        let description = '';
        const descElement = element.querySelector('p, [class*="Description"], [class*="Body"]');
        if (descElement) {
          description = descElement.textContent.trim();
        }
        
        // Add to rewards
        if (title && title.length > 5) {
          rewards.push({
            reward: title,
            notes: description,
            site: 'Sky Bet',
            url: window.location.href,
            category: 'FREE_BET',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing Sky Bet promo:', err);
      }
    }
    
    // Check for free bet balance
    const balanceElement = document.querySelector(
      '[data-testid="free-bet-balance"], [class*="freebet"], [class*="FreeBet"]'
    );
    
    if (balanceElement) {
      const text = balanceElement.textContent.trim();
      
      if (text && text.match(/\d+/) && !text.includes('£0') && !text.includes('0.00')) {
        rewards.push({
          reward: 'Free Bet Balance: ' + text,
          notes: 'Current free bet balance',
          site: 'Sky Bet',
          url: window.location.href,
          category: 'FREE_BET',
          detectedAt: new Date().toISOString()
        });
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('Error scanning Sky Bet:', error);
    return [];
  }
}

// William Hill specific scanner
async function scanWilliamHill() {
  console.log('SpinVault: Scanning William Hill...');
  const rewards = [];
  
  try {
    // FIRST APPROACH: Target promotions on homepage banners and carousels
    console.log('SpinVault: Scanning William Hill homepage banners and carousels...');
    
    // More aggressive selectors for William Hill
    const promoElements = document.querySelectorAll(
      // Banner and promotion selectors
      '[data-testid*="promotion"], [class*="promotion"], [class*="offer"], .promo-card, .offer-card, ' +
      // Hero and carousel selectors  
      '.hero-banner, .home-banner, .carousel, .carousel-item, [class*="carousel"], [class*="slider"], ' +
      // Broader selectors to catch all promotional content
      '[class*="banner"], [class*="card"], [class*="tile"], [class*="highlight"], img[alt*="offer"], img[alt*="free"]'
    );
    
    console.log(`SpinVault: Found ${promoElements.length} promo elements on William Hill`);
    
    // SECOND APPROACH: Look for specific promotion keywords in the page
    console.log('SpinVault: Searching for offer text on William Hill...');
    
    // William Hill specific keywords
    const whKeywords = ['free spins', 'get £', 'get €', 'bet £', 'bet €', 'welcome offer', 'new customer', 'money back'];
    
    // Check for elements containing these keywords
    for (const keyword of whKeywords) {
      try {
        // Find all text nodes containing the keyword
        const iterator = document.createNodeIterator(
          document.body,
          NodeFilter.SHOW_TEXT,
          { acceptNode: node => node.textContent.toLowerCase().includes(keyword) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT }
        );
        
        let textNode;
        while (textNode = iterator.nextNode()) {
          try {
            // Get the parent element
            const element = textNode.parentElement;
            
            // Skip if element is script, style, etc.
            if (!element || element.nodeName === 'SCRIPT' || element.nodeName === 'STYLE' || 
                element.nodeName === 'NOSCRIPT' || element.hasAttribute('data-spinvault-ignore')) {
              continue;
            }
            
            // Get text content
            const text = element.textContent.trim();
            
            // Skip if too short or looks like code
            if (text.length < 15 || text.includes('function(') || text.includes('var ') || 
                text.includes('{') || text.includes('script') || text.includes('push(')) {
              continue;
            }
            
            // Create a title
            let title = text;
            if (text.length > 100) {
              const firstLine = text.split('\n')[0].trim();
              title = firstLine.length > 0 ? firstLine : text.substring(0, 97) + '...';
            }
            
            // Add reward
            rewards.push({
              reward: title,
              notes: text !== title ? text : '',
              site: 'William Hill',
              url: window.location.href,
              category: text.toLowerCase().includes('spin') ? 'FREE_SPIN' : 'FREE_BET',
              detectedAt: new Date().toISOString()
            });
          } catch (err) {
            console.error('SpinVault: Error processing William Hill text node:', err);
          }
        }
      } catch (err) {
        console.error(`SpinVault: Error searching for keyword "${keyword}":`, err);
      }
    }
    
    // Process the promo elements found earlier
    for (const element of promoElements) {
      try {
        // Skip elements that have been marked to ignore or script-like elements
        if (element.hasAttribute('data-spinvault-ignore') || 
            element.nodeName === 'SCRIPT' || 
            element.nodeName === 'STYLE') {
          continue;
        }
        
        // Get title
        let title = '';
        const titleElement = element.querySelector('h1, h2, h3, h4, h5, h6, [class*="title"], [class*="heading"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          const text = element.textContent.trim();
          
          // Skip if it looks like code
          if (text.includes('function(') || text.includes('var ') || 
              text.includes('{') || text.includes('push(')) {
            continue;
          }
          
          // Use first line or first 100 chars
          const firstLine = text.split('\n')[0].trim();
          title = firstLine.length > 10 ? firstLine : text.substring(0, Math.min(100, text.length));
        }
        
        // Skip empty or short titles
        if (!title || title.length < 10) {
          continue;
        }
        
        // Get description
        let description = '';
        const descElement = element.querySelector('p, [class*="description"], [class*="content"], [class*="text"]');
        if (descElement && descElement !== titleElement) {
          description = descElement.textContent.trim();
        }
        
        // Determine category based on content
        let category = 'FREE_BET';
        const allText = (title + ' ' + description).toLowerCase();
        
        if (allText.includes('free spin') || allText.includes('slot') || allText.includes('vegas') || allText.includes('casino')) {
          category = 'FREE_SPIN';
        } else if (allText.includes('acca') || allText.includes('accumulator')) {
          category = 'ACCA_INSURANCE';
        } else if (allText.includes('enhanced') || allText.includes('boost') || allText.includes('price')) {
          category = 'ODDS_BOOST';
        }
        
        // Add to rewards if title seems valid
        rewards.push({
          reward: title,
          notes: description,
          site: 'William Hill',
          url: window.location.href,
          category,
          detectedAt: new Date().toISOString()
        });
      } catch (err) {
        console.error('SpinVault: Error processing William Hill promo:', err);
      }
    }
    
    // Check for free bet messages in account area
    const accountElements = document.querySelectorAll(
      '[class*="account"], [class*="balance"], [class*="bonus"]'
    );
    
    for (const element of accountElements) {
      try {
        const text = element.textContent.trim();
        
        if (text.toLowerCase().includes('free') && text.toLowerCase().includes('bet')) {
          rewards.push({
            reward: text.length > 100 ? text.substring(0, 100) + '...' : text,
            notes: 'Personal account offer',
            site: 'William Hill',
            url: window.location.href,
            category: 'PERSONAL_OFFER',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing William Hill account element:', err);
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('Error scanning William Hill:', error);
    return [];
  }
}

// Ladbrokes specific scanner
async function scanLadbrokes() {
  console.log('Scanning Ladbrokes...');
  const rewards = [];
  
  try {
    // Look for promotional elements
    const promoElements = document.querySelectorAll(
      '.promo-card, .promotion, [data-test-id*="promo"], [class*="PromotionCard"]'
    );
    
    console.log(`Found ${promoElements.length} promo elements on Ladbrokes`);
    
    for (const element of promoElements) {
      try {
        // Get title
        let title = '';
        const titleElement = element.querySelector('h3, h4, [class*="Title"], [class*="Heading"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          title = element.textContent.trim().substring(0, 100);
        }
        
        // Get description
        let description = '';
        const descElement = element.querySelector('p, [class*="Description"], [class*="Content"]');
        if (descElement) {
          description = descElement.textContent.trim();
        }
        
        // Add to rewards
        if (title && title.length > 5) {
          rewards.push({
            reward: title,
            notes: description,
            site: 'Ladbrokes',
            url: window.location.href,
            category: 'FREE_BET',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing Ladbrokes promo:', err);
      }
    }
    
    // Look for balance sections with free bets
    const balanceElements = document.querySelectorAll(
      '[class*="Balance"], [class*="Wallet"], [class*="FreeBet"]'
    );
    
    for (const element of balanceElements) {
      try {
        const text = element.textContent.trim();
        
        if (text.toLowerCase().includes('free') && text.match(/\d+/)) {
          rewards.push({
            reward: 'Free Bet Balance Found',
            notes: text,
            site: 'Ladbrokes',
            url: window.location.href,
            category: 'FREE_BET',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing Ladbrokes balance element:', err);
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('Error scanning Ladbrokes:', error);
    return [];
  }
}

// Coral specific scanner
async function scanCoral() {
  console.log('Scanning Coral...');
  const rewards = [];
  
  try {
    // Look for promotional elements (Coral is owned by the same company as Ladbrokes, so similar structure)
    const promoElements = document.querySelectorAll(
      '.promo-card, .promotion, [data-test-id*="promo"], [class*="PromotionCard"]'
    );
    
    console.log(`Found ${promoElements.length} promo elements on Coral`);
    
    for (const element of promoElements) {
      try {
        // Get title
        let title = '';
        const titleElement = element.querySelector('h3, h4, [class*="Title"], [class*="Heading"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          title = element.textContent.trim().substring(0, 100);
        }
        
        // Get description
        let description = '';
        const descElement = element.querySelector('p, [class*="Description"], [class*="Content"]');
        if (descElement) {
          description = descElement.textContent.trim();
        }
        
        // Add to rewards
        if (title && title.length > 5) {
          rewards.push({
            reward: title,
            notes: description,
            site: 'Coral',
            url: window.location.href,
            category: 'FREE_BET',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing Coral promo:', err);
      }
    }
    
    // Look for balance sections with free bets
    const balanceElements = document.querySelectorAll(
      '[class*="Balance"], [class*="Wallet"], [class*="FreeBet"]'
    );
    
    for (const element of balanceElements) {
      try {
        const text = element.textContent.trim();
        
        if (text.toLowerCase().includes('free') && text.match(/\d+/)) {
          rewards.push({
            reward: 'Free Bet Balance Found',
            notes: text,
            site: 'Coral',
            url: window.location.href,
            category: 'FREE_BET',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing Coral balance element:', err);
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('Error scanning Coral:', error);
    return [];
  }
}