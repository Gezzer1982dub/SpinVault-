async function scanWilliamHill() {
  console.log('SpinVault: Scanning William Hill...');
  const rewards = [];
  
  try {
    // FIRST APPROACH: Target promotions on homepage banners and carousels
    console.log('SpinVault: Scanning William Hill homepage banners and carousels...');
    
    // More aggressive selectors for William Hill
    const promoElements = document.querySelectorAll(
      // Banner and promotion selectors
      '[data-testid*="promotion"], [class*="promotion"], [class*="offer"], .promo-card, .offer-card, ' +
      // Hero and carousel selectors  
      '.hero-banner, .home-banner, .carousel, .carousel-item, [class*="carousel"], [class*="slider"], ' +
      // Broader selectors to catch all promotional content
      '[class*="banner"], [class*="card"], [class*="tile"], [class*="highlight"], img[alt*="offer"], img[alt*="free"]'
    );
    
    console.log(`SpinVault: Found ${promoElements.length} promo elements on William Hill`);
    
    // SECOND APPROACH: Look for specific promotion keywords in the page
    console.log('SpinVault: Searching for offer text on William Hill...');
    
    // William Hill specific keywords
    const whKeywords = ['free spins', 'get £', 'get €', 'bet £', 'bet €', 'welcome offer', 'new customer', 'money back'];
    
    // Check for elements containing these keywords
    for (const keyword of whKeywords) {
      try {
        // Find all text nodes containing the keyword
        const iterator = document.createNodeIterator(
          document.body,
          NodeFilter.SHOW_TEXT,
          { acceptNode: node => node.textContent.toLowerCase().includes(keyword) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT }
        );
        
        let textNode;
        while (textNode = iterator.nextNode()) {
          try {
            // Get the parent element
            const element = textNode.parentElement;
            
            // Skip if element is script, style, etc.
            if (!element || element.nodeName === 'SCRIPT' || element.nodeName === 'STYLE' || 
                element.nodeName === 'NOSCRIPT' || element.hasAttribute('data-spinvault-ignore')) {
              continue;
            }
            
            // Get text content
            const text = element.textContent.trim();
            
            // Skip if too short or looks like code
            if (text.length < 15 || text.includes('function(') || text.includes('var ') || 
                text.includes('{') || text.includes('script') || text.includes('push(')) {
              continue;
            }
            
            // Create a title
            let title = text;
            if (text.length > 100) {
              const firstLine = text.split('\n')[0].trim();
              title = firstLine.length > 0 ? firstLine : text.substring(0, 97) + '...';
            }
            
            // Add reward
            rewards.push({
              reward: title,
              notes: text !== title ? text : '',
              site: 'William Hill',
              url: window.location.href,
              category: text.toLowerCase().includes('spin') ? 'FREE_SPIN' : 'FREE_BET',
              detectedAt: new Date().toISOString()
            });
          } catch (err) {
            console.error('SpinVault: Error processing William Hill text node:', err);
          }
        }
      } catch (err) {
        console.error(`SpinVault: Error searching for keyword "${keyword}":`, err);
      }
    }
    
    // Process the promo elements found earlier
    for (const element of promoElements) {
      try {
        // Skip elements that have been marked to ignore or script-like elements
        if (element.hasAttribute('data-spinvault-ignore') || 
            element.nodeName === 'SCRIPT' || 
            element.nodeName === 'STYLE') {
          continue;
        }
        
        // Get title
        let title = '';
        const titleElement = element.querySelector('h1, h2, h3, h4, h5, h6, [class*="title"], [class*="heading"]');
        if (titleElement) {
          title = titleElement.textContent.trim();
        } else {
          const text = element.textContent.trim();
          
          // Skip if it looks like code
          if (text.includes('function(') || text.includes('var ') || 
              text.includes('{') || text.includes('push(')) {
            continue;
          }
          
          // Use first line or first 100 chars
          const firstLine = text.split('\n')[0].trim();
          title = firstLine.length > 10 ? firstLine : text.substring(0, Math.min(100, text.length));
        }
        
        // Skip empty or short titles
        if (!title || title.length < 10) {
          continue;
        }
        
        // Get description
        let description = '';
        const descElement = element.querySelector('p, [class*="description"], [class*="content"], [class*="text"]');
        if (descElement && descElement !== titleElement) {
          description = descElement.textContent.trim();
        }
        
        // Determine category based on content
        let category = 'FREE_BET';
        const allText = (title + ' ' + description).toLowerCase();
        
        if (allText.includes('free spin') || allText.includes('slot') || allText.includes('vegas') || allText.includes('casino')) {
          category = 'FREE_SPIN';
        } else if (allText.includes('acca') || allText.includes('accumulator')) {
          category = 'ACCA_INSURANCE';
        } else if (allText.includes('enhanced') || allText.includes('boost') || allText.includes('price')) {
          category = 'ODDS_BOOST';
        }
        
        // Add to rewards if title seems valid
        rewards.push({
          reward: title,
          notes: description,
          site: 'William Hill',
          url: window.location.href,
          category,
          detectedAt: new Date().toISOString()
        });
      } catch (err) {
        console.error('SpinVault: Error processing William Hill promo:', err);
      }
    }
    
    // Check for free bet messages in account area
    const accountElements = document.querySelectorAll(
      '[class*="account"], [class*="balance"], [class*="bonus"]'
    );
    
    for (const element of accountElements) {
      try {
        const text = element.textContent.trim();
        
        if (text.toLowerCase().includes('free') && text.toLowerCase().includes('bet')) {
          rewards.push({
            reward: text.length > 100 ? text.substring(0, 100) + '...' : text,
            notes: 'Personal account offer',
            site: 'William Hill',
            url: window.location.href,
            category: 'PERSONAL_OFFER',
            detectedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.error('Error processing William Hill account element:', err);
      }
    }
    
    return rewards;
  } catch (error) {
    console.error('Error scanning William Hill:', error);
    return [];
  }
}

// Ladbrokes specific scanner
async function scanLadbrokes() {
